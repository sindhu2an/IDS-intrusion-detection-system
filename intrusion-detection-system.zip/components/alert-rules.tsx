"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Edit, Trash2, Shield } from "lucide-react"

const mockRules = [
  {
    id: "AUTH_001",
    name: "Brute Force Detection",
    description: "Detects multiple failed login attempts from the same IP",
    category: "Authentication",
    severity: "high",
    enabled: true,
    conditions: "Failed login attempts > 5 in 5 minutes",
    actions: ["Block IP", "Send Alert", "Log Event"],
    lastTriggered: "2 minutes ago",
  },
  {
    id: "NET_003",
    name: "Suspicious Outbound Traffic",
    description: "Monitors for unusual data exfiltration patterns",
    category: "Network",
    severity: "medium",
    enabled: true,
    conditions: "Outbound traffic > 100MB in 1 minute",
    actions: ["Send Alert", "Log Event", "Rate Limit"],
    lastTriggered: "5 minutes ago",
  },
  {
    id: "MAL_007",
    name: "Malware Signature Match",
    description: "Detects known malware signatures in files",
    category: "Malware",
    severity: "high",
    enabled: true,
    conditions: "File hash matches known malware database",
    actions: ["Quarantine File", "Send Alert", "Block User"],
    lastTriggered: "10 minutes ago",
  },
]

export function AlertRules() {
  const [rules, setRules] = useState(mockRules)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  const toggleRule = (ruleId: string) => {
    setRules((prev) => prev.map((rule) => (rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule)))
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-red-600 bg-red-50 border-red-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "low":
        return "text-green-600 bg-green-50 border-green-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Alert Rules</h2>
          <p className="text-gray-600">Configure detection rules and automated responses</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Rule
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Alert Rule</DialogTitle>
              <DialogDescription>Define conditions and actions for security detection</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ruleName">Rule Name</Label>
                  <Input id="ruleName" placeholder="Enter rule name" />
                </div>
                <div>
                  <Label htmlFor="ruleId">Rule ID</Label>
                  <Input id="ruleId" placeholder="e.g., AUTH_002" />
                </div>
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" placeholder="Describe what this rule detects" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="authentication">Authentication</SelectItem>
                      <SelectItem value="network">Network</SelectItem>
                      <SelectItem value="malware">Malware</SelectItem>
                      <SelectItem value="access-control">Access Control</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="severity">Severity</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="conditions">Conditions</Label>
                <Textarea id="conditions" placeholder="Define the conditions that trigger this rule" />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsCreateDialogOpen(false)}>Create Rule</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {rules.map((rule) => (
          <Card key={rule.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Shield className="h-5 w-5 text-blue-600" />
                  <div>
                    <CardTitle className="text-lg">{rule.name}</CardTitle>
                    <CardDescription>{rule.description}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={`${getSeverityColor(rule.severity)} border`}>{rule.severity.toUpperCase()}</Badge>
                  <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium">Rule ID</Label>
                  <p className="text-sm font-mono mt-1">{rule.id}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Category</Label>
                  <p className="text-sm mt-1">{rule.category}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Last Triggered</Label>
                  <p className="text-sm mt-1">{rule.lastTriggered}</p>
                </div>
              </div>
              <div className="mt-4">
                <Label className="text-sm font-medium">Conditions</Label>
                <p className="text-sm mt-1 p-2 bg-gray-50 dark:bg-gray-800 rounded font-mono">{rule.conditions}</p>
              </div>
              <div className="mt-4">
                <Label className="text-sm font-medium">Actions</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {rule.actions.map((action, index) => (
                    <Badge key={index} variant="outline">
                      {action}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex justify-end space-x-2 mt-4">
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
                <Button variant="outline" size="sm">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

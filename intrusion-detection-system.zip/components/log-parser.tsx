"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, FileText, AlertTriangle, CheckCircle } from "lucide-react"

interface ParsedLog {
  timestamp: string
  level: string
  source: string
  message: string
  parsed: boolean
  error?: string
}

export function LogParser() {
  const [rawLogs, setRawLogs] = useState("")
  const [logFormat, setLogFormat] = useState("syslog")
  const [parsedLogs, setParsedLogs] = useState<ParsedLog[]>([])
  const [isProcessing, setIsProcessing] = useState(false)

  const parseLogFormat = (logText: string, format: string): ParsedLog[] => {
    const lines = logText.split("\n").filter((line) => line.trim())

    return lines.map((line, index) => {
      try {
        switch (format) {
          case "syslog":
            // Basic syslog parsing: timestamp hostname service: message
            const syslogMatch = line.match(/^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(\w+)\s+(\w+):\s*(.+)$/)
            if (syslogMatch) {
              return {
                timestamp: syslogMatch[1],
                level: "INFO",
                source: syslogMatch[3],
                message: syslogMatch[4],
                parsed: true,
              }
            }
            break

          case "apache":
            // Apache access log parsing
            const apacheMatch = line.match(/^(\S+)\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"([^"]+)"\s+(\d+)\s+(\d+)/)
            if (apacheMatch) {
              return {
                timestamp: apacheMatch[2],
                level: Number.parseInt(apacheMatch[4]) >= 400 ? "WARNING" : "INFO",
                source: "apache",
                message: `${apacheMatch[1]} - ${apacheMatch[3]} - Status: ${apacheMatch[4]}`,
                parsed: true,
              }
            }
            break

          case "json":
            // JSON log parsing
            const jsonLog = JSON.parse(line)
            return {
              timestamp: jsonLog.timestamp || jsonLog.time || new Date().toISOString(),
              level: jsonLog.level || jsonLog.severity || "INFO",
              source: jsonLog.source || jsonLog.service || "unknown",
              message: jsonLog.message || jsonLog.msg || line,
              parsed: true,
            }

          default:
            // Generic parsing - try to extract basic info
            const genericMatch = line.match(
              /(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2})?.*?(ERROR|WARN|INFO|DEBUG|CRITICAL)?.*?(.+)/,
            )
            return {
              timestamp: genericMatch?.[1] || new Date().toISOString(),
              level: genericMatch?.[2] || "INFO",
              source: "unknown",
              message: genericMatch?.[3] || line,
              parsed: true,
            }
        }

        // Fallback for unparseable lines
        return {
          timestamp: new Date().toISOString(),
          level: "INFO",
          source: "unknown",
          message: line,
          parsed: false,
          error: "Could not parse log format",
        }
      } catch (error) {
        return {
          timestamp: new Date().toISOString(),
          level: "ERROR",
          source: "parser",
          message: line,
          parsed: false,
          error: `Parse error: ${error}`,
        }
      }
    })
  }

  const handleParseLogs = async () => {
    setIsProcessing(true)

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const parsed = parseLogFormat(rawLogs, logFormat)
    setParsedLogs(parsed)
    setIsProcessing(false)
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case "CRITICAL":
      case "ERROR":
        return "text-red-600 bg-red-50 border-red-200"
      case "WARNING":
      case "WARN":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "INFO":
        return "text-blue-600 bg-blue-50 border-blue-200"
      case "DEBUG":
        return "text-gray-600 bg-gray-50 border-gray-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Log Parser</CardTitle>
          <CardDescription>Parse and analyze raw log files from various sources</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="logFormat">Log Format</Label>
            <Select value={logFormat} onValueChange={setLogFormat}>
              <SelectTrigger>
                <SelectValue placeholder="Select log format" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="syslog">Syslog</SelectItem>
                <SelectItem value="apache">Apache Access Log</SelectItem>
                <SelectItem value="json">JSON Logs</SelectItem>
                <SelectItem value="generic">Generic/Auto-detect</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="rawLogs">Raw Log Data</Label>
            <Textarea
              id="rawLogs"
              placeholder="Paste your raw log data here..."
              value={rawLogs}
              onChange={(e) => setRawLogs(e.target.value)}
              className="min-h-[200px] font-mono text-sm"
            />
          </div>

          <div className="flex space-x-2">
            <Button onClick={handleParseLogs} disabled={!rawLogs.trim() || isProcessing}>
              <FileText className="h-4 w-4 mr-2" />
              {isProcessing ? "Processing..." : "Parse Logs"}
            </Button>
            <Button variant="outline">
              <Upload className="h-4 w-4 mr-2" />
              Upload File
            </Button>
          </div>
        </CardContent>
      </Card>

      {parsedLogs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Parsed Results</CardTitle>
            <CardDescription>
              {parsedLogs.filter((log) => log.parsed).length} of {parsedLogs.length} logs parsed successfully
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {parsedLogs.map((log, index) => (
                <div key={index} className="border rounded-lg p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className="mt-1">
                        {log.parsed ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge className={`${getLevelColor(log.level)} border`}>{log.level}</Badge>
                          <Badge variant="outline">{log.source}</Badge>
                          <span className="text-xs text-gray-500">{log.timestamp}</span>
                        </div>
                        <p className="text-sm font-mono text-gray-900 dark:text-white">{log.message}</p>
                        {log.error && <p className="text-xs text-red-600 mt-1">{log.error}</p>}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

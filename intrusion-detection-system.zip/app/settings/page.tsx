"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Settings,
  Users,
  Database,
  Download,
  Upload,
  ArrowLeft,
  Save,
  RotateCcw,
  Plus,
  Edit,
  Trash2,
  Key,
  AlertTriangle,
} from "lucide-react"
import Link from "next/link"

// Mock configuration data
const mockSystemConfig = {
  general: {
    systemName: "SecureWatch IDS",
    timezone: "UTC",
    logLevel: "INFO",
    maxLogSize: "1GB",
    logRetention: "30",
    autoBackup: true,
    backupInterval: "daily",
  },
  security: {
    sessionTimeout: "30",
    maxLoginAttempts: "5",
    passwordPolicy: "strong",
    twoFactorAuth: true,
    encryptionLevel: "AES-256",
    sslRequired: true,
  },
  monitoring: {
    realTimeMonitoring: true,
    alertThreshold: "medium",
    networkScanInterval: "5",
    threatUpdateInterval: "1",
    performanceMonitoring: true,
    bandwidthMonitoring: true,
  },
  notifications: {
    emailAlerts: true,
    smsAlerts: false,
    webhookAlerts: true,
    alertCooldown: "5",
    escalationTime: "15",
    maxAlertsPerHour: "50",
  },
}

const mockUsers = [
  {
    id: 1,
    username: "admin",
    email: "admin@company.com",
    role: "Administrator",
    status: "active",
    lastLogin: "2024-01-15 14:30:22",
    permissions: ["all"],
  },
  {
    id: 2,
    username: "security_analyst",
    email: "analyst@company.com",
    role: "Security Analyst",
    status: "active",
    lastLogin: "2024-01-15 13:45:10",
    permissions: ["view_alerts", "manage_alerts", "view_logs"],
  },
  {
    id: 3,
    username: "network_admin",
    email: "netadmin@company.com",
    role: "Network Admin",
    status: "active",
    lastLogin: "2024-01-15 12:20:45",
    permissions: ["view_network", "manage_network", "view_devices"],
  },
]

const mockIntegrations = [
  {
    id: 1,
    name: "SIEM Integration",
    type: "siem",
    status: "connected",
    endpoint: "https://siem.company.com/api",
    lastSync: "2024-01-15 14:25:00",
  },
  {
    id: 2,
    name: "Threat Intelligence Feed",
    type: "threat_intel",
    status: "connected",
    endpoint: "https://threatfeed.provider.com/api",
    lastSync: "2024-01-15 14:20:00",
  },
  {
    id: 3,
    name: "Email Notifications",
    type: "email",
    status: "configured",
    endpoint: "smtp.company.com:587",
    lastSync: "N/A",
  },
]

export default function SettingsPage() {
  const [config, setConfig] = useState(mockSystemConfig)
  const [users, setUsers] = useState(mockUsers)
  const [integrations, setIntegrations] = useState(mockIntegrations)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false)

  const updateConfig = (section: string, key: string, value: any) => {
    setConfig((prev) => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [key]: value,
      },
    }))
    setHasUnsavedChanges(true)
  }

  const saveConfiguration = () => {
    // Simulate saving configuration
    console.log("Saving configuration:", config)
    setHasUnsavedChanges(false)
    // Show success message
  }

  const resetConfiguration = () => {
    setConfig(mockSystemConfig)
    setHasUnsavedChanges(false)
  }

  const exportConfiguration = () => {
    const configData = JSON.stringify(config, null, 2)
    const blob = new Blob([configData], { type: "application/json" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `ids-config-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "connected":
        return "text-green-600 bg-green-50 border-green-200"
      case "inactive":
      case "disconnected":
        return "text-red-600 bg-red-50 border-red-200"
      case "configured":
        return "text-blue-600 bg-blue-50 border-blue-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Link>
            </div>
            <div className="flex items-center space-x-3">
              <Settings className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Configuration Management</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">System Settings & Administration</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {hasUnsavedChanges && (
                <Badge variant="outline" className="text-orange-600 border-orange-200">
                  Unsaved Changes
                </Badge>
              )}
              <Button onClick={saveConfiguration} disabled={!hasUnsavedChanges}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="integrations">Integrations</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>General System Settings</CardTitle>
                <CardDescription>Basic system configuration and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="systemName">System Name</Label>
                    <Input
                      id="systemName"
                      value={config.general.systemName}
                      onChange={(e) => updateConfig("general", "systemName", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select
                      value={config.general.timezone}
                      onValueChange={(value) => updateConfig("general", "timezone", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="EST">Eastern Time</SelectItem>
                        <SelectItem value="PST">Pacific Time</SelectItem>
                        <SelectItem value="GMT">Greenwich Mean Time</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="logLevel">Log Level</Label>
                    <Select
                      value={config.general.logLevel}
                      onValueChange={(value) => updateConfig("general", "logLevel", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DEBUG">Debug</SelectItem>
                        <SelectItem value="INFO">Info</SelectItem>
                        <SelectItem value="WARNING">Warning</SelectItem>
                        <SelectItem value="ERROR">Error</SelectItem>
                        <SelectItem value="CRITICAL">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxLogSize">Maximum Log Size</Label>
                    <Select
                      value={config.general.maxLogSize}
                      onValueChange={(value) => updateConfig("general", "maxLogSize", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="100MB">100 MB</SelectItem>
                        <SelectItem value="500MB">500 MB</SelectItem>
                        <SelectItem value="1GB">1 GB</SelectItem>
                        <SelectItem value="5GB">5 GB</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="logRetention">Log Retention (days)</Label>
                    <Input
                      id="logRetention"
                      type="number"
                      value={config.general.logRetention}
                      onChange={(e) => updateConfig("general", "logRetention", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="backupInterval">Backup Interval</Label>
                    <Select
                      value={config.general.backupInterval}
                      onValueChange={(value) => updateConfig("general", "backupInterval", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="autoBackup"
                    checked={config.general.autoBackup}
                    onCheckedChange={(checked) => updateConfig("general", "autoBackup", checked)}
                  />
                  <Label htmlFor="autoBackup">Enable Automatic Backups</Label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuration Management</CardTitle>
                <CardDescription>Backup and restore system configuration</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4">
                  <Button onClick={exportConfiguration} variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export Configuration
                  </Button>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Import Configuration
                  </Button>
                  <Button onClick={resetConfiguration} variant="outline">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset to Defaults
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>Configure security policies and authentication settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                    <Input
                      id="sessionTimeout"
                      type="number"
                      value={config.security.sessionTimeout}
                      onChange={(e) => updateConfig("security", "sessionTimeout", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxLoginAttempts">Max Login Attempts</Label>
                    <Input
                      id="maxLoginAttempts"
                      type="number"
                      value={config.security.maxLoginAttempts}
                      onChange={(e) => updateConfig("security", "maxLoginAttempts", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="passwordPolicy">Password Policy</Label>
                    <Select
                      value={config.security.passwordPolicy}
                      onValueChange={(value) => updateConfig("security", "passwordPolicy", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic (8+ characters)</SelectItem>
                        <SelectItem value="strong">Strong (12+ chars, mixed case, numbers)</SelectItem>
                        <SelectItem value="complex">Complex (16+ chars, symbols required)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="encryptionLevel">Encryption Level</Label>
                    <Select
                      value={config.security.encryptionLevel}
                      onValueChange={(value) => updateConfig("security", "encryptionLevel", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="AES-128">AES-128</SelectItem>
                        <SelectItem value="AES-256">AES-256</SelectItem>
                        <SelectItem value="RSA-2048">RSA-2048</SelectItem>
                        <SelectItem value="RSA-4096">RSA-4096</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="twoFactorAuth"
                      checked={config.security.twoFactorAuth}
                      onCheckedChange={(checked) => updateConfig("security", "twoFactorAuth", checked)}
                    />
                    <Label htmlFor="twoFactorAuth">Require Two-Factor Authentication</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="sslRequired"
                      checked={config.security.sslRequired}
                      onCheckedChange={(checked) => updateConfig("security", "sslRequired", checked)}
                    />
                    <Label htmlFor="sslRequired">Require SSL/TLS for all connections</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Monitoring Configuration</CardTitle>
                <CardDescription>Configure monitoring thresholds and intervals</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="alertThreshold">Alert Threshold</Label>
                    <Select
                      value={config.monitoring.alertThreshold}
                      onValueChange={(value) => updateConfig("monitoring", "alertThreshold", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="networkScanInterval">Network Scan Interval (minutes)</Label>
                    <Input
                      id="networkScanInterval"
                      type="number"
                      value={config.monitoring.networkScanInterval}
                      onChange={(e) => updateConfig("monitoring", "networkScanInterval", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="threatUpdateInterval">Threat Update Interval (hours)</Label>
                    <Input
                      id="threatUpdateInterval"
                      type="number"
                      value={config.monitoring.threatUpdateInterval}
                      onChange={(e) => updateConfig("monitoring", "threatUpdateInterval", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="realTimeMonitoring"
                      checked={config.monitoring.realTimeMonitoring}
                      onCheckedChange={(checked) => updateConfig("monitoring", "realTimeMonitoring", checked)}
                    />
                    <Label htmlFor="realTimeMonitoring">Enable Real-time Monitoring</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="performanceMonitoring"
                      checked={config.monitoring.performanceMonitoring}
                      onCheckedChange={(checked) => updateConfig("monitoring", "performanceMonitoring", checked)}
                    />
                    <Label htmlFor="performanceMonitoring">Enable Performance Monitoring</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="bandwidthMonitoring"
                      checked={config.monitoring.bandwidthMonitoring}
                      onCheckedChange={(checked) => updateConfig("monitoring", "bandwidthMonitoring", checked)}
                    />
                    <Label htmlFor="bandwidthMonitoring">Enable Bandwidth Monitoring</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Configure alert notifications and escalation policies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="alertCooldown">Alert Cooldown (minutes)</Label>
                    <Input
                      id="alertCooldown"
                      type="number"
                      value={config.notifications.alertCooldown}
                      onChange={(e) => updateConfig("notifications", "alertCooldown", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="escalationTime">Escalation Time (minutes)</Label>
                    <Input
                      id="escalationTime"
                      type="number"
                      value={config.notifications.escalationTime}
                      onChange={(e) => updateConfig("notifications", "escalationTime", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxAlertsPerHour">Max Alerts per Hour</Label>
                    <Input
                      id="maxAlertsPerHour"
                      type="number"
                      value={config.notifications.maxAlertsPerHour}
                      onChange={(e) => updateConfig("notifications", "maxAlertsPerHour", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="emailAlerts"
                      checked={config.notifications.emailAlerts}
                      onCheckedChange={(checked) => updateConfig("notifications", "emailAlerts", checked)}
                    />
                    <Label htmlFor="emailAlerts">Enable Email Alerts</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="smsAlerts"
                      checked={config.notifications.smsAlerts}
                      onCheckedChange={(checked) => updateConfig("notifications", "smsAlerts", checked)}
                    />
                    <Label htmlFor="smsAlerts">Enable SMS Alerts</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="webhookAlerts"
                      checked={config.notifications.webhookAlerts}
                      onCheckedChange={(checked) => updateConfig("notifications", "webhookAlerts", checked)}
                    />
                    <Label htmlFor="webhookAlerts">Enable Webhook Alerts</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Manage user accounts and permissions</CardDescription>
                  </div>
                  <Dialog open={isCreateUserOpen} onOpenChange={setIsCreateUserOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add User
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create New User</DialogTitle>
                        <DialogDescription>Add a new user account to the system</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="newUsername">Username</Label>
                            <Input id="newUsername" placeholder="Enter username" />
                          </div>
                          <div>
                            <Label htmlFor="newEmail">Email</Label>
                            <Input id="newEmail" type="email" placeholder="Enter email" />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="newRole">Role</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="administrator">Administrator</SelectItem>
                              <SelectItem value="security_analyst">Security Analyst</SelectItem>
                              <SelectItem value="network_admin">Network Admin</SelectItem>
                              <SelectItem value="viewer">Viewer</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setIsCreateUserOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={() => setIsCreateUserOpen(false)}>Create User</Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user) => (
                    <div key={user.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full">
                            <Users className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold">{user.username}</h3>
                            <p className="text-sm text-gray-600">{user.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={`${getStatusColor(user.status)} border`}>{user.status}</Badge>
                          <Badge variant="outline">{user.role}</Badge>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" onClick={() => setSelectedUser(user)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit User: {user.username}</DialogTitle>
                                <DialogDescription>Modify user account settings and permissions</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label>Username</Label>
                                    <Input value={user.username} />
                                  </div>
                                  <div>
                                    <Label>Email</Label>
                                    <Input value={user.email} />
                                  </div>
                                </div>
                                <div>
                                  <Label>Role</Label>
                                  <Select value={user.role.toLowerCase().replace(" ", "_")}>
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="administrator">Administrator</SelectItem>
                                      <SelectItem value="security_analyst">Security Analyst</SelectItem>
                                      <SelectItem value="network_admin">Network Admin</SelectItem>
                                      <SelectItem value="viewer">Viewer</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div>
                                  <Label>Permissions</Label>
                                  <div className="grid grid-cols-2 gap-2 mt-2">
                                    {[
                                      "view_alerts",
                                      "manage_alerts",
                                      "view_logs",
                                      "view_network",
                                      "manage_network",
                                    ].map((permission) => (
                                      <div key={permission} className="flex items-center space-x-2">
                                        <Switch
                                          id={permission}
                                          checked={
                                            user.permissions.includes(permission) || user.permissions.includes("all")
                                          }
                                        />
                                        <Label htmlFor={permission} className="text-sm">
                                          {permission.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                                        </Label>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                <div className="flex justify-end space-x-2">
                                  <Button variant="outline">Cancel</Button>
                                  <Button>Save Changes</Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="mt-3 grid grid-cols-3 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Last Login:</span>
                          <p>{user.lastLogin}</p>
                        </div>
                        <div>
                          <span className="font-medium">Permissions:</span>
                          <p>{user.permissions.includes("all") ? "All" : user.permissions.length + " assigned"}</p>
                        </div>
                        <div>
                          <span className="font-medium">Status:</span>
                          <p className="capitalize">{user.status}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="integrations" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>System Integrations</CardTitle>
                    <CardDescription>Manage external system integrations and API connections</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Integration
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {integrations.map((integration) => (
                    <div key={integration.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="bg-purple-100 dark:bg-purple-900 p-2 rounded-full">
                            <Database className="h-5 w-5 text-purple-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold">{integration.name}</h3>
                            <p className="text-sm text-gray-600">{integration.endpoint}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={`${getStatusColor(integration.status)} border`}>{integration.status}</Badge>
                          <Button variant="outline" size="sm">
                            <Key className="h-4 w-4 mr-2" />
                            Configure
                          </Button>
                          <Button variant="outline" size="sm">
                            <AlertTriangle className="h-4 w-4 mr-2" />
                            Test
                          </Button>
                        </div>
                      </div>
                      <div className="mt-3 grid grid-cols-3 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Type:</span>
                          <p className="capitalize">{integration.type.replace("_", " ")}</p>
                        </div>
                        <div>
                          <span className="font-medium">Last Sync:</span>
                          <p>{integration.lastSync}</p>
                        </div>
                        <div>
                          <span className="font-medium">Status:</span>
                          <p className="capitalize">{integration.status}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  AlertTriangle,
  Shield,
  Eye,
  Activity,
  Search,
  ArrowUpDown,
  CheckCircle,
  Clock,
  User,
  ArrowLeft,
} from "lucide-react"
import Link from "next/link"

// Enhanced mock alert data
const mockAlerts = [
  {
    id: 1,
    type: "critical",
    severity: "high",
    title: "Brute Force Attack Detected",
    description: "Multiple failed login attempts from IP 192.168.1.100. 47 attempts in the last 5 minutes.",
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    source: "Authentication System",
    sourceIP: "192.168.1.100",
    targetSystem: "Web Server",
    status: "active",
    assignedTo: null,
    category: "Authentication",
    ruleId: "AUTH_001",
    evidence: ["Failed login logs", "IP geolocation data", "User agent analysis"],
    recommendedActions: ["Block IP address", "Reset affected user passwords", "Enable 2FA"],
  },
  {
    id: 2,
    type: "warning",
    severity: "medium",
    title: "Suspicious Network Traffic",
    description: "Unusual outbound traffic pattern detected on port 443. Data exfiltration attempt suspected.",
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    source: "Network Monitor",
    sourceIP: "10.0.0.45",
    targetSystem: "Database Server",
    status: "investigating",
    assignedTo: "security-team",
    category: "Network",
    ruleId: "NET_003",
    evidence: ["Network flow logs", "Packet capture", "Bandwidth analysis"],
    recommendedActions: ["Investigate data access patterns", "Review user permissions", "Monitor network traffic"],
  },
  {
    id: 3,
    type: "critical",
    severity: "high",
    title: "Malware Signature Detected",
    description: "Known malware signature found in uploaded file. Trojan.Win32.Generic detected.",
    timestamp: new Date(Date.now() - 10 * 60 * 1000),
    source: "File Scanner",
    sourceIP: "172.16.0.23",
    targetSystem: "File Server",
    status: "resolved",
    assignedTo: "admin",
    category: "Malware",
    ruleId: "MAL_007",
    evidence: ["File hash analysis", "Behavioral analysis", "Signature match"],
    recommendedActions: ["Quarantine file", "Scan affected systems", "Update antivirus signatures"],
  },
  {
    id: 4,
    type: "info",
    severity: "low",
    title: "System Configuration Change",
    description: "Firewall rules updated by administrator. 3 new rules added to block suspicious IPs.",
    timestamp: new Date(Date.now() - 60 * 60 * 1000),
    source: "System",
    sourceIP: "127.0.0.1",
    targetSystem: "Firewall",
    status: "acknowledged",
    assignedTo: "admin",
    category: "System",
    ruleId: "SYS_012",
    evidence: ["Configuration logs", "Admin activity logs"],
    recommendedActions: ["Review changes", "Document modifications"],
  },
  {
    id: 5,
    type: "warning",
    severity: "medium",
    title: "Privilege Escalation Attempt",
    description: "User account attempted to access restricted resources. Potential privilege escalation detected.",
    timestamp: new Date(Date.now() - 90 * 60 * 1000),
    source: "Access Control",
    sourceIP: "192.168.1.55",
    targetSystem: "Domain Controller",
    status: "active",
    assignedTo: null,
    category: "Access Control",
    ruleId: "ACC_005",
    evidence: ["Access logs", "Permission audit", "User behavior analysis"],
    recommendedActions: ["Review user permissions", "Investigate user activity", "Consider account suspension"],
  },
]

export default function AlertsPage() {
  const [alerts, setAlerts] = useState(mockAlerts)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("timestamp")
  const [selectedAlert, setSelectedAlert] = useState<any>(null)

  const filteredAndSortedAlerts = useMemo(() => {
    const filtered = alerts.filter((alert) => {
      const matchesSearch =
        alert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.sourceIP.includes(searchTerm)
      const matchesType = filterType === "all" || alert.type === filterType
      const matchesStatus = filterStatus === "all" || alert.status === filterStatus
      return matchesSearch && matchesType && matchesStatus
    })

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case "timestamp":
          return b.timestamp.getTime() - a.timestamp.getTime()
        case "severity":
          const severityOrder = { high: 3, medium: 2, low: 1 }
          return (
            severityOrder[b.severity as keyof typeof severityOrder] -
            severityOrder[a.severity as keyof typeof severityOrder]
          )
        case "title":
          return a.title.localeCompare(b.title)
        default:
          return 0
      }
    })
  }, [alerts, searchTerm, filterType, filterStatus, sortBy])

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "critical":
        return <AlertTriangle className="h-4 w-4" />
      case "warning":
        return <Eye className="h-4 w-4" />
      case "info":
        return <Activity className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "investigating":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "resolved":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "acknowledged":
        return <Eye className="h-4 w-4 text-blue-500" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const updateAlertStatus = (alertId: number, newStatus: string, assignedTo?: string) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === alertId ? { ...alert, status: newStatus, assignedTo: assignedTo || alert.assignedTo } : alert,
      ),
    )
  }

  const getAlertVariant = (type: string) => {
    switch (type) {
      case "critical":
        return "destructive"
      case "warning":
        return "default"
      case "info":
        return "secondary"
      default:
        return "default"
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-red-600 bg-red-50 border-red-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "low":
        return "text-green-600 bg-green-50 border-green-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Link>
            </div>
            <div className="flex items-center space-x-3">
              <Shield className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Alert Management</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Security Alert Center</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters and Search */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filter & Search Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search alerts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="investigating">Investigating</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="acknowledged">Acknowledged</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="timestamp">Timestamp</SelectItem>
                  <SelectItem value="severity">Severity</SelectItem>
                  <SelectItem value="title">Title</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Alert Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Alerts</p>
                  <p className="text-2xl font-bold">{alerts.length}</p>
                </div>
                <Activity className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active</p>
                  <p className="text-2xl font-bold text-red-600">
                    {alerts.filter((a) => a.status === "active").length}
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Investigating</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {alerts.filter((a) => a.status === "investigating").length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Resolved</p>
                  <p className="text-2xl font-bold text-green-600">
                    {alerts.filter((a) => a.status === "resolved").length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alerts List */}
        <Card>
          <CardHeader>
            <CardTitle>Security Alerts ({filteredAndSortedAlerts.length})</CardTitle>
            <CardDescription>Manage and investigate security alerts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredAndSortedAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="border rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className="mt-1">{getAlertIcon(alert.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-gray-900 dark:text-white">{alert.title}</h3>
                          <Badge variant={getAlertVariant(alert.type) as any}>{alert.type.toUpperCase()}</Badge>
                          <Badge className={`${getSeverityColor(alert.severity)} border`}>
                            {alert.severity.toUpperCase()}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{alert.description}</p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span>Source: {alert.source}</span>
                          <span>IP: {alert.sourceIP}</span>
                          <span>Target: {alert.targetSystem}</span>
                          <span>{alert.timestamp.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(alert.status)}
                        <span className="text-sm capitalize">{alert.status}</span>
                      </div>
                      {alert.assignedTo && (
                        <Badge variant="outline">
                          <User className="h-3 w-3 mr-1" />
                          {alert.assignedTo}
                        </Badge>
                      )}
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" onClick={() => setSelectedAlert(alert)}>
                            View Details
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle className="flex items-center space-x-2">
                              {getAlertIcon(alert.type)}
                              <span>{alert.title}</span>
                            </DialogTitle>
                            <DialogDescription>
                              Alert ID: {alert.id} | Rule: {alert.ruleId}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label className="text-sm font-medium">Severity</Label>
                                <Badge className={`${getSeverityColor(alert.severity)} border mt-1`}>
                                  {alert.severity.toUpperCase()}
                                </Badge>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Status</Label>
                                <div className="flex items-center space-x-1 mt-1">
                                  {getStatusIcon(alert.status)}
                                  <span className="text-sm capitalize">{alert.status}</span>
                                </div>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Source IP</Label>
                                <p className="text-sm font-mono mt-1">{alert.sourceIP}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Target System</Label>
                                <p className="text-sm mt-1">{alert.targetSystem}</p>
                              </div>
                            </div>

                            <div>
                              <Label className="text-sm font-medium">Description</Label>
                              <p className="text-sm mt-1 p-3 bg-gray-50 dark:bg-gray-800 rounded">
                                {alert.description}
                              </p>
                            </div>

                            <div>
                              <Label className="text-sm font-medium">Evidence</Label>
                              <ul className="text-sm mt-1 space-y-1">
                                {alert.evidence.map((item, index) => (
                                  <li key={index} className="flex items-center space-x-2">
                                    <CheckCircle className="h-3 w-3 text-green-500" />
                                    <span>{item}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div>
                              <Label className="text-sm font-medium">Recommended Actions</Label>
                              <ul className="text-sm mt-1 space-y-1">
                                {alert.recommendedActions.map((action, index) => (
                                  <li key={index} className="flex items-center space-x-2">
                                    <ArrowUpDown className="h-3 w-3 text-blue-500" />
                                    <span>{action}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div className="flex space-x-2 pt-4 border-t">
                              <Button
                                onClick={() => updateAlertStatus(alert.id, "investigating", "security-team")}
                                disabled={alert.status === "investigating"}
                              >
                                Start Investigation
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => updateAlertStatus(alert.id, "acknowledged")}
                                disabled={alert.status === "acknowledged"}
                              >
                                Acknowledge
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => updateAlertStatus(alert.id, "resolved")}
                                disabled={alert.status === "resolved"}
                              >
                                Mark Resolved
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Download, AlertTriangle, Activity, Shield, ArrowLeft, TrendingUp, Eye, Clock } from "lucide-react"
import Link from "next/link"

// Enhanced mock log data
const mockLogs = [
  {
    id: 1,
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    level: "CRITICAL",
    source: "auth-service",
    sourceIP: "192.168.1.100",
    message: "Authentication failed for user 'admin' from 192.168.1.100 - attempt 5/5",
    category: "Authentication",
    details: {
      user: "admin",
      attempts: 5,
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      sessionId: "sess_abc123",
    },
    severity: "high",
    correlationId: "auth_001",
  },
  {
    id: 2,
    timestamp: new Date(Date.now() - 3 * 60 * 1000),
    level: "WARNING",
    source: "network-monitor",
    sourceIP: "10.0.0.45",
    message: "Unusual outbound traffic detected: 150MB transferred to external IP 203.0.113.5",
    category: "Network",
    details: {
      bytesTransferred: 157286400,
      destinationIP: "203.0.113.5",
      port: 443,
      protocol: "HTTPS",
      duration: "5m 23s",
    },
    severity: "medium",
    correlationId: "net_002",
  },
  {
    id: 3,
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    level: "CRITICAL",
    source: "file-scanner",
    sourceIP: "172.16.0.23",
    message: "Malware detected in uploaded file: trojan.exe (SHA256: a1b2c3d4...)",
    category: "Malware",
    details: {
      fileName: "trojan.exe",
      fileSize: 2048576,
      hash: "a1b2c3d4e5f6789012345678901234567890abcdef",
      malwareType: "Trojan.Win32.Generic",
      quarantined: true,
    },
    severity: "high",
    correlationId: "mal_003",
  },
  {
    id: 4,
    timestamp: new Date(Date.now() - 10 * 60 * 1000),
    level: "INFO",
    source: "system",
    sourceIP: "127.0.0.1",
    message: "Firewall rules updated successfully - 3 new blocking rules added",
    category: "System",
    details: {
      rulesAdded: 3,
      rulesModified: 1,
      adminUser: "security_admin",
      configVersion: "v2.1.4",
    },
    severity: "low",
    correlationId: "sys_004",
  },
  {
    id: 5,
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    level: "WARNING",
    source: "access-control",
    sourceIP: "192.168.1.55",
    message: "Privilege escalation attempt detected for user 'john.doe'",
    category: "Access Control",
    details: {
      user: "john.doe",
      requestedResource: "/admin/users",
      currentRole: "user",
      requiredRole: "admin",
      blocked: true,
    },
    severity: "medium",
    correlationId: "acc_005",
  },
]

// Mock log patterns and statistics
const logPatterns = [
  {
    pattern: "Failed authentication attempts",
    count: 47,
    trend: "increasing",
    severity: "high",
    description: "Multiple failed login attempts detected across different IPs",
  },
  {
    pattern: "Unusual network traffic",
    count: 12,
    trend: "stable",
    severity: "medium",
    description: "Abnormal data transfer patterns identified",
  },
  {
    pattern: "Malware signatures",
    count: 3,
    trend: "decreasing",
    severity: "high",
    description: "Known malware signatures detected in file uploads",
  },
]

export default function LogAnalysisPage() {
  const [logs, setLogs] = useState(mockLogs)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterLevel, setFilterLevel] = useState("all")
  const [filterSource, setFilterSource] = useState("all")
  const [filterCategory, setFilterCategory] = useState("all")
  const [selectedLog, setSelectedLog] = useState<any>(null)
  const [timeRange, setTimeRange] = useState("1h")

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const matchesSearch =
        log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.sourceIP.includes(searchTerm)
      const matchesLevel = filterLevel === "all" || log.level === filterLevel
      const matchesSource = filterSource === "all" || log.source === filterSource
      const matchesCategory = filterCategory === "all" || log.category === filterCategory
      return matchesSearch && matchesLevel && matchesSource && matchesCategory
    })
  }, [logs, searchTerm, filterLevel, filterSource, filterCategory])

  const logStats = useMemo(() => {
    const total = logs.length
    const critical = logs.filter((log) => log.level === "CRITICAL").length
    const warning = logs.filter((log) => log.level === "WARNING").length
    const info = logs.filter((log) => log.level === "INFO").length
    const highSeverity = logs.filter((log) => log.severity === "high").length

    return { total, critical, warning, info, highSeverity }
  }, [logs])

  const getLevelColor = (level: string) => {
    switch (level) {
      case "CRITICAL":
        return "text-red-600 bg-red-50 border-red-200"
      case "WARNING":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "INFO":
        return "text-blue-600 bg-blue-50 border-blue-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getLevelIcon = (level: string) => {
    switch (level) {
      case "CRITICAL":
        return <AlertTriangle className="h-4 w-4" />
      case "WARNING":
        return <Eye className="h-4 w-4" />
      case "INFO":
        return <Activity className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "increasing":
        return <TrendingUp className="h-4 w-4 text-red-500" />
      case "decreasing":
        return <TrendingUp className="h-4 w-4 text-green-500 rotate-180" />
      case "stable":
        return <Activity className="h-4 w-4 text-blue-500" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const exportLogs = () => {
    const csvContent = [
      "Timestamp,Level,Source,Source IP,Category,Message",
      ...filteredLogs.map(
        (log) =>
          `"${log.timestamp.toISOString()}","${log.level}","${log.source}","${log.sourceIP}","${log.category}","${log.message}"`,
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `security-logs-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Link>
            </div>
            <div className="flex items-center space-x-3">
              <Activity className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Log Analysis Engine</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Security Log Analysis & Correlation</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Log Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Logs</p>
                  <p className="text-2xl font-bold">{logStats.total}</p>
                </div>
                <Activity className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Critical</p>
                  <p className="text-2xl font-bold text-red-600">{logStats.critical}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Warnings</p>
                  <p className="text-2xl font-bold text-yellow-600">{logStats.warning}</p>
                </div>
                <Eye className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Info</p>
                  <p className="text-2xl font-bold text-blue-600">{logStats.info}</p>
                </div>
                <Activity className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">High Severity</p>
                  <p className="text-2xl font-bold text-orange-600">{logStats.highSeverity}</p>
                </div>
                <Shield className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="logs" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="logs">Log Analysis</TabsTrigger>
            <TabsTrigger value="patterns">Pattern Detection</TabsTrigger>
            <TabsTrigger value="correlation">Log Correlation</TabsTrigger>
          </TabsList>

          <TabsContent value="logs" className="space-y-6">
            {/* Filters and Search */}
            <Card>
              <CardHeader>
                <CardTitle>Search & Filter Logs</CardTitle>
                <CardDescription>Advanced log filtering and search capabilities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search logs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={filterLevel} onValueChange={setFilterLevel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="CRITICAL">Critical</SelectItem>
                      <SelectItem value="WARNING">Warning</SelectItem>
                      <SelectItem value="INFO">Info</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterSource} onValueChange={setFilterSource}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Sources</SelectItem>
                      <SelectItem value="auth-service">Auth Service</SelectItem>
                      <SelectItem value="network-monitor">Network Monitor</SelectItem>
                      <SelectItem value="file-scanner">File Scanner</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="Authentication">Authentication</SelectItem>
                      <SelectItem value="Network">Network</SelectItem>
                      <SelectItem value="Malware">Malware</SelectItem>
                      <SelectItem value="System">System</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={exportLogs} variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Log Entries */}
            <Card>
              <CardHeader>
                <CardTitle>Security Logs ({filteredLogs.length})</CardTitle>
                <CardDescription>Real-time security event logs with detailed analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-3">
                    {filteredLogs.map((log) => (
                      <div
                        key={log.id}
                        className="border rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3 flex-1">
                            <div className="mt-1">{getLevelIcon(log.level)}</div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center space-x-2 mb-2">
                                <Badge className={`${getLevelColor(log.level)} border`}>{log.level}</Badge>
                                <Badge variant="outline">{log.source}</Badge>
                                <Badge variant="outline">{log.category}</Badge>
                                <span className="text-xs text-gray-500 font-mono">{log.correlationId}</span>
                              </div>
                              <p className="text-sm font-mono text-gray-900 dark:text-white mb-2">{log.message}</p>
                              <div className="flex items-center space-x-4 text-xs text-gray-500">
                                <span>IP: {log.sourceIP}</span>
                                <span>{log.timestamp.toLocaleString()}</span>
                                <span>Severity: {log.severity}</span>
                              </div>
                            </div>
                          </div>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" onClick={() => setSelectedLog(log)}>
                                View Details
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle className="flex items-center space-x-2">
                                  {getLevelIcon(log.level)}
                                  <span>Log Entry Details</span>
                                </DialogTitle>
                                <DialogDescription>Correlation ID: {log.correlationId}</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label className="text-sm font-medium">Level</Label>
                                    <Badge className={`${getLevelColor(log.level)} border mt-1`}>{log.level}</Badge>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Severity</Label>
                                    <p className="text-sm mt-1 capitalize">{log.severity}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Source</Label>
                                    <p className="text-sm mt-1">{log.source}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Category</Label>
                                    <p className="text-sm mt-1">{log.category}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Source IP</Label>
                                    <p className="text-sm font-mono mt-1">{log.sourceIP}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Timestamp</Label>
                                    <p className="text-sm mt-1">{log.timestamp.toLocaleString()}</p>
                                  </div>
                                </div>

                                <div>
                                  <Label className="text-sm font-medium">Message</Label>
                                  <p className="text-sm mt-1 p-3 bg-gray-50 dark:bg-gray-800 rounded font-mono">
                                    {log.message}
                                  </p>
                                </div>

                                <div>
                                  <Label className="text-sm font-medium">Additional Details</Label>
                                  <div className="mt-1 p-3 bg-gray-50 dark:bg-gray-800 rounded">
                                    <pre className="text-xs overflow-x-auto">
                                      {JSON.stringify(log.details, null, 2)}
                                    </pre>
                                  </div>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="patterns" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pattern Detection</CardTitle>
                <CardDescription>Automated detection of security patterns and anomalies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {logPatterns.map((pattern, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <h3 className="font-semibold">{pattern.pattern}</h3>
                          <Badge variant={pattern.severity === "high" ? "destructive" : "default"}>
                            {pattern.severity.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          {getTrendIcon(pattern.trend)}
                          <span className="text-sm font-medium">{pattern.count} occurrences</span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{pattern.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <span>Trend: {pattern.trend}</span>
                          <span>•</span>
                          <span>Last 24 hours</span>
                        </div>
                        <Button variant="outline" size="sm">
                          Investigate Pattern
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="correlation" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Log Correlation Analysis</CardTitle>
                <CardDescription>Correlate related security events across different sources</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-3">Authentication Attack Chain</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-mono">14:30:22</span>
                        <Badge className="text-red-600 bg-red-50 border-red-200">CRITICAL</Badge>
                        <span>Multiple failed authentication attempts detected</span>
                      </div>
                      <div className="flex items-center space-x-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-mono">14:31:15</span>
                        <Badge className="text-yellow-600 bg-yellow-50 border-yellow-200">WARNING</Badge>
                        <span>IP address 192.168.1.100 added to watchlist</span>
                      </div>
                      <div className="flex items-center space-x-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-mono">14:32:08</span>
                        <Badge className="text-blue-600 bg-blue-50 border-blue-200">INFO</Badge>
                        <span>Firewall rule activated to block IP 192.168.1.100</span>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded">
                      <p className="text-sm">
                        <strong>Correlation:</strong> Automated response successfully blocked brute force attack from IP
                        192.168.1.100
                      </p>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-3">Data Exfiltration Attempt</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-mono">14:25:45</span>
                        <Badge className="text-yellow-600 bg-yellow-50 border-yellow-200">WARNING</Badge>
                        <span>Unusual network traffic pattern detected</span>
                      </div>
                      <div className="flex items-center space-x-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-mono">14:27:12</span>
                        <Badge className="text-yellow-600 bg-yellow-50 border-yellow-200">WARNING</Badge>
                        <span>Large data transfer to external IP detected</span>
                      </div>
                      <div className="flex items-center space-x-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-mono">14:28:33</span>
                        <Badge className="text-red-600 bg-red-50 border-red-200">CRITICAL</Badge>
                        <span>Potential data exfiltration alert triggered</span>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 rounded">
                      <p className="text-sm">
                        <strong>Correlation:</strong> Suspicious data transfer pattern indicates potential data breach -
                        requires immediate investigation
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

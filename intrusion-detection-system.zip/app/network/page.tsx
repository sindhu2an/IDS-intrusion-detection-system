"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Network,
  Activity,
  Shield,
  AlertTriangle,
  ArrowLeft,
  Wifi,
  Server,
  Router,
  Globe,
  Eye,
  TrendingUp,
  Pause,
  Play,
} from "lucide-react"
import Link from "next/link"

// Mock network data
const mockNetworkDevices = [
  {
    id: "fw-001",
    name: "Main Firewall",
    type: "firewall",
    ip: "192.168.1.1",
    status: "online",
    cpu: 23,
    memory: 45,
    connections: 1247,
    throughput: "2.4 GB/s",
    location: "Data Center A",
  },
  {
    id: "sw-001",
    name: "Core Switch",
    type: "switch",
    ip: "192.168.1.2",
    status: "online",
    cpu: 12,
    memory: 34,
    connections: 856,
    throughput: "1.8 GB/s",
    location: "Data Center A",
  },
  {
    id: "rt-001",
    name: "Border Router",
    type: "router",
    ip: "203.0.113.1",
    status: "online",
    cpu: 67,
    memory: 78,
    connections: 2341,
    throughput: "5.2 GB/s",
    location: "Edge Network",
  },
  {
    id: "srv-001",
    name: "Web Server",
    type: "server",
    ip: "192.168.1.100",
    status: "warning",
    cpu: 89,
    memory: 92,
    connections: 445,
    throughput: "890 MB/s",
    location: "Data Center B",
  },
  {
    id: "srv-002",
    name: "Database Server",
    type: "server",
    ip: "192.168.1.101",
    status: "online",
    cpu: 34,
    memory: 56,
    connections: 123,
    throughput: "234 MB/s",
    location: "Data Center B",
  },
]

const mockTrafficData = [
  { time: "14:30", inbound: 2.4, outbound: 1.8, threats: 3 },
  { time: "14:31", inbound: 2.6, outbound: 2.1, threats: 1 },
  { time: "14:32", inbound: 2.2, outbound: 1.9, threats: 5 },
  { time: "14:33", inbound: 2.8, outbound: 2.3, threats: 2 },
  { time: "14:34", inbound: 3.1, outbound: 2.5, threats: 7 },
  { time: "14:35", inbound: 2.9, outbound: 2.2, threats: 4 },
]

const mockConnections = [
  {
    id: 1,
    sourceIP: "192.168.1.45",
    destIP: "203.0.113.25",
    port: 443,
    protocol: "HTTPS",
    status: "active",
    bytes: 2048576,
    duration: "00:05:23",
    country: "United States",
    risk: "low",
  },
  {
    id: 2,
    sourceIP: "10.0.0.23",
    destIP: "198.51.100.15",
    port: 22,
    protocol: "SSH",
    status: "suspicious",
    bytes: 1024,
    duration: "00:00:45",
    country: "Unknown",
    risk: "high",
  },
  {
    id: 3,
    sourceIP: "192.168.1.67",
    destIP: "172.16.0.10",
    port: 80,
    protocol: "HTTP",
    status: "active",
    bytes: 512000,
    duration: "00:02:15",
    country: "Canada",
    risk: "medium",
  },
]

export default function NetworkMonitoringPage() {
  const [devices, setDevices] = useState(mockNetworkDevices)
  const [trafficData, setTrafficData] = useState(mockTrafficData)
  const [connections, setConnections] = useState(mockConnections)
  const [isMonitoring, setIsMonitoring] = useState(true)
  const [selectedDevice, setSelectedDevice] = useState<any>(null)
  const [timeRange, setTimeRange] = useState("1h")

  // Simulate real-time updates
  useEffect(() => {
    if (!isMonitoring) return

    const interval = setInterval(() => {
      // Update traffic data
      setTrafficData((prev) => {
        const newData = [...prev.slice(1)]
        const lastTime = prev[prev.length - 1]?.time || "14:35"
        const [hours, minutes] = lastTime.split(":").map(Number)
        const newMinutes = minutes + 1
        const newTime = `${hours}:${newMinutes.toString().padStart(2, "0")}`

        newData.push({
          time: newTime,
          inbound: 2 + Math.random() * 2,
          outbound: 1.5 + Math.random() * 1.5,
          threats: Math.floor(Math.random() * 8),
        })
        return newData
      })

      // Update device metrics
      setDevices((prev) =>
        prev.map((device) => ({
          ...device,
          cpu: Math.max(10, Math.min(95, device.cpu + (Math.random() - 0.5) * 10)),
          memory: Math.max(20, Math.min(95, device.memory + (Math.random() - 0.5) * 8)),
          connections: device.connections + Math.floor((Math.random() - 0.5) * 50),
        })),
      )
    }, 3000)

    return () => clearInterval(interval)
  }, [isMonitoring])

  const networkStats = useMemo(() => {
    const totalDevices = devices.length
    const onlineDevices = devices.filter((d) => d.status === "online").length
    const warningDevices = devices.filter((d) => d.status === "warning").length
    const totalConnections = devices.reduce((sum, d) => sum + d.connections, 0)
    const avgCpu = devices.reduce((sum, d) => sum + d.cpu, 0) / devices.length

    return { totalDevices, onlineDevices, warningDevices, totalConnections, avgCpu }
  }, [devices])

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case "firewall":
        return <Shield className="h-5 w-5" />
      case "switch":
        return <Network className="h-5 w-5" />
      case "router":
        return <Router className="h-5 w-5" />
      case "server":
        return <Server className="h-5 w-5" />
      default:
        return <Network className="h-5 w-5" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "text-green-600 bg-green-50 border-green-200"
      case "warning":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "offline":
        return "text-red-600 bg-red-50 border-red-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "text-red-600 bg-red-50 border-red-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "low":
        return "text-green-600 bg-green-50 border-green-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Link>
            </div>
            <div className="flex items-center space-x-3">
              <Network className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Network Monitoring</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Real-time Network Analysis</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsMonitoring(!isMonitoring)}
                className={isMonitoring ? "text-green-600" : "text-gray-600"}
              >
                {isMonitoring ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                {isMonitoring ? "Pause" : "Resume"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Network Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Devices</p>
                  <p className="text-2xl font-bold">{networkStats.totalDevices}</p>
                </div>
                <Network className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Online</p>
                  <p className="text-2xl font-bold text-green-600">{networkStats.onlineDevices}</p>
                </div>
                <Activity className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Warnings</p>
                  <p className="text-2xl font-bold text-yellow-600">{networkStats.warningDevices}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Connections</p>
                  <p className="text-2xl font-bold">{networkStats.totalConnections.toLocaleString()}</p>
                </div>
                <Wifi className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg CPU</p>
                  <p className="text-2xl font-bold">{networkStats.avgCpu.toFixed(1)}%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="topology" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="topology">Network Topology</TabsTrigger>
            <TabsTrigger value="traffic">Traffic Analysis</TabsTrigger>
            <TabsTrigger value="connections">Active Connections</TabsTrigger>
            <TabsTrigger value="devices">Device Monitor</TabsTrigger>
          </TabsList>

          <TabsContent value="topology" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Network Topology</CardTitle>
                <CardDescription>Visual representation of network infrastructure</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Network Diagram */}
                  <div className="lg:col-span-2">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 h-[400px] flex items-center justify-center">
                      <div className="relative w-full h-full">
                        {/* Internet */}
                        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
                          <Globe className="h-12 w-12 text-blue-600 mb-2" />
                          <span className="text-sm font-medium">Internet</span>
                        </div>

                        {/* Border Router */}
                        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
                          <div className="bg-white dark:bg-gray-700 p-3 rounded-lg border-2 border-blue-500">
                            <Router className="h-8 w-8 text-blue-600" />
                          </div>
                          <span className="text-xs mt-1">Border Router</span>
                          <span className="text-xs text-gray-500">203.0.113.1</span>
                        </div>

                        {/* Firewall */}
                        <div className="absolute top-40 left-1/4 transform -translate-x-1/2 flex flex-col items-center">
                          <div className="bg-white dark:bg-gray-700 p-3 rounded-lg border-2 border-red-500">
                            <Shield className="h-8 w-8 text-red-600" />
                          </div>
                          <span className="text-xs mt-1">Firewall</span>
                          <span className="text-xs text-gray-500">192.168.1.1</span>
                        </div>

                        {/* Core Switch */}
                        <div className="absolute top-40 right-1/4 transform translate-x-1/2 flex flex-col items-center">
                          <div className="bg-white dark:bg-gray-700 p-3 rounded-lg border-2 border-green-500">
                            <Network className="h-8 w-8 text-green-600" />
                          </div>
                          <span className="text-xs mt-1">Core Switch</span>
                          <span className="text-xs text-gray-500">192.168.1.2</span>
                        </div>

                        {/* Servers */}
                        <div className="absolute bottom-8 left-1/4 transform -translate-x-1/2 flex flex-col items-center">
                          <div className="bg-white dark:bg-gray-700 p-3 rounded-lg border-2 border-purple-500">
                            <Server className="h-8 w-8 text-purple-600" />
                          </div>
                          <span className="text-xs mt-1">Web Server</span>
                          <span className="text-xs text-gray-500">192.168.1.100</span>
                        </div>

                        <div className="absolute bottom-8 right-1/4 transform translate-x-1/2 flex flex-col items-center">
                          <div className="bg-white dark:bg-gray-700 p-3 rounded-lg border-2 border-purple-500">
                            <Server className="h-8 w-8 text-purple-600" />
                          </div>
                          <span className="text-xs mt-1">DB Server</span>
                          <span className="text-xs text-gray-500">192.168.1.101</span>
                        </div>

                        {/* Connection Lines */}
                        <svg className="absolute inset-0 w-full h-full pointer-events-none">
                          <line x1="50%" y1="15%" x2="50%" y2="25%" stroke="#3b82f6" strokeWidth="2" />
                          <line x1="50%" y1="35%" x2="25%" y2="45%" stroke="#3b82f6" strokeWidth="2" />
                          <line x1="50%" y1="35%" x2="75%" y2="45%" stroke="#3b82f6" strokeWidth="2" />
                          <line x1="25%" y1="55%" x2="25%" y2="75%" stroke="#3b82f6" strokeWidth="2" />
                          <line x1="75%" y1="55%" x2="75%" y2="75%" stroke="#3b82f6" strokeWidth="2" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Device Status */}
                  <div className="space-y-4">
                    <h3 className="font-semibold">Device Status</h3>
                    {devices.map((device) => (
                      <div key={device.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            {getDeviceIcon(device.type)}
                            <span className="font-medium text-sm">{device.name}</span>
                          </div>
                          <Badge className={`${getStatusColor(device.status)} border text-xs`}>{device.status}</Badge>
                        </div>
                        <div className="space-y-1 text-xs text-gray-600">
                          <div className="flex justify-between">
                            <span>CPU:</span>
                            <span>{device.cpu}%</span>
                          </div>
                          <Progress value={device.cpu} className="h-1" />
                          <div className="flex justify-between">
                            <span>Memory:</span>
                            <span>{device.memory}%</span>
                          </div>
                          <Progress value={device.memory} className="h-1" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="traffic" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Traffic Overview</CardTitle>
                  <CardDescription>Real-time network traffic monitoring</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Inbound Traffic</span>
                      <span className="text-sm font-medium">
                        {trafficData[trafficData.length - 1]?.inbound.toFixed(1)} GB/s
                      </span>
                    </div>
                    <Progress value={(trafficData[trafficData.length - 1]?.inbound / 5) * 100} />
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Outbound Traffic</span>
                      <span className="text-sm font-medium">
                        {trafficData[trafficData.length - 1]?.outbound.toFixed(1)} GB/s
                      </span>
                    </div>
                    <Progress value={(trafficData[trafficData.length - 1]?.outbound / 5) * 100} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Threat Detection</CardTitle>
                  <CardDescription>Real-time threat monitoring</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Active Threats</span>
                      <span className="text-2xl font-bold text-red-600">
                        {trafficData[trafficData.length - 1]?.threats || 0}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span>DDoS Attempts</span>
                        <span>2</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Port Scans</span>
                        <span>3</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Malware Traffic</span>
                        <span>1</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Traffic History</CardTitle>
                <CardDescription>Network traffic patterns over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gray-50 dark:bg-gray-800 rounded-lg p-4 flex items-end justify-between">
                  {trafficData.map((data, index) => (
                    <div key={index} className="flex flex-col items-center space-y-2">
                      <div className="flex space-x-1">
                        <div
                          className="w-3 bg-blue-500 rounded-t"
                          style={{ height: `${(data.inbound / 5) * 200}px` }}
                        />
                        <div
                          className="w-3 bg-green-500 rounded-t"
                          style={{ height: `${(data.outbound / 5) * 200}px` }}
                        />
                        <div
                          className="w-3 bg-red-500 rounded-t"
                          style={{ height: `${(data.threats / 10) * 200}px` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500">{data.time}</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-center space-x-6 mt-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-blue-500 rounded" />
                    <span>Inbound</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded" />
                    <span>Outbound</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded" />
                    <span>Threats</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="connections" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Active Network Connections</CardTitle>
                <CardDescription>Real-time monitoring of network connections</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[500px]">
                  <div className="space-y-3">
                    {connections.map((conn) => (
                      <div key={conn.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className="flex items-center space-x-2">
                              <span className="font-mono text-sm">{conn.sourceIP}</span>
                              <span className="text-gray-400">→</span>
                              <span className="font-mono text-sm">{conn.destIP}</span>
                            </div>
                            <Badge variant="outline">{conn.protocol}</Badge>
                            <Badge variant="outline">Port {conn.port}</Badge>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={`${getRiskColor(conn.risk)} border`}>{conn.risk.toUpperCase()}</Badge>
                            <Badge
                              className={
                                conn.status === "suspicious"
                                  ? "text-red-600 bg-red-50 border-red-200"
                                  : "text-green-600 bg-green-50 border-green-200"
                              }
                            >
                              {conn.status}
                            </Badge>
                          </div>
                        </div>
                        <div className="grid grid-cols-4 gap-4 text-sm text-gray-600">
                          <div>
                            <span className="font-medium">Duration:</span>
                            <p>{conn.duration}</p>
                          </div>
                          <div>
                            <span className="font-medium">Bytes:</span>
                            <p>{(conn.bytes / 1024).toFixed(1)} KB</p>
                          </div>
                          <div>
                            <span className="font-medium">Country:</span>
                            <p>{conn.country}</p>
                          </div>
                          <div className="flex justify-end">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-2" />
                              Inspect
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="devices" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Network Device Monitor</CardTitle>
                <CardDescription>Detailed monitoring of network infrastructure devices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {devices.map((device) => (
                    <div key={device.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          {getDeviceIcon(device.type)}
                          <div>
                            <h3 className="font-semibold">{device.name}</h3>
                            <p className="text-sm text-gray-600">{device.ip}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={`${getStatusColor(device.status)} border`}>{device.status}</Badge>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" onClick={() => setSelectedDevice(device)}>
                                View Details
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle className="flex items-center space-x-2">
                                  {getDeviceIcon(device.type)}
                                  <span>{device.name}</span>
                                </DialogTitle>
                                <DialogDescription>Device monitoring and performance metrics</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label className="text-sm font-medium">IP Address</Label>
                                    <p className="text-sm font-mono mt-1">{device.ip}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Location</Label>
                                    <p className="text-sm mt-1">{device.location}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Type</Label>
                                    <p className="text-sm mt-1 capitalize">{device.type}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium">Throughput</Label>
                                    <p className="text-sm mt-1">{device.throughput}</p>
                                  </div>
                                </div>

                                <div className="space-y-3">
                                  <div>
                                    <div className="flex justify-between text-sm mb-1">
                                      <span>CPU Usage</span>
                                      <span>{device.cpu}%</span>
                                    </div>
                                    <Progress value={device.cpu} />
                                  </div>
                                  <div>
                                    <div className="flex justify-between text-sm mb-1">
                                      <span>Memory Usage</span>
                                      <span>{device.memory}%</span>
                                    </div>
                                    <Progress value={device.memory} />
                                  </div>
                                </div>

                                <div>
                                  <Label className="text-sm font-medium">Active Connections</Label>
                                  <p className="text-2xl font-bold mt-1">{device.connections.toLocaleString()}</p>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                      <div className="grid grid-cols-4 gap-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>CPU</span>
                            <span>{device.cpu}%</span>
                          </div>
                          <Progress value={device.cpu} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Memory</span>
                            <span>{device.memory}%</span>
                          </div>
                          <Progress value={device.memory} className="h-2" />
                        </div>
                        <div>
                          <span className="text-sm text-gray-600">Connections</span>
                          <p className="font-semibold">{device.connections.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-600">Throughput</span>
                          <p className="font-semibold">{device.throughput}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, AlertTriangle, Activity, Network, Eye, Settings, FileText } from "lucide-react"
import Link from "next/link"

// Mock data for demonstration
const mockAlerts = [
  {
    id: 1,
    type: "critical",
    title: "Suspicious Login Attempt",
    description: "Multiple failed login attempts from IP 192.168.1.100",
    timestamp: "2 minutes ago",
    source: "Authentication System",
  },
  {
    id: 2,
    type: "warning",
    title: "Unusual Network Traffic",
    description: "High bandwidth usage detected on port 443",
    timestamp: "5 minutes ago",
    source: "Network Monitor",
  },
  {
    id: 3,
    type: "info",
    title: "System Update",
    description: "IDS signatures updated successfully",
    timestamp: "1 hour ago",
    source: "System",
  },
]

const mockNetworkStats = {
  totalConnections: 1247,
  blockedAttempts: 23,
  activeThreats: 3,
  systemUptime: "99.8%",
}

export default function IDSDashboard() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [systemStatus, setSystemStatus] = useState("active")

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const getAlertVariant = (type: string) => {
    switch (type) {
      case "critical":
        return "destructive"
      case "warning":
        return "default"
      case "info":
        return "secondary"
      default:
        return "default"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "critical":
        return <AlertTriangle className="h-4 w-4" />
      case "warning":
        return <Eye className="h-4 w-4" />
      case "info":
        return <Activity className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Shield className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">SecureWatch IDS</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Intrusion Detection System</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant={systemStatus === "active" ? "default" : "destructive"}>
                {systemStatus === "active" ? "System Active" : "System Alert"}
              </Badge>
              <div className="text-sm text-gray-500 dark:text-gray-400">{currentTime.toLocaleTimeString()}</div>
              <Link href="/alerts">
                <Button variant="outline" size="sm">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Manage Alerts
                </Button>
              </Link>
              <Link href="/network">
                <Button variant="outline" size="sm">
                  <Network className="h-4 w-4 mr-2" />
                  Network Monitor
                </Button>
              </Link>
              <Link href="/logs">
                <Button variant="outline" size="sm">
                  <Activity className="h-4 w-4 mr-2" />
                  Log Analysis
                </Button>
              </Link>
              {/* Added Reports button linking to reporting system */}
              <Link href="/reports">
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Reports
                </Button>
              </Link>
              <Link href="/settings">
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* System Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Connections</CardTitle>
              <Network className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mockNetworkStats.totalConnections.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+12% from last hour</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Blocked Attempts</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{mockNetworkStats.blockedAttempts}</div>
              <p className="text-xs text-muted-foreground">Last 24 hours</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Threats</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{mockNetworkStats.activeThreats}</div>
              <p className="text-xs text-muted-foreground">Requires attention</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">System Uptime</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{mockNetworkStats.systemUptime}</div>
              <Progress value={99.8} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="alerts" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="alerts">Security Alerts</TabsTrigger>
            <TabsTrigger value="monitoring">Live Monitoring</TabsTrigger>
            <TabsTrigger value="logs">Event Logs</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="alerts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Security Alerts</CardTitle>
                <CardDescription>Latest security events and potential threats detected by the system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockAlerts.map((alert) => (
                  <Alert key={alert.id} variant={getAlertVariant(alert.type) as any}>
                    {getAlertIcon(alert.type)}
                    <AlertTitle className="flex items-center justify-between">
                      <span>{alert.title}</span>
                      <Badge variant="outline" className="text-xs">
                        {alert.source}
                      </Badge>
                    </AlertTitle>
                    <AlertDescription>
                      <div className="mt-2">
                        <p>{alert.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">{alert.timestamp}</p>
                      </div>
                    </AlertDescription>
                  </Alert>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Network Traffic</CardTitle>
                  <CardDescription>Real-time network activity monitoring</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Inbound Traffic</span>
                      <span className="text-sm font-medium">2.4 GB/s</span>
                    </div>
                    <Progress value={65} />
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Outbound Traffic</span>
                      <span className="text-sm font-medium">1.8 GB/s</span>
                    </div>
                    <Progress value={45} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Resources</CardTitle>
                  <CardDescription>IDS system performance metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">CPU Usage</span>
                      <span className="text-sm font-medium">34%</span>
                    </div>
                    <Progress value={34} />
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Memory Usage</span>
                      <span className="text-sm font-medium">67%</span>
                    </div>
                    <Progress value={67} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="logs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Event Logs</CardTitle>
                <CardDescription>Detailed system and security event logs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 font-mono text-sm">
                  <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                    <span className="text-green-600">[INFO]</span> 2024-01-15 14:30:22 - System startup completed
                  </div>
                  <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                    <span className="text-yellow-600">[WARN]</span> 2024-01-15 14:32:15 - Unusual traffic pattern
                    detected from 10.0.0.45
                  </div>
                  <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                    <span className="text-red-600">[CRIT]</span> 2024-01-15 14:35:08 - Multiple failed authentication
                    attempts blocked
                  </div>
                  <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                    <span className="text-green-600">[INFO]</span> 2024-01-15 14:36:42 - Firewall rules updated
                    successfully
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Security Reports</CardTitle>
                <CardDescription>Generate and view security analysis reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link href="/reports">
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center bg-transparent w-full"
                    >
                      <Activity className="h-6 w-6 mb-2" />
                      Daily Security Report
                    </Button>
                  </Link>
                  <Link href="/reports">
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center bg-transparent w-full"
                    >
                      <AlertTriangle className="h-6 w-6 mb-2" />
                      Threat Analysis Report
                    </Button>
                  </Link>
                  <Link href="/reports">
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center bg-transparent w-full"
                    >
                      <Network className="h-6 w-6 mb-2" />
                      Network Traffic Report
                    </Button>
                  </Link>
                  <Link href="/reports">
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center bg-transparent w-full"
                    >
                      <Shield className="h-6 w-6 mb-2" />
                      Compliance Report
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

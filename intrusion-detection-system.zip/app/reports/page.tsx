"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  FileText,
  Download,
  CalendarIcon,
  ArrowLeft,
  Plus,
  Eye,
  Clock,
  TrendingUp,
  Shield,
  AlertTriangle,
  Activity,
  Network,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock report data
const mockReports = [
  {
    id: 1,
    name: "Daily Security Summary",
    type: "security",
    status: "completed",
    generatedAt: "2024-01-15 14:30:00",
    size: "2.4 MB",
    format: "PDF",
    schedule: "Daily at 6:00 AM",
    description: "Comprehensive daily security overview including alerts, threats, and system status",
  },
  {
    id: 2,
    name: "Weekly Threat Analysis",
    type: "threat",
    status: "completed",
    generatedAt: "2024-01-14 08:00:00",
    size: "5.1 MB",
    format: "PDF",
    schedule: "Weekly on Monday",
    description: "Detailed analysis of security threats, attack patterns, and mitigation strategies",
  },
  {
    id: 3,
    name: "Network Traffic Report",
    type: "network",
    status: "generating",
    generatedAt: "In Progress",
    size: "N/A",
    format: "CSV",
    schedule: "On Demand",
    description: "Network traffic analysis with bandwidth usage and connection patterns",
  },
  {
    id: 4,
    name: "Compliance Audit Report",
    type: "compliance",
    status: "completed",
    generatedAt: "2024-01-13 16:45:00",
    size: "3.8 MB",
    format: "PDF",
    schedule: "Monthly",
    description: "Security compliance assessment against industry standards and regulations",
  },
]

const mockReportTemplates = [
  {
    id: 1,
    name: "Executive Security Summary",
    category: "executive",
    description: "High-level security overview for executive leadership",
    sections: ["Threat Overview", "Risk Assessment", "Key Metrics", "Recommendations"],
  },
  {
    id: 2,
    name: "Technical Incident Report",
    category: "technical",
    description: "Detailed technical analysis of security incidents",
    sections: ["Incident Timeline", "Technical Analysis", "Impact Assessment", "Remediation Steps"],
  },
  {
    id: 3,
    name: "Compliance Assessment",
    category: "compliance",
    description: "Regulatory compliance status and gap analysis",
    sections: ["Compliance Status", "Gap Analysis", "Risk Matrix", "Action Plan"],
  },
]

const mockMetrics = {
  totalReports: 47,
  scheduledReports: 12,
  completedToday: 8,
  averageGenerationTime: "3.2 minutes",
}

export default function ReportsPage() {
  const [reports, setReports] = useState(mockReports)
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [reportName, setReportName] = useState("")
  const [reportFormat, setReportFormat] = useState("pdf")
  const [dateRange, setDateRange] = useState({ from: new Date(), to: new Date() })
  const [isGenerating, setIsGenerating] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  const generateReport = async () => {
    setIsGenerating(true)
    // Simulate report generation
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const newReport = {
      id: reports.length + 1,
      name: reportName || "Custom Report",
      type: "custom",
      status: "completed",
      generatedAt: new Date().toLocaleString(),
      size: "1.2 MB",
      format: reportFormat.toUpperCase(),
      schedule: "On Demand",
      description: "Custom generated report",
    }

    setReports((prev) => [newReport, ...prev])
    setIsGenerating(false)
    setIsCreateDialogOpen(false)
    setReportName("")
  }

  const downloadReport = (reportId: number) => {
    // Simulate download
    console.log(`Downloading report ${reportId}`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-50 border-green-200"
      case "generating":
        return "text-blue-600 bg-blue-50 border-blue-200"
      case "failed":
        return "text-red-600 bg-red-50 border-red-200"
      case "scheduled":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getReportIcon = (type: string) => {
    switch (type) {
      case "security":
        return <Shield className="h-5 w-5 text-blue-600" />
      case "threat":
        return <AlertTriangle className="h-5 w-5 text-red-600" />
      case "network":
        return <Network className="h-5 w-5 text-green-600" />
      case "compliance":
        return <FileText className="h-5 w-5 text-purple-600" />
      default:
        return <FileText className="h-5 w-5 text-gray-600" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Link>
            </div>
            <div className="flex items-center space-x-3">
              <FileText className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Reporting System</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">Security Reports & Analytics</p>
              </div>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Generate New Report</DialogTitle>
                  <DialogDescription>Create a custom security report with specific parameters</DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="reportName">Report Name</Label>
                      <Input
                        id="reportName"
                        value={reportName}
                        onChange={(e) => setReportName(e.target.value)}
                        placeholder="Enter report name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="reportFormat">Format</Label>
                      <Select value={reportFormat} onValueChange={setReportFormat}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pdf">PDF</SelectItem>
                          <SelectItem value="csv">CSV</SelectItem>
                          <SelectItem value="json">JSON</SelectItem>
                          <SelectItem value="xlsx">Excel</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Report Template</Label>
                    <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a template" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockReportTemplates.map((template) => (
                          <SelectItem key={template.id} value={template.id.toString()}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Date Range From</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal bg-transparent"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {dateRange.from ? format(dateRange.from, "PPP") : "Pick a date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={dateRange.from}
                            onSelect={(date) => setDateRange((prev) => ({ ...prev, from: date || new Date() }))}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div>
                      <Label>Date Range To</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal bg-transparent"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {dateRange.to ? format(dateRange.to, "PPP") : "Pick a date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={dateRange.to}
                            onSelect={(date) => setDateRange((prev) => ({ ...prev, to: date || new Date() }))}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={generateReport} disabled={isGenerating}>
                      {isGenerating ? "Generating..." : "Generate Report"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Report Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Reports</p>
                  <p className="text-2xl font-bold">{mockMetrics.totalReports}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Scheduled</p>
                  <p className="text-2xl font-bold">{mockMetrics.scheduledReports}</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Completed Today</p>
                  <p className="text-2xl font-bold">{mockMetrics.completedToday}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Generation</p>
                  <p className="text-2xl font-bold">{mockMetrics.averageGenerationTime}</p>
                </div>
                <Activity className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="reports" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="reports">Generated Reports</TabsTrigger>
            <TabsTrigger value="templates">Report Templates</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled Reports</TabsTrigger>
            <TabsTrigger value="analytics">Report Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="reports" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Generated Reports</CardTitle>
                <CardDescription>View and download previously generated security reports</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {reports.map((report) => (
                      <div key={report.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {getReportIcon(report.type)}
                            <div>
                              <h3 className="font-semibold">{report.name}</h3>
                              <p className="text-sm text-gray-600">{report.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={`${getStatusColor(report.status)} border`}>{report.status}</Badge>
                            <Badge variant="outline">{report.format}</Badge>
                            {report.status === "completed" && (
                              <>
                                <Button variant="outline" size="sm">
                                  <Eye className="h-4 w-4 mr-2" />
                                  Preview
                                </Button>
                                <Button variant="outline" size="sm" onClick={() => downloadReport(report.id)}>
                                  <Download className="h-4 w-4 mr-2" />
                                  Download
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="mt-3 grid grid-cols-4 gap-4 text-sm text-gray-600">
                          <div>
                            <span className="font-medium">Generated:</span>
                            <p>{report.generatedAt}</p>
                          </div>
                          <div>
                            <span className="font-medium">Size:</span>
                            <p>{report.size}</p>
                          </div>
                          <div>
                            <span className="font-medium">Schedule:</span>
                            <p>{report.schedule}</p>
                          </div>
                          <div>
                            <span className="font-medium">Type:</span>
                            <p className="capitalize">{report.type}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Report Templates</CardTitle>
                    <CardDescription>Pre-configured report templates for different use cases</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Template
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {mockReportTemplates.map((template) => (
                    <Card key={template.id}>
                      <CardHeader>
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <CardDescription>{template.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <Label className="text-sm font-medium">Sections Included:</Label>
                            <ul className="text-sm text-gray-600 mt-1 space-y-1">
                              {template.sections.map((section, index) => (
                                <li key={index} className="flex items-center space-x-2">
                                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                                  <span>{section}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div className="flex space-x-2">
                            <Button size="sm" className="flex-1">
                              Use Template
                            </Button>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="scheduled" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Scheduled Reports</CardTitle>
                    <CardDescription>Manage automated report generation schedules</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Schedule Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Clock className="h-5 w-5 text-blue-600" />
                        <div>
                          <h3 className="font-semibold">Daily Security Summary</h3>
                          <p className="text-sm text-gray-600">Automated daily security overview</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className="text-green-600 bg-green-50 border-green-200">Active</Badge>
                        <Button variant="outline" size="sm">
                          Edit Schedule
                        </Button>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-4 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Frequency:</span>
                        <p>Daily at 6:00 AM</p>
                      </div>
                      <div>
                        <span className="font-medium">Format:</span>
                        <p>PDF</p>
                      </div>
                      <div>
                        <span className="font-medium">Recipients:</span>
                        <p>3 users</p>
                      </div>
                      <div>
                        <span className="font-medium">Next Run:</span>
                        <p>Tomorrow 6:00 AM</p>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Clock className="h-5 w-5 text-purple-600" />
                        <div>
                          <h3 className="font-semibold">Weekly Threat Analysis</h3>
                          <p className="text-sm text-gray-600">Comprehensive weekly threat report</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className="text-green-600 bg-green-50 border-green-200">Active</Badge>
                        <Button variant="outline" size="sm">
                          Edit Schedule
                        </Button>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-4 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Frequency:</span>
                        <p>Weekly on Monday</p>
                      </div>
                      <div>
                        <span className="font-medium">Format:</span>
                        <p>PDF</p>
                      </div>
                      <div>
                        <span className="font-medium">Recipients:</span>
                        <p>5 users</p>
                      </div>
                      <div>
                        <span className="font-medium">Next Run:</span>
                        <p>Monday 8:00 AM</p>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Clock className="h-5 w-5 text-orange-600" />
                        <div>
                          <h3 className="font-semibold">Monthly Compliance Report</h3>
                          <p className="text-sm text-gray-600">Monthly compliance assessment</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className="text-green-600 bg-green-50 border-green-200">Active</Badge>
                        <Button variant="outline" size="sm">
                          Edit Schedule
                        </Button>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-4 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Frequency:</span>
                        <p>Monthly on 1st</p>
                      </div>
                      <div>
                        <span className="font-medium">Format:</span>
                        <p>PDF</p>
                      </div>
                      <div>
                        <span className="font-medium">Recipients:</span>
                        <p>2 users</p>
                      </div>
                      <div>
                        <span className="font-medium">Next Run:</span>
                        <p>Feb 1st 9:00 AM</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Report Generation Trends</CardTitle>
                  <CardDescription>Monthly report generation statistics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gray-50 dark:bg-gray-800 rounded-lg p-4 flex items-end justify-between">
                    {[
                      { month: "Oct", count: 12 },
                      { month: "Nov", count: 18 },
                      { month: "Dec", count: 15 },
                      { month: "Jan", count: 22 },
                    ].map((data, index) => (
                      <div key={index} className="flex flex-col items-center space-y-2">
                        <div
                          className="w-12 bg-blue-500 rounded-t"
                          style={{ height: `${(data.count / 25) * 200}px` }}
                        />
                        <span className="text-sm font-medium">{data.count}</span>
                        <span className="text-xs text-gray-500">{data.month}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Report Types Distribution</CardTitle>
                  <CardDescription>Breakdown of report types generated</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-blue-500 rounded" />
                        <span className="text-sm">Security Reports</span>
                      </div>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-500 rounded" />
                        <span className="text-sm">Threat Analysis</span>
                      </div>
                      <span className="text-sm font-medium">25%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded" />
                        <span className="text-sm">Network Reports</span>
                      </div>
                      <span className="text-sm font-medium">20%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-purple-500 rounded" />
                        <span className="text-sm">Compliance</span>
                      </div>
                      <span className="text-sm font-medium">10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Report Performance Metrics</CardTitle>
                <CardDescription>Key performance indicators for report generation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">3.2 min</div>
                    <div className="text-sm text-gray-600">Average Generation Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">98.5%</div>
                    <div className="text-sm text-gray-600">Success Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">2.1 MB</div>
                    <div className="text-sm text-gray-600">Average Report Size</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

#!/usr/bin/env python3
"""
Alert and Notification System for Intrusion Detection System
Handles alert generation, correlation, escalation, and notifications
"""

import json
import time
import smtplib
import logging
import hashlib
import threading
from datetime import datetime, timedelta
from collections import defaultdict, deque
from typing import Dict, List, Optional, Callable
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dataclasses import dataclass, asdict
from enum import Enum
import requests

class AlertSeverity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"

class AlertStatus(Enum):
    OPEN = "open"
    ACKNOWLEDGED = "acknowledged"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"
    CLOSED = "closed"

@dataclass
class Alert:
    """Alert data structure"""
    alert_id: str
    title: str
    description: str
    severity: AlertSeverity
    category: str
    source_ip: Optional[str] = None
    dest_ip: Optional[str] = None
    protocol: Optional[str] = None
    timestamp: Optional[str] = None
    status: AlertStatus = AlertStatus.OPEN
    assigned_to: Optional[str] = None
    tags: List[str] = None
    evidence: Dict = None
    correlation_id: Optional[str] = None
    escalation_level: int = 0
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[str] = None
    resolved_at: Optional[str] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()
        if self.tags is None:
            self.tags = []
        if self.evidence is None:
            self.evidence = {}

class NotificationChannel:
    """Base class for notification channels"""
    
    def __init__(self, name: str, config: Dict):
        self.name = name
        self.config = config
        self.enabled = config.get('enabled', True)
        self.logger = logging.getLogger(__name__)
    
    def send_notification(self, alert: Alert) -> bool:
        """Send notification for alert"""
        raise NotImplementedError

class EmailNotification(NotificationChannel):
    """Email notification channel"""
    
    def send_notification(self, alert: Alert) -> bool:
        """Send email notification"""
        if not self.enabled:
            return False
        
        try:
            smtp_server = self.config.get('smtp_server', 'localhost')
            smtp_port = self.config.get('smtp_port', 587)
            username = self.config.get('username')
            password = self.config.get('password')
            from_email = self.config.get('from_email', 'ids@localhost')
            to_emails = self.config.get('to_emails', [])
            
            if not to_emails:
                self.logger.warning("No email recipients configured")
                return False
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = from_email
            msg['To'] = ', '.join(to_emails)
            msg['Subject'] = f"[IDS Alert - {alert.severity.value.upper()}] {alert.title}"
            
            # Email body
            body = f"""
Security Alert Detected

Alert ID: {alert.alert_id}
Severity: {alert.severity.value.upper()}
Category: {alert.category}
Timestamp: {alert.timestamp}

Description:
{alert.description}

Source IP: {alert.source_ip or 'N/A'}
Destination IP: {alert.dest_ip or 'N/A'}
Protocol: {alert.protocol or 'N/A'}

Status: {alert.status.value}
Escalation Level: {alert.escalation_level}

Evidence:
{json.dumps(alert.evidence, indent=2)}

This is an automated message from the Intrusion Detection System.
"""
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Send email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                if username and password:
                    server.starttls()
                    server.login(username, password)
                server.send_message(msg)
            
            self.logger.info(f"Email notification sent for alert {alert.alert_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to send email notification: {e}")
            return False

class WebhookNotification(NotificationChannel):
    """Webhook notification channel"""
    
    def send_notification(self, alert: Alert) -> bool:
        """Send webhook notification"""
        if not self.enabled:
            return False
        
        try:
            webhook_url = self.config.get('webhook_url')
            if not webhook_url:
                self.logger.warning("No webhook URL configured")
                return False
            
            # Prepare payload
            payload = {
                'alert_id': alert.alert_id,
                'title': alert.title,
                'description': alert.description,
                'severity': alert.severity.value,
                'category': alert.category,
                'timestamp': alert.timestamp,
                'source_ip': alert.source_ip,
                'dest_ip': alert.dest_ip,
                'protocol': alert.protocol,
                'status': alert.status.value,
                'evidence': alert.evidence
            }
            
            # Send webhook
            headers = {'Content-Type': 'application/json'}
            auth_token = self.config.get('auth_token')
            if auth_token:
                headers['Authorization'] = f'Bearer {auth_token}'
            
            response = requests.post(
                webhook_url,
                json=payload,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                self.logger.info(f"Webhook notification sent for alert {alert.alert_id}")
                return True
            else:
                self.logger.error(f"Webhook failed with status {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to send webhook notification: {e}")
            return False

class FileNotification(NotificationChannel):
    """File-based notification channel"""
    
    def send_notification(self, alert: Alert) -> bool:
        """Write alert to file"""
        if not self.enabled:
            return False
        
        try:
            alert_file = self.config.get('alert_file', 'alerts.json')
            
            # Prepare alert data
            alert_data = asdict(alert)
            alert_data['severity'] = alert.severity.value
            alert_data['status'] = alert.status.value
            
            # Append to file
            with open(alert_file, 'a') as f:
                f.write(json.dumps(alert_data) + '\n')
            
            self.logger.info(f"Alert {alert.alert_id} written to {alert_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to write alert to file: {e}")
            return False

class AlertCorrelator:
    """Alert correlation engine"""
    
    def __init__(self, correlation_window=300):  # 5 minutes
        self.correlation_window = correlation_window
        self.recent_alerts = deque(maxlen=1000)
        self.correlation_rules = []
        self.logger = logging.getLogger(__name__)
        
        # Load default correlation rules
        self.load_default_rules()
    
    def load_default_rules(self):
        """Load default correlation rules"""
        self.correlation_rules = [
            {
                'name': 'Same Source Multiple Targets',
                'condition': lambda alerts: self._same_source_multiple_targets(alerts),
                'correlation_type': 'lateral_movement'
            },
            {
                'name': 'Multiple Sources Same Target',
                'condition': lambda alerts: self._multiple_sources_same_target(alerts),
                'correlation_type': 'coordinated_attack'
            },
            {
                'name': 'Escalating Severity',
                'condition': lambda alerts: self._escalating_severity(alerts),
                'correlation_type': 'attack_progression'
            }
        ]
    
    def _same_source_multiple_targets(self, alerts: List[Alert]) -> Optional[Dict]:
        """Detect same source attacking multiple targets"""
        source_targets = defaultdict(set)
        
        for alert in alerts:
            if alert.source_ip:
                source_targets[alert.source_ip].add(alert.dest_ip)
        
        for source_ip, targets in source_targets.items():
            if len(targets) >= 3:  # Threshold: 3 or more targets
                return {
                    'source_ip': source_ip,
                    'target_count': len(targets),
                    'targets': list(targets)
                }
        
        return None
    
    def _multiple_sources_same_target(self, alerts: List[Alert]) -> Optional[Dict]:
        """Detect multiple sources attacking same target"""
        target_sources = defaultdict(set)
        
        for alert in alerts:
            if alert.dest_ip:
                target_sources[alert.dest_ip].add(alert.source_ip)
        
        for target_ip, sources in target_sources.items():
            if len(sources) >= 3:  # Threshold: 3 or more sources
                return {
                    'target_ip': target_ip,
                    'source_count': len(sources),
                    'sources': list(sources)
                }
        
        return None
    
    def _escalating_severity(self, alerts: List[Alert]) -> Optional[Dict]:
        """Detect escalating attack severity"""
        severity_order = {
            AlertSeverity.INFO: 1,
            AlertSeverity.LOW: 2,
            AlertSeverity.MEDIUM: 3,
            AlertSeverity.HIGH: 4,
            AlertSeverity.CRITICAL: 5
        }
        
        # Group by source IP
        source_alerts = defaultdict(list)
        for alert in alerts:
            if alert.source_ip:
                source_alerts[alert.source_ip].append(alert)
        
        for source_ip, source_alert_list in source_alerts.items():
            if len(source_alert_list) >= 3:
                # Sort by timestamp
                sorted_alerts = sorted(source_alert_list, 
                                     key=lambda x: x.timestamp)
                
                # Check for escalating severity
                severities = [severity_order[alert.severity] for alert in sorted_alerts]
                if len(severities) >= 3:
                    # Check if generally increasing
                    increasing_count = sum(1 for i in range(1, len(severities)) 
                                         if severities[i] > severities[i-1])
                    
                    if increasing_count >= len(severities) // 2:
                        return {
                            'source_ip': source_ip,
                            'alert_count': len(sorted_alerts),
                            'severity_progression': [alert.severity.value for alert in sorted_alerts]
                        }
        
        return None
    
    def correlate_alert(self, alert: Alert) -> Optional[str]:
        """Correlate new alert with recent alerts"""
        self.recent_alerts.append(alert)
        
        # Get recent alerts within correlation window
        current_time = datetime.now()
        recent_window_alerts = []
        
        for recent_alert in self.recent_alerts:
            alert_time = datetime.fromisoformat(recent_alert.timestamp)
            if (current_time - alert_time).total_seconds() <= self.correlation_window:
                recent_window_alerts.append(recent_alert)
        
        # Apply correlation rules
        for rule in self.correlation_rules:
            try:
                correlation_result = rule['condition'](recent_window_alerts)
                if correlation_result:
                    correlation_id = hashlib.md5(
                        f"{rule['name']}_{json.dumps(correlation_result, sort_keys=True)}".encode()
                    ).hexdigest()[:16]
                    
                    self.logger.warning(f"Alert correlation detected: {rule['name']} - {correlation_result}")
                    return correlation_id
                    
            except Exception as e:
                self.logger.error(f"Error in correlation rule {rule['name']}: {e}")
        
        return None

class AlertManager:
    """Main alert management system"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.alerts = {}  # alert_id -> Alert
        self.notification_channels = []
        self.correlator = AlertCorrelator()
        self.escalation_rules = []
        self.logger = logging.getLogger(__name__)
        
        # Setup notification channels
        self.setup_notification_channels()
        
        # Setup escalation rules
        self.setup_escalation_rules()
        
        # Start background tasks
        self.start_background_tasks()
    
    def setup_notification_channels(self):
        """Setup notification channels from config"""
        channels_config = self.config.get('notification_channels', {})
        
        # Email channel
        if 'email' in channels_config:
            email_channel = EmailNotification('email', channels_config['email'])
            self.notification_channels.append(email_channel)
        
        # Webhook channel
        if 'webhook' in channels_config:
            webhook_channel = WebhookNotification('webhook', channels_config['webhook'])
            self.notification_channels.append(webhook_channel)
        
        # File channel (always enabled for logging)
        file_config = channels_config.get('file', {'enabled': True, 'alert_file': 'alerts.json'})
        file_channel = FileNotification('file', file_config)
        self.notification_channels.append(file_channel)
    
    def setup_escalation_rules(self):
        """Setup alert escalation rules"""
        self.escalation_rules = [
            {
                'name': 'Critical Alert Escalation',
                'condition': lambda alert: alert.severity == AlertSeverity.CRITICAL,
                'escalation_time': 300,  # 5 minutes
                'max_escalations': 3
            },
            {
                'name': 'High Alert Escalation',
                'condition': lambda alert: alert.severity == AlertSeverity.HIGH,
                'escalation_time': 900,  # 15 minutes
                'max_escalations': 2
            },
            {
                'name': 'Unacknowledged Alert Escalation',
                'condition': lambda alert: alert.status == AlertStatus.OPEN,
                'escalation_time': 1800,  # 30 minutes
                'max_escalations': 1
            }
        ]
    
    def create_alert(self, title: str, description: str, severity: AlertSeverity,
                    category: str, **kwargs) -> Alert:
        """Create a new alert"""
        alert_id = hashlib.md5(
            f"{title}_{description}_{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]
        
        alert = Alert(
            alert_id=alert_id,
            title=title,
            description=description,
            severity=severity,
            category=category,
            **kwargs
        )
        
        # Check for correlation
        correlation_id = self.correlator.correlate_alert(alert)
        if correlation_id:
            alert.correlation_id = correlation_id
            alert.tags.append('correlated')
        
        # Store alert
        self.alerts[alert_id] = alert
        
        # Send notifications
        self.send_notifications(alert)
        
        self.logger.info(f"Created alert {alert_id}: {title} ({severity.value})")
        return alert
    
    def send_notifications(self, alert: Alert):
        """Send notifications for alert"""
        for channel in self.notification_channels:
            try:
                # Check if channel should be used for this severity
                min_severity = channel.config.get('min_severity', 'info')
                severity_levels = {
                    'info': 1, 'low': 2, 'medium': 3, 'high': 4, 'critical': 5
                }
                
                alert_level = severity_levels.get(alert.severity.value, 1)
                min_level = severity_levels.get(min_severity, 1)
                
                if alert_level >= min_level:
                    success = channel.send_notification(alert)
                    if success:
                        self.logger.info(f"Notification sent via {channel.name} for alert {alert.alert_id}")
                    else:
                        self.logger.error(f"Failed to send notification via {channel.name}")
                        
            except Exception as e:
                self.logger.error(f"Error sending notification via {channel.name}: {e}")
    
    def acknowledge_alert(self, alert_id: str, acknowledged_by: str) -> bool:
        """Acknowledge an alert"""
        if alert_id not in self.alerts:
            return False
        
        alert = self.alerts[alert_id]
        alert.status = AlertStatus.ACKNOWLEDGED
        alert.acknowledged_by = acknowledged_by
        alert.acknowledged_at = datetime.now().isoformat()
        
        self.logger.info(f"Alert {alert_id} acknowledged by {acknowledged_by}")
        return True
    
    def resolve_alert(self, alert_id: str, resolved_by: str) -> bool:
        """Resolve an alert"""
        if alert_id not in self.alerts:
            return False
        
        alert = self.alerts[alert_id]
        alert.status = AlertStatus.RESOLVED
        alert.resolved_at = datetime.now().isoformat()
        
        self.logger.info(f"Alert {alert_id} resolved by {resolved_by}")
        return True
    
    def get_alerts(self, status: Optional[AlertStatus] = None, 
                  severity: Optional[AlertSeverity] = None,
                  limit: int = 100) -> List[Alert]:
        """Get alerts with optional filtering"""
        alerts = list(self.alerts.values())
        
        if status:
            alerts = [a for a in alerts if a.status == status]
        
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        
        # Sort by timestamp (newest first)
        alerts.sort(key=lambda x: x.timestamp, reverse=True)
        
        return alerts[:limit]
    
    def get_alert_statistics(self) -> Dict:
        """Get alert statistics"""
        total_alerts = len(self.alerts)
        
        stats = {
            'total_alerts': total_alerts,
            'by_severity': defaultdict(int),
            'by_status': defaultdict(int),
            'by_category': defaultdict(int),
            'recent_alerts': 0
        }
        
        # Calculate recent alerts (last hour)
        current_time = datetime.now()
        
        for alert in self.alerts.values():
            stats['by_severity'][alert.severity.value] += 1
            stats['by_status'][alert.status.value] += 1
            stats['by_category'][alert.category] += 1
            
            # Check if recent
            alert_time = datetime.fromisoformat(alert.timestamp)
            if (current_time - alert_time).total_seconds() <= 3600:  # 1 hour
                stats['recent_alerts'] += 1
        
        return dict(stats)
    
    def start_background_tasks(self):
        """Start background tasks for escalation"""
        def escalation_worker():
            while True:
                try:
                    self.check_escalations()
                    time.sleep(60)  # Check every minute
                except Exception as e:
                    self.logger.error(f"Error in escalation worker: {e}")
                    time.sleep(60)
        
        escalation_thread = threading.Thread(target=escalation_worker, daemon=True)
        escalation_thread.start()
    
    def check_escalations(self):
        """Check for alerts that need escalation"""
        current_time = datetime.now()
        
        for alert in self.alerts.values():
            if alert.status in [AlertStatus.RESOLVED, AlertStatus.CLOSED]:
                continue
            
            alert_time = datetime.fromisoformat(alert.timestamp)
            time_since_alert = (current_time - alert_time).total_seconds()
            
            for rule in self.escalation_rules:
                if (rule['condition'](alert) and 
                    time_since_alert >= rule['escalation_time'] and
                    alert.escalation_level < rule['max_escalations']):
                    
                    # Escalate alert
                    alert.escalation_level += 1
                    alert.tags.append(f'escalated_level_{alert.escalation_level}')
                    
                    # Send escalation notification
                    escalation_alert = Alert(
                        alert_id=f"{alert.alert_id}_escalation_{alert.escalation_level}",
                        title=f"ESCALATION: {alert.title}",
                        description=f"Alert {alert.alert_id} has been escalated to level {alert.escalation_level}. Original: {alert.description}",
                        severity=AlertSeverity.HIGH,
                        category="escalation",
                        source_ip=alert.source_ip,
                        dest_ip=alert.dest_ip,
                        protocol=alert.protocol
                    )
                    
                    self.send_notifications(escalation_alert)
                    self.logger.warning(f"Alert {alert.alert_id} escalated to level {alert.escalation_level}")

def main():
    """Test alert system"""
    print("Alert System Test")
    print("=" * 30)
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create alert manager with test config
    config = {
        'notification_channels': {
            'file': {
                'enabled': True,
                'alert_file': 'test_alerts.json'
            },
            'webhook': {
                'enabled': False,  # Disabled for testing
                'webhook_url': 'http://localhost:8080/webhook'
            }
        }
    }
    
    alert_manager = AlertManager(config)
    
    # Create test alerts
    print("Creating test alerts...")
    
    # Critical alert
    critical_alert = alert_manager.create_alert(
        title="Malware Detection",
        description="Suspicious executable detected in network traffic",
        severity=AlertSeverity.CRITICAL,
        category="malware",
        source_ip="192.168.1.100",
        dest_ip="192.168.1.1",
        protocol="TCP",
        evidence={"file_hash": "abc123", "signature": "trojan.generic"}
    )
    
    # High severity alert
    high_alert = alert_manager.create_alert(
        title="Port Scan Detected",
        description="Multiple port scan attempts from external IP",
        severity=AlertSeverity.HIGH,
        category="scan",
        source_ip="10.0.0.50",
        dest_ip="192.168.1.10",
        protocol="TCP",
        evidence={"ports_scanned": [22, 80, 443, 8080], "scan_duration": 30}
    )
    
    # Test acknowledgment
    print(f"\nAcknowledging alert {critical_alert.alert_id}")
    alert_manager.acknowledge_alert(critical_alert.alert_id, "admin")
    
    # Get statistics
    stats = alert_manager.get_alert_statistics()
    print(f"\nAlert Statistics:")
    print(f"Total alerts: {stats['total_alerts']}")
    print(f"By severity: {dict(stats['by_severity'])}")
    print(f"By status: {dict(stats['by_status'])}")
    print(f"Recent alerts: {stats['recent_alerts']}")
    
    # Get recent alerts
    recent_alerts = alert_manager.get_alerts(limit=5)
    print(f"\nRecent Alerts:")
    for alert in recent_alerts:
        print(f"  {alert.alert_id}: {alert.title} ({alert.severity.value}) - {alert.status.value}")

if __name__ == "__main__":
    main()

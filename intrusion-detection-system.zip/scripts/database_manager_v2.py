#!/usr/bin/env python3
"""
Advanced Database Manager v2.0
Comprehensive database integration with multiple backend support
"""

import asyncio
import sqlite3
import logging
import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
import threading
from contextlib import contextmanager
import time

# Database backend imports
try:
    import psycopg2
    import psycopg2.pool
    POSTGRESQL_AVAILABLE = True
except ImportError:
    POSTGRESQL_AVAILABLE = False

try:
    import mysql.connector
    import mysql.connector.pooling
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False

from ids_core_v2 import SecurityEvent, EventType, ThreatLevel

logger = logging.getLogger(__name__)

@dataclass
class DatabaseConfig:
    """Database configuration"""
    backend: str = "sqlite"  # sqlite, postgresql, mysql
    host: str = "localhost"
    port: int = 5432
    database: str = "ids_v2"
    username: str = ""
    password: str = ""
    pool_size: int = 10
    max_overflow: int = 20
    pool_timeout: int = 30
    sqlite_path: str = "ids_v2.db"
    enable_wal: bool = True
    enable_foreign_keys: bool = True

class DatabaseSchema:
    """Database schema definitions and migrations"""
    
    CURRENT_VERSION = 3
    
    @staticmethod
    def get_schema_v1() -> Dict[str, str]:
        """Initial schema version 1"""
        return {
            "schema_version": """
                CREATE TABLE IF NOT EXISTS schema_version (
                    version INTEGER PRIMARY KEY,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    description TEXT
                )
            """,
            
            "events": """
                CREATE TABLE IF NOT EXISTS events (
                    id TEXT PRIMARY KEY,
                    timestamp TIMESTAMP NOT NULL,
                    event_type TEXT NOT NULL,
                    threat_level TEXT NOT NULL,
                    source_ip TEXT NOT NULL,
                    destination_ip TEXT NOT NULL,
                    source_port INTEGER,
                    destination_port INTEGER,
                    protocol TEXT,
                    description TEXT,
                    raw_data TEXT,
                    confidence_score REAL,
                    mitigation_suggested TEXT,
                    tags TEXT,
                    processed BOOLEAN DEFAULT FALSE,
                    acknowledged BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """,
            
            "statistics": """
                CREATE TABLE IF NOT EXISTS statistics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP NOT NULL,
                    metric_name TEXT NOT NULL,
                    metric_value REAL NOT NULL,
                    metadata TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """,
            
            "configuration": """
                CREATE TABLE IF NOT EXISTS configuration (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    description TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_by TEXT
                )
            """
        }
    
    @staticmethod
    def get_schema_v2() -> Dict[str, str]:
        """Schema version 2 - Add indexes and new tables"""
        return {
            "alerts": """
                CREATE TABLE IF NOT EXISTS alerts (
                    id TEXT PRIMARY KEY,
                    event_id TEXT NOT NULL,
                    alert_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    status TEXT DEFAULT 'open',
                    assigned_to TEXT,
                    notes TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    resolved_at TIMESTAMP,
                    FOREIGN KEY (event_id) REFERENCES events(id)
                )
            """,
            
            "threat_intelligence": """
                CREATE TABLE IF NOT EXISTS threat_intelligence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    indicator_type TEXT NOT NULL,
                    indicator_value TEXT NOT NULL,
                    threat_type TEXT,
                    confidence_score REAL,
                    source TEXT,
                    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT TRUE,
                    metadata TEXT,
                    UNIQUE(indicator_type, indicator_value)
                )
            """,
            
            "user_sessions": """
                CREATE TABLE IF NOT EXISTS user_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    source_ip TEXT NOT NULL,
                    user_agent TEXT,
                    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    logout_time TIMESTAMP,
                    session_duration INTEGER,
                    activities_count INTEGER DEFAULT 0,
                    is_suspicious BOOLEAN DEFAULT FALSE
                )
            """,
            
            "network_profiles": """
                CREATE TABLE IF NOT EXISTS network_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_ip TEXT NOT NULL UNIQUE,
                    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    total_connections INTEGER DEFAULT 0,
                    protocols_used TEXT,
                    ports_accessed TEXT,
                    geographic_info TEXT,
                    risk_score REAL DEFAULT 0.0,
                    is_whitelisted BOOLEAN DEFAULT FALSE,
                    is_blacklisted BOOLEAN DEFAULT FALSE,
                    notes TEXT
                )
            """
        }
    
    @staticmethod
    def get_schema_v3() -> Dict[str, str]:
        """Schema version 3 - Add performance indexes and audit tables"""
        return {
            "audit_log": """
                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    table_name TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    record_id TEXT NOT NULL,
                    old_values TEXT,
                    new_values TEXT,
                    changed_by TEXT,
                    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    change_reason TEXT
                )
            """,
            
            "system_health": """
                CREATE TABLE IF NOT EXISTS system_health (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    component TEXT NOT NULL,
                    status TEXT NOT NULL,
                    cpu_usage REAL,
                    memory_usage REAL,
                    disk_usage REAL,
                    network_io TEXT,
                    error_count INTEGER DEFAULT 0,
                    warning_count INTEGER DEFAULT 0,
                    metadata TEXT
                )
            """
        }
    
    @staticmethod
    def get_indexes() -> Dict[str, List[str]]:
        """Performance indexes for all tables"""
        return {
            "events": [
                "CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp)",
                "CREATE INDEX IF NOT EXISTS idx_events_source_ip ON events(source_ip)",
                "CREATE INDEX IF NOT EXISTS idx_events_event_type ON events(event_type)",
                "CREATE INDEX IF NOT EXISTS idx_events_threat_level ON events(threat_level)",
                "CREATE INDEX IF NOT EXISTS idx_events_processed ON events(processed)",
                "CREATE INDEX IF NOT EXISTS idx_events_composite ON events(timestamp, source_ip, event_type)"
            ],
            "alerts": [
                "CREATE INDEX IF NOT EXISTS idx_alerts_event_id ON alerts(event_id)",
                "CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status)",
                "CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity)",
                "CREATE INDEX IF NOT EXISTS idx_alerts_created_at ON alerts(created_at)"
            ],
            "threat_intelligence": [
                "CREATE INDEX IF NOT EXISTS idx_ti_indicator ON threat_intelligence(indicator_type, indicator_value)",
                "CREATE INDEX IF NOT EXISTS idx_ti_threat_type ON threat_intelligence(threat_type)",
                "CREATE INDEX IF NOT EXISTS idx_ti_active ON threat_intelligence(is_active)"
            ],
            "statistics": [
                "CREATE INDEX IF NOT EXISTS idx_stats_timestamp ON statistics(timestamp)",
                "CREATE INDEX IF NOT EXISTS idx_stats_metric ON statistics(metric_name)"
            ],
            "network_profiles": [
                "CREATE INDEX IF NOT EXISTS idx_profiles_source_ip ON network_profiles(source_ip)",
                "CREATE INDEX IF NOT EXISTS idx_profiles_risk_score ON network_profiles(risk_score)",
                "CREATE INDEX IF NOT EXISTS idx_profiles_last_seen ON network_profiles(last_seen)"
            ]
        }

class ConnectionPool:
    """Database connection pool manager"""
    
    def __init__(self, config: DatabaseConfig):
        self.config = config
        self.pool = None
        self._lock = threading.Lock()
        self._initialize_pool()
    
    def _initialize_pool(self):
        """Initialize connection pool based on backend"""
        try:
            if self.config.backend == "postgresql" and POSTGRESQL_AVAILABLE:
                self.pool = psycopg2.pool.ThreadedConnectionPool(
                    minconn=1,
                    maxconn=self.config.pool_size,
                    host=self.config.host,
                    port=self.config.port,
                    database=self.config.database,
                    user=self.config.username,
                    password=self.config.password
                )
                logger.info("PostgreSQL connection pool initialized")
            
            elif self.config.backend == "mysql" and MYSQL_AVAILABLE:
                self.pool = mysql.connector.pooling.MySQLConnectionPool(
                    pool_name="ids_pool",
                    pool_size=self.config.pool_size,
                    host=self.config.host,
                    port=self.config.port,
                    database=self.config.database,
                    user=self.config.username,
                    password=self.config.password
                )
                logger.info("MySQL connection pool initialized")
            
            elif self.config.backend == "sqlite":
                # SQLite doesn't use connection pooling in the traditional sense
                self.pool = None
                logger.info("SQLite backend initialized")
            
            else:
                raise ValueError(f"Unsupported database backend: {self.config.backend}")
        
        except Exception as e:
            logger.error(f"Failed to initialize connection pool: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        """Get database connection from pool"""
        connection = None
        try:
            if self.config.backend == "postgresql" and self.pool:
                connection = self.pool.getconn()
                yield connection
            
            elif self.config.backend == "mysql" and self.pool:
                connection = self.pool.get_connection()
                yield connection
            
            elif self.config.backend == "sqlite":
                connection = sqlite3.connect(
                    self.config.sqlite_path,
                    timeout=self.config.pool_timeout,
                    check_same_thread=False
                )
                
                # Enable WAL mode for better concurrency
                if self.config.enable_wal:
                    connection.execute("PRAGMA journal_mode=WAL")
                
                # Enable foreign keys
                if self.config.enable_foreign_keys:
                    connection.execute("PRAGMA foreign_keys=ON")
                
                connection.row_factory = sqlite3.Row
                yield connection
            
            else:
                raise ValueError(f"No connection available for backend: {self.config.backend}")
        
        except Exception as e:
            logger.error(f"Database connection error: {e}")
            raise
        
        finally:
            if connection:
                try:
                    if self.config.backend == "postgresql" and self.pool:
                        self.pool.putconn(connection)
                    elif self.config.backend == "mysql":
                        connection.close()
                    elif self.config.backend == "sqlite":
                        connection.close()
                except Exception as e:
                    logger.error(f"Error closing connection: {e}")
    
    def close_pool(self):
        """Close connection pool"""
        try:
            if self.pool:
                if self.config.backend == "postgresql":
                    self.pool.closeall()
                elif self.config.backend == "mysql":
                    # MySQL connector pool doesn't have closeall method
                    pass
            logger.info("Connection pool closed")
        except Exception as e:
            logger.error(f"Error closing pool: {e}")

class AdvancedDatabaseManager:
    """Advanced database manager with multi-backend support"""
    
    def __init__(self, config: Optional[DatabaseConfig] = None):
        self.config = config or DatabaseConfig()
        self.pool = ConnectionPool(self.config)
        self.schema = DatabaseSchema()
        
        # Initialize database
        self._initialize_database()
        
        # Performance monitoring
        self.query_stats = {
            'total_queries': 0,
            'slow_queries': 0,
            'failed_queries': 0,
            'avg_query_time': 0.0
        }
        
        logger.info(f"Advanced Database Manager initialized with {self.config.backend} backend")
    
    def _initialize_database(self):
        """Initialize database schema and migrations"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                
                # Create schema version table first
                schema_v1 = self.schema.get_schema_v1()
                cursor.execute(schema_v1["schema_version"])
                
                # Check current schema version
                current_version = self._get_schema_version(cursor)
                
                # Apply migrations
                if current_version < 1:
                    self._apply_schema_v1(cursor)
                    self._set_schema_version(cursor, 1, "Initial schema")
                
                if current_version < 2:
                    self._apply_schema_v2(cursor)
                    self._set_schema_version(cursor, 2, "Added alerts and intelligence tables")
                
                if current_version < 3:
                    self._apply_schema_v3(cursor)
                    self._set_schema_version(cursor, 3, "Added audit and health monitoring")
                
                # Apply indexes
                self._apply_indexes(cursor)
                
                conn.commit()
                logger.info(f"Database schema initialized (version {self.schema.CURRENT_VERSION})")
        
        except Exception as e:
            logger.error(f"Database initialization error: {e}")
            raise
    
    def _get_schema_version(self, cursor) -> int:
        """Get current schema version"""
        try:
            cursor.execute("SELECT MAX(version) FROM schema_version")
            result = cursor.fetchone()
            return result[0] if result and result[0] else 0
        except:
            return 0
    
    def _set_schema_version(self, cursor, version: int, description: str):
        """Set schema version"""
        cursor.execute(
            "INSERT INTO schema_version (version, description) VALUES (?, ?)",
            (version, description)
        )
    
    def _apply_schema_v1(self, cursor):
        """Apply schema version 1"""
        schema = self.schema.get_schema_v1()
        for table_name, sql in schema.items():
            if table_name != "schema_version":  # Already created
                cursor.execute(sql)
        logger.info("Applied schema version 1")
    
    def _apply_schema_v2(self, cursor):
        """Apply schema version 2"""
        schema = self.schema.get_schema_v2()
        for table_name, sql in schema.items():
            cursor.execute(sql)
        logger.info("Applied schema version 2")
    
    def _apply_schema_v3(self, cursor):
        """Apply schema version 3"""
        schema = self.schema.get_schema_v3()
        for table_name, sql in schema.items():
            cursor.execute(sql)
        logger.info("Applied schema version 3")
    
    def _apply_indexes(self, cursor):
        """Apply performance indexes"""
        indexes = self.schema.get_indexes()
        for table_name, index_list in indexes.items():
            for index_sql in index_list:
                try:
                    cursor.execute(index_sql)
                except Exception as e:
                    logger.warning(f"Index creation warning: {e}")
        logger.info("Applied database indexes")
    
    def _execute_query(self, query: str, params: Optional[Tuple] = None, 
                      fetch_one: bool = False, fetch_all: bool = False) -> Any:
        """Execute query with performance monitoring"""
        start_time = time.time()
        
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                result = None
                if fetch_one:
                    result = cursor.fetchone()
                elif fetch_all:
                    result = cursor.fetchall()
                
                conn.commit()
                
                # Update performance stats
                query_time = time.time() - start_time
                self.query_stats['total_queries'] += 1
                self.query_stats['avg_query_time'] = (
                    (self.query_stats['avg_query_time'] * (self.query_stats['total_queries'] - 1) + query_time) /
                    self.query_stats['total_queries']
                )
                
                if query_time > 1.0:  # Slow query threshold
                    self.query_stats['slow_queries'] += 1
                    logger.warning(f"Slow query detected ({query_time:.2f}s): {query[:100]}...")
                
                return result
        
        except Exception as e:
            self.query_stats['failed_queries'] += 1
            logger.error(f"Query execution error: {e}")
            logger.debug(f"Failed query: {query}")
            raise
    
    async def store_event(self, event: SecurityEvent) -> bool:
        """Store security event with enhanced data"""
        try:
            query = """
                INSERT OR REPLACE INTO events 
                (id, timestamp, event_type, threat_level, source_ip, destination_ip,
                 source_port, destination_port, protocol, description, raw_data,
                 confidence_score, mitigation_suggested, tags, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            params = (
                event.id,
                event.timestamp.isoformat(),
                event.event_type.value,
                event.threat_level.value,
                event.source_ip,
                event.destination_ip,
                event.source_port,
                event.destination_port,
                event.protocol,
                event.description,
                json.dumps(event.raw_data),
                event.confidence_score,
                json.dumps(event.mitigation_suggested),
                json.dumps(event.tags),
                datetime.now().isoformat()
            )
            
            self._execute_query(query, params)
            
            # Create alert if high severity
            if event.threat_level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL]:
                await self._create_alert(event)
            
            # Update network profile
            await self._update_network_profile(event)
            
            return True
        
        except Exception as e:
            logger.error(f"Error storing event: {e}")
            return False
    
    async def _create_alert(self, event: SecurityEvent):
        """Create alert for high-severity events"""
        try:
            alert_id = f"alert_{event.id}"
            query = """
                INSERT OR IGNORE INTO alerts 
                (id, event_id, alert_type, severity, status)
                VALUES (?, ?, ?, ?, ?)
            """
            
            params = (
                alert_id,
                event.id,
                event.event_type.value,
                event.threat_level.value,
                'open'
            )
            
            self._execute_query(query, params)
        
        except Exception as e:
            logger.error(f"Error creating alert: {e}")
    
    async def _update_network_profile(self, event: SecurityEvent):
        """Update network profile based on event"""
        try:
            # Check if profile exists
            query = "SELECT id, total_connections, protocols_used, ports_accessed FROM network_profiles WHERE source_ip = ?"
            result = self._execute_query(query, (event.source_ip,), fetch_one=True)
            
            if result:
                # Update existing profile
                profile_id, total_connections, protocols_str, ports_str = result
                
                protocols = set(json.loads(protocols_str or '[]'))
                protocols.add(event.protocol)
                
                ports = set(json.loads(ports_str or '[]'))
                ports.add(event.destination_port)
                
                update_query = """
                    UPDATE network_profiles 
                    SET last_seen = ?, total_connections = ?, protocols_used = ?, ports_accessed = ?
                    WHERE id = ?
                """
                
                params = (
                    datetime.now().isoformat(),
                    total_connections + 1,
                    json.dumps(list(protocols)),
                    json.dumps(list(ports)),
                    profile_id
                )
                
                self._execute_query(update_query, params)
            
            else:
                # Create new profile
                insert_query = """
                    INSERT INTO network_profiles 
                    (source_ip, total_connections, protocols_used, ports_accessed)
                    VALUES (?, ?, ?, ?)
                """
                
                params = (
                    event.source_ip,
                    1,
                    json.dumps([event.protocol]),
                    json.dumps([event.destination_port])
                )
                
                self._execute_query(insert_query, params)
        
        except Exception as e:
            logger.error(f"Error updating network profile: {e}")
    
    async def get_events(self, limit: int = 100, offset: int = 0, 
                        filters: Optional[Dict] = None) -> List[Dict]:
        """Get events with advanced filtering"""
        try:
            query = "SELECT * FROM events"
            params = []
            conditions = []
            
            if filters:
                if 'start_time' in filters:
                    conditions.append("timestamp >= ?")
                    params.append(filters['start_time'])
                
                if 'end_time' in filters:
                    conditions.append("timestamp <= ?")
                    params.append(filters['end_time'])
                
                if 'source_ip' in filters:
                    conditions.append("source_ip = ?")
                    params.append(filters['source_ip'])
                
                if 'event_type' in filters:
                    conditions.append("event_type = ?")
                    params.append(filters['event_type'])
                
                if 'threat_level' in filters:
                    conditions.append("threat_level = ?")
                    params.append(filters['threat_level'])
                
                if 'min_confidence' in filters:
                    conditions.append("confidence_score >= ?")
                    params.append(filters['min_confidence'])
            
            if conditions:
                query += " WHERE " + " AND ".join(conditions)
            
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            results = self._execute_query(query, tuple(params), fetch_all=True)
            
            # Convert to dictionaries
            events = []
            for row in results:
                if self.config.backend == "sqlite":
                    event_dict = dict(row)
                else:
                    # For PostgreSQL/MySQL, convert tuple to dict
                    columns = ['id', 'timestamp', 'event_type', 'threat_level', 'source_ip', 
                              'destination_ip', 'source_port', 'destination_port', 'protocol',
                              'description', 'raw_data', 'confidence_score', 'mitigation_suggested',
                              'tags', 'processed', 'acknowledged', 'created_at', 'updated_at']
                    event_dict = dict(zip(columns, row))
                
                # Parse JSON fields
                for json_field in ['raw_data', 'mitigation_suggested', 'tags']:
                    if event_dict.get(json_field):
                        try:
                            event_dict[json_field] = json.loads(event_dict[json_field])
                        except:
                            pass
                
                events.append(event_dict)
            
            return events
        
        except Exception as e:
            logger.error(f"Error retrieving events: {e}")
            return []
    
    async def get_threat_statistics(self, time_range: str = "24h") -> Dict[str, Any]:
        """Get comprehensive threat statistics"""
        try:
            # Calculate time range
            if time_range == "1h":
                start_time = datetime.now() - timedelta(hours=1)
            elif time_range == "24h":
                start_time = datetime.now() - timedelta(days=1)
            elif time_range == "7d":
                start_time = datetime.now() - timedelta(days=7)
            elif time_range == "30d":
                start_time = datetime.now() - timedelta(days=30)
            else:
                start_time = datetime.now() - timedelta(days=1)
            
            stats = {}
            
            # Total events
            query = "SELECT COUNT(*) FROM events WHERE timestamp >= ?"
            result = self._execute_query(query, (start_time.isoformat(),), fetch_one=True)
            stats['total_events'] = result[0] if result else 0
            
            # Events by threat level
            query = """
                SELECT threat_level, COUNT(*) 
                FROM events 
                WHERE timestamp >= ? 
                GROUP BY threat_level
            """
            results = self._execute_query(query, (start_time.isoformat(),), fetch_all=True)
            stats['by_threat_level'] = {row[0]: row[1] for row in results}
            
            # Events by type
            query = """
                SELECT event_type, COUNT(*) 
                FROM events 
                WHERE timestamp >= ? 
                GROUP BY event_type
            """
            results = self._execute_query(query, (start_time.isoformat(),), fetch_all=True)
            stats['by_event_type'] = {row[0]: row[1] for row in results}
            
            # Top source IPs
            query = """
                SELECT source_ip, COUNT(*) as count
                FROM events 
                WHERE timestamp >= ? 
                GROUP BY source_ip 
                ORDER BY count DESC 
                LIMIT 10
            """
            results = self._execute_query(query, (start_time.isoformat(),), fetch_all=True)
            stats['top_source_ips'] = [{'ip': row[0], 'count': row[1]} for row in results]
            
            # Active alerts
            query = "SELECT COUNT(*) FROM alerts WHERE status = 'open'"
            result = self._execute_query(query, fetch_one=True)
            stats['active_alerts'] = result[0] if result else 0
            
            # Average confidence score
            query = "SELECT AVG(confidence_score) FROM events WHERE timestamp >= ?"
            result = self._execute_query(query, (start_time.isoformat(),), fetch_one=True)
            stats['avg_confidence'] = round(result[0], 3) if result and result[0] else 0.0
            
            return stats
        
        except Exception as e:
            logger.error(f"Error getting threat statistics: {e}")
            return {}
    
    async def cleanup_old_data(self, retention_days: int = 90):
        """Clean up old data based on retention policy"""
        try:
            cutoff_date = datetime.now() - timedelta(days=retention_days)
            
            # Archive old events before deletion
            await self._archive_old_events(cutoff_date)
            
            # Delete old events
            query = "DELETE FROM events WHERE timestamp < ?"
            self._execute_query(query, (cutoff_date.isoformat(),))
            
            # Delete old statistics
            query = "DELETE FROM statistics WHERE timestamp < ?"
            self._execute_query(query, (cutoff_date.isoformat(),))
            
            # Delete resolved alerts older than retention period
            query = "DELETE FROM alerts WHERE status = 'resolved' AND resolved_at < ?"
            self._execute_query(query, (cutoff_date.isoformat(),))
            
            logger.info(f"Cleaned up data older than {retention_days} days")
        
        except Exception as e:
            logger.error(f"Error during data cleanup: {e}")
    
    async def _archive_old_events(self, cutoff_date: datetime):
        """Archive old events to separate storage"""
        try:
            # Create archive table if not exists
            archive_query = """
                CREATE TABLE IF NOT EXISTS events_archive AS 
                SELECT * FROM events WHERE 1=0
            """
            self._execute_query(archive_query)
            
            # Move old events to archive
            move_query = """
                INSERT INTO events_archive 
                SELECT * FROM events WHERE timestamp < ?
            """
            self._execute_query(move_query, (cutoff_date.isoformat(),))
            
            logger.info("Old events archived successfully")
        
        except Exception as e:
            logger.error(f"Error archiving old events: {e}")
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database performance statistics"""
        try:
            stats = {
                'query_stats': self.query_stats.copy(),
                'backend': self.config.backend,
                'pool_size': self.config.pool_size
            }
            
            # Get table sizes
            if self.config.backend == "sqlite":
                with self.pool.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # Get table row counts
                    tables = ['events', 'alerts', 'statistics', 'network_profiles', 'threat_intelligence']
                    table_stats = {}
                    
                    for table in tables:
                        try:
                            cursor.execute(f"SELECT COUNT(*) FROM {table}")
                            count = cursor.fetchone()[0]
                            table_stats[table] = count
                        except:
                            table_stats[table] = 0
                    
                    stats['table_stats'] = table_stats
                    
                    # Get database size
                    db_path = Path(self.config.sqlite_path)
                    if db_path.exists():
                        stats['database_size_mb'] = db_path.stat().st_size / (1024 * 1024)
            
            return stats
        
        except Exception as e:
            logger.error(f"Error getting database stats: {e}")
            return {'error': str(e)}
    
    def close(self):
        """Close database connections"""
        try:
            self.pool.close_pool()
            logger.info("Database manager closed")
        except Exception as e:
            logger.error(f"Error closing database manager: {e}")

# Example usage and testing
async def main():
    """Test the advanced database manager"""
    
    # Test with SQLite
    config = DatabaseConfig(
        backend="sqlite",
        sqlite_path="test_ids_v2.db",
        enable_wal=True
    )
    
    db_manager = AdvancedDatabaseManager(config)
    
    # Create test event
    from ids_core_v2 import SecurityEvent, EventType, ThreatLevel
    import uuid
    
    test_event = SecurityEvent(
        id=str(uuid.uuid4()),
        timestamp=datetime.now(),
        event_type=EventType.PORT_SCAN,
        threat_level=ThreatLevel.HIGH,
        source_ip="192.168.1.100",
        destination_ip="192.168.1.1",
        source_port=12345,
        destination_port=22,
        protocol="TCP",
        description="Test port scan event",
        raw_data={"test": "data"},
        confidence_score=0.9,
        mitigation_suggested=["Block IP"],
        tags=["test", "port_scan"]
    )
    
    # Store event
    success = await db_manager.store_event(test_event)
    print(f"Event stored: {success}")
    
    # Get events
    events = await db_manager.get_events(limit=10)
    print(f"Retrieved {len(events)} events")
    
    # Get statistics
    stats = await db_manager.get_threat_statistics("24h")
    print(f"Threat statistics: {json.dumps(stats, indent=2)}")
    
    # Get database stats
    db_stats = db_manager.get_database_stats()
    print(f"Database stats: {json.dumps(db_stats, indent=2)}")
    
    # Close
    db_manager.close()
    
    print("Database testing completed")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nTesting interrupted by user")
    except Exception as e:
        print(f"Error: {e}")

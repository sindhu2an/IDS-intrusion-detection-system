#!/usr/bin/env python3
"""
Intrusion Detection System - Main Interface
Version 2.0
Complete control interface for all IDS features
"""

import asyncio
import threading
import time
import sys
import os
import signal
from typing import Dict, Any, Optional
import logging
from datetime import datetime
import json

# Import all IDS components
try:
    from ids_core_v2 import IDSCore
    from network_capture_v2 import NetworkCapture
    from ml_detection_v2 import MLAnomalyDetector, ThreatClassifier
    from behavioral_analysis_v2 import BehaviorAnalyzer, AttackPatternDetector
    from web_dashboard_v2 import create_app
    from database_manager_v2 import DatabaseManager
    from data_analytics_v2 import DataAnalytics
except ImportError as e:
    print(f"Error importing IDS components: {e}")
    print("Please ensure all IDS modules are in the same directory")
    sys.exit(1)

class IDSMainInterface:
    """Main interface to control all IDS features"""
    
    def __init__(self):
        self.setup_logging()
        self.components = {}
        self.running = False
        self.web_thread = None
        self.core_task = None
        self.stats = {
            'start_time': None,
            'packets_processed': 0,
            'threats_detected': 0,
            'alerts_generated': 0,
            'uptime': 0
        }
        
    def setup_logging(self):
        """Setup comprehensive logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('ids_main.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger('IDS-Main')
        
    async def initialize_components(self):
        """Initialize all IDS components"""
        try:
            self.logger.info("Initializing IDS components...")
            
            # Initialize database
            self.components['database'] = DatabaseManager()
            await self.components['database'].initialize()
            
            # Initialize core engine
            self.components['core'] = IDSCore()
            
            # Initialize network capture
            self.components['network'] = NetworkCapture()
            
            # Initialize ML components
            self.components['ml_detector'] = MLAnomalyDetector()
            self.components['threat_classifier'] = ThreatClassifier()
            
            # Initialize behavioral analysis
            self.components['behavior_analyzer'] = BehaviorAnalyzer()
            self.components['attack_detector'] = AttackPatternDetector()
            
            # Initialize analytics
            self.components['analytics'] = DataAnalytics(self.components['database'])
            
            self.logger.info("All components initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize components: {e}")
            return False
    
    def start_web_dashboard(self, host='127.0.0.1', port=5000):
        """Start the web dashboard in a separate thread"""
        try:
            from web_dashboard_v2 import create_app
            app = create_app()
            
            def run_flask():
                app.run(host=host, port=port, debug=False, use_reloader=False)
            
            self.web_thread = threading.Thread(target=run_flask, daemon=True)
            self.web_thread.start()
            self.logger.info(f"Web dashboard started at http://{host}:{port}")
            
        except Exception as e:
            self.logger.error(f"Failed to start web dashboard: {e}")
    
    async def start_monitoring(self):
        """Start all monitoring components"""
        try:
            self.logger.info("Starting IDS monitoring...")
            self.running = True
            self.stats['start_time'] = datetime.now()
            
            # Start core engine
            self.core_task = asyncio.create_task(
                self.components['core'].start_monitoring()
            )
            
            # Start network capture
            capture_task = asyncio.create_task(
                self.components['network'].start_capture()
            )
            
            # Start behavioral analysis
            behavior_task = asyncio.create_task(
                self.components['behavior_analyzer'].start_analysis()
            )
            
            self.logger.info("All monitoring components started")
            
            # Run monitoring loop
            await self.monitoring_loop()
            
        except Exception as e:
            self.logger.error(f"Error in monitoring: {e}")
    
    async def monitoring_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                # Update statistics
                self.update_stats()
                
                # Process any pending events
                await self.process_events()
                
                # Sleep for a short interval
                await asyncio.sleep(1)
                
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(5)
    
    def update_stats(self):
        """Update system statistics"""
        if self.stats['start_time']:
            self.stats['uptime'] = (datetime.now() - self.stats['start_time']).total_seconds()
    
    async def process_events(self):
        """Process any pending events from components"""
        try:
            # Check for new threats from ML detector
            if hasattr(self.components['ml_detector'], 'get_recent_detections'):
                detections = await self.components['ml_detector'].get_recent_detections()
                for detection in detections:
                    self.stats['threats_detected'] += 1
                    await self.handle_threat_detection(detection)
            
            # Check for behavioral anomalies
            if hasattr(self.components['behavior_analyzer'], 'get_anomalies'):
                anomalies = await self.components['behavior_analyzer'].get_anomalies()
                for anomaly in anomalies:
                    await self.handle_behavioral_anomaly(anomaly)
                    
        except Exception as e:
            self.logger.error(f"Error processing events: {e}")
    
    async def handle_threat_detection(self, detection):
        """Handle a threat detection"""
        self.logger.warning(f"Threat detected: {detection}")
        self.stats['alerts_generated'] += 1
        
        # Store in database
        if 'database' in self.components:
            await self.components['database'].store_alert({
                'type': 'threat_detection',
                'data': detection,
                'timestamp': datetime.now(),
                'severity': detection.get('severity', 'medium')
            })
    
    async def handle_behavioral_anomaly(self, anomaly):
        """Handle a behavioral anomaly"""
        self.logger.warning(f"Behavioral anomaly detected: {anomaly}")
        self.stats['alerts_generated'] += 1
    
    def stop_monitoring(self):
        """Stop all monitoring components"""
        self.logger.info("Stopping IDS monitoring...")
        self.running = False
        
        if self.core_task:
            self.core_task.cancel()
        
        # Stop other components
        for name, component in self.components.items():
            if hasattr(component, 'stop'):
                try:
                    component.stop()
                except Exception as e:
                    self.logger.error(f"Error stopping {name}: {e}")
    
    def print_status(self):
        """Print current system status"""
        print("\n" + "="*60)
        print("INTRUSION DETECTION SYSTEM - STATUS")
        print("="*60)
        print(f"Status: {'RUNNING' if self.running else 'STOPPED'}")
        print(f"Uptime: {self.stats['uptime']:.0f} seconds")
        print(f"Packets Processed: {self.stats['packets_processed']}")
        print(f"Threats Detected: {self.stats['threats_detected']}")
        print(f"Alerts Generated: {self.stats['alerts_generated']}")
        print(f"Components Loaded: {len(self.components)}")
        print("="*60)
        
        if self.web_thread and self.web_thread.is_alive():
            print("Web Dashboard: http://127.0.0.1:5000")
        print()
    
    def print_menu(self):
        """Print the main menu"""
        print("\n" + "="*60)
        print("INTRUSION DETECTION SYSTEM - MAIN INTERFACE")
        print("="*60)
        print("1. Start IDS Monitoring")
        print("2. Stop IDS Monitoring")
        print("3. Start Web Dashboard")
        print("4. Show System Status")
        print("5. Run Analytics Report")
        print("6. Test Detection Algorithms")
        print("7. View Recent Alerts")
        print("8. System Configuration")
        print("9. Export Data")
        print("0. Exit")
        print("="*60)
    
    async def run_analytics_report(self):
        """Generate and display analytics report"""
        try:
            if 'analytics' not in self.components:
                print("Analytics component not available")
                return
                
            print("\nGenerating analytics report...")
            report = await self.components['analytics'].generate_security_report()
            
            print("\n" + "="*50)
            print("SECURITY ANALYTICS REPORT")
            print("="*50)
            print(f"Report generated: {datetime.now()}")
            print(f"Total events: {report.get('total_events', 0)}")
            print(f"High severity alerts: {report.get('high_severity', 0)}")
            print(f"Top threat types: {report.get('top_threats', [])}")
            print("="*50)
            
        except Exception as e:
            print(f"Error generating report: {e}")
    
    async def test_detection_algorithms(self):
        """Test the detection algorithms"""
        try:
            print("\nTesting detection algorithms...")
            
            # Test ML detector
            if 'ml_detector' in self.components:
                print("Testing ML anomaly detector...")
                # Add test data here
                
            # Test behavioral analyzer
            if 'behavior_analyzer' in self.components:
                print("Testing behavioral analyzer...")
                # Add test data here
                
            print("Detection algorithm tests completed")
            
        except Exception as e:
            print(f"Error testing algorithms: {e}")
    
    async def view_recent_alerts(self):
        """View recent alerts from database"""
        try:
            if 'database' not in self.components:
                print("Database component not available")
                return
                
            alerts = await self.components['database'].get_recent_alerts(limit=10)
            
            print("\n" + "="*50)
            print("RECENT ALERTS")
            print("="*50)
            
            for alert in alerts:
                print(f"Time: {alert.get('timestamp', 'Unknown')}")
                print(f"Type: {alert.get('type', 'Unknown')}")
                print(f"Severity: {alert.get('severity', 'Unknown')}")
                print(f"Details: {alert.get('data', {})}")
                print("-" * 30)
                
        except Exception as e:
            print(f"Error viewing alerts: {e}")
    
    def signal_handler(self, signum, frame):
        """Handle system signals"""
        print(f"\nReceived signal {signum}, shutting down...")
        self.stop_monitoring()
        sys.exit(0)

async def main():
    """Main function to run the IDS interface"""
    ids = IDSMainInterface()
    
    # Setup signal handlers
    signal.signal(signal.SIGINT, ids.signal_handler)
    signal.signal(signal.SIGTERM, ids.signal_handler)
    
    # Initialize components
    if not await ids.initialize_components():
        print("Failed to initialize IDS components")
        return
    
    print("IDS Main Interface Started Successfully!")
    
    # Interactive menu loop
    while True:
        try:
            ids.print_menu()
            choice = input("Enter your choice (0-9): ").strip()
            
            if choice == '1':
                if not ids.running:
                    print("Starting IDS monitoring...")
                    # Start monitoring in background
                    monitoring_task = asyncio.create_task(ids.start_monitoring())
                    await asyncio.sleep(2)  # Give it time to start
                else:
                    print("IDS monitoring is already running")
                    
            elif choice == '2':
                if ids.running:
                    ids.stop_monitoring()
                    print("IDS monitoring stopped")
                else:
                    print("IDS monitoring is not running")
                    
            elif choice == '3':
                if not ids.web_thread or not ids.web_thread.is_alive():
                    ids.start_web_dashboard()
                    print("Web dashboard started at http://127.0.0.1:5000")
                else:
                    print("Web dashboard is already running")
                    
            elif choice == '4':
                ids.print_status()
                
            elif choice == '5':
                await ids.run_analytics_report()
                
            elif choice == '6':
                await ids.test_detection_algorithms()
                
            elif choice == '7':
                await ids.view_recent_alerts()
                
            elif choice == '8':
                print("Configuration management - Feature coming soon!")
                
            elif choice == '9':
                print("Data export - Feature coming soon!")
                
            elif choice == '0':
                print("Shutting down IDS...")
                ids.stop_monitoring()
                break
                
            else:
                print("Invalid choice. Please try again.")
                
            input("\nPress Enter to continue...")
            
        except KeyboardInterrupt:
            print("\nShutting down...")
            ids.stop_monitoring()
            break
        except Exception as e:
            print(f"Error: {e}")
            input("Press Enter to continue...")

if __name__ == "__main__":
    print("Starting Intrusion Detection System v2.0...")
    print("Loading components...")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nGoodbye!")
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)

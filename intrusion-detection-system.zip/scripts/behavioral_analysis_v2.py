#!/usr/bin/env python3
"""
Behavioral Analysis Module v2.0
Advanced behavioral pattern detection and user activity analysis
"""

import asyncio
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set, Tuple
import logging
import json
from collections import defaultdict, deque
from dataclasses import dataclass
import uuid

from ids_core_v2 import SecurityEvent, EventType, ThreatLevel

logger = logging.getLogger(__name__)

@dataclass
class UserBehavior:
    """User behavior profile"""
    user_id: str
    typical_login_times: List[int]  # Hours of day
    typical_locations: Set[str]  # IP addresses
    typical_activities: Dict[str, int]  # Activity counts
    session_durations: List[float]  # Minutes
    data_transfer_patterns: Dict[str, float]  # Upload/download patterns
    last_updated: datetime

@dataclass
class NetworkBehavior:
    """Network behavior profile"""
    source_ip: str
    connection_patterns: Dict[str, int]  # Protocol -> count
    port_usage: Dict[int, int]  # Port -> count
    traffic_volume: Dict[str, float]  # Time period -> bytes
    geographic_patterns: Set[str]  # Destination countries/regions
    protocol_timing: Dict[str, List[int]]  # Protocol -> hours of activity
    last_seen: datetime

class BehaviorProfiler:
    """Build and maintain behavioral profiles"""
    
    def __init__(self, profile_window_days: int = 30):
        self.profile_window_days = profile_window_days
        self.user_profiles: Dict[str, UserBehavior] = {}
        self.network_profiles: Dict[str, NetworkBehavior] = {}
        self.activity_history = deque(maxlen=10000)
        
        # Behavioral thresholds
        self.anomaly_thresholds = {
            'login_time_deviation': 3.0,  # Standard deviations
            'location_anomaly': 0.1,  # Probability threshold
            'activity_spike': 5.0,  # Multiplier of normal activity
            'session_duration_anomaly': 3.0,  # Standard deviations
            'data_transfer_anomaly': 10.0  # Multiplier of normal transfer
        }
    
    async def update_user_profile(self, user_id: str, activity_data: Dict):
        """Update user behavioral profile"""
        try:
            if user_id not in self.user_profiles:
                self.user_profiles[user_id] = UserBehavior(
                    user_id=user_id,
                    typical_login_times=[],
                    typical_locations=set(),
                    typical_activities=defaultdict(int),
                    session_durations=[],
                    data_transfer_patterns=defaultdict(float),
                    last_updated=datetime.now()
                )
            
            profile = self.user_profiles[user_id]
            
            # Update login times
            if 'login_time' in activity_data:
                login_hour = activity_data['login_time'].hour
                profile.typical_login_times.append(login_hour)
                # Keep only recent login times
                if len(profile.typical_login_times) > 100:
                    profile.typical_login_times = profile.typical_login_times[-100:]
            
            # Update locations
            if 'source_ip' in activity_data:
                profile.typical_locations.add(activity_data['source_ip'])
            
            # Update activities
            if 'activity_type' in activity_data:
                profile.typical_activities[activity_data['activity_type']] += 1
            
            # Update session duration
            if 'session_duration' in activity_data:
                profile.session_durations.append(activity_data['session_duration'])
                if len(profile.session_durations) > 100:
                    profile.session_durations = profile.session_durations[-100:]
            
            # Update data transfer patterns
            if 'bytes_transferred' in activity_data:
                time_period = activity_data.get('time_period', 'unknown')
                profile.data_transfer_patterns[time_period] += activity_data['bytes_transferred']
            
            profile.last_updated = datetime.now()
            
        except Exception as e:
            logger.error(f"Error updating user profile: {e}")
    
    async def update_network_profile(self, source_ip: str, network_data: Dict):
        """Update network behavioral profile"""
        try:
            if source_ip not in self.network_profiles:
                self.network_profiles[source_ip] = NetworkBehavior(
                    source_ip=source_ip,
                    connection_patterns=defaultdict(int),
                    port_usage=defaultdict(int),
                    traffic_volume=defaultdict(float),
                    geographic_patterns=set(),
                    protocol_timing=defaultdict(list),
                    last_seen=datetime.now()
                )
            
            profile = self.network_profiles[source_ip]
            
            # Update connection patterns
            if 'protocol' in network_data:
                profile.connection_patterns[network_data['protocol']] += 1
            
            # Update port usage
            if 'destination_port' in network_data:
                profile.port_usage[network_data['destination_port']] += 1
            
            # Update traffic volume
            if 'bytes_transferred' in network_data:
                hour = datetime.now().hour
                profile.traffic_volume[f"hour_{hour}"] += network_data['bytes_transferred']
            
            # Update geographic patterns
            if 'destination_country' in network_data:
                profile.geographic_patterns.add(network_data['destination_country'])
            
            # Update protocol timing
            if 'protocol' in network_data:
                current_hour = datetime.now().hour
                profile.protocol_timing[network_data['protocol']].append(current_hour)
                # Keep only recent timing data
                if len(profile.protocol_timing[network_data['protocol']]) > 100:
                    profile.protocol_timing[network_data['protocol']] = \
                        profile.protocol_timing[network_data['protocol']][-100:]
            
            profile.last_seen = datetime.now()
            
        except Exception as e:
            logger.error(f"Error updating network profile: {e}")
    
    async def detect_user_anomalies(self, user_id: str, current_activity: Dict) -> List[SecurityEvent]:
        """Detect anomalies in user behavior"""
        events = []
        
        if user_id not in self.user_profiles:
            return events
        
        profile = self.user_profiles[user_id]
        
        try:
            # Check login time anomaly
            if 'login_time' in current_activity and profile.typical_login_times:
                login_hour = current_activity['login_time'].hour
                typical_hours = np.array(profile.typical_login_times)
                
                if len(typical_hours) > 5:  # Need sufficient data
                    mean_hour = np.mean(typical_hours)
                    std_hour = np.std(typical_hours)
                    
                    if std_hour > 0:
                        deviation = abs(login_hour - mean_hour) / std_hour
                        
                        if deviation > self.anomaly_thresholds['login_time_deviation']:
                            events.append(self._create_user_anomaly_event(
                                user_id, current_activity,
                                "Unusual login time detected",
                                f"Login at {login_hour}:00, typical range: {mean_hour-std_hour:.1f}-{mean_hour+std_hour:.1f}",
                                ThreatLevel.MEDIUM
                            ))
            
            # Check location anomaly
            if 'source_ip' in current_activity:
                source_ip = current_activity['source_ip']
                if source_ip not in profile.typical_locations and len(profile.typical_locations) > 0:
                    events.append(self._create_user_anomaly_event(
                        user_id, current_activity,
                        "Login from unusual location",
                        f"New IP address: {source_ip}",
                        ThreatLevel.HIGH
                    ))
            
            # Check activity spike
            if 'activity_type' in current_activity:
                activity_type = current_activity['activity_type']
                current_count = current_activity.get('activity_count', 1)
                typical_count = profile.typical_activities.get(activity_type, 0)
                
                if typical_count > 0 and current_count > typical_count * self.anomaly_thresholds['activity_spike']:
                    events.append(self._create_user_anomaly_event(
                        user_id, current_activity,
                        "Unusual activity spike detected",
                        f"{activity_type}: {current_count} vs typical {typical_count}",
                        ThreatLevel.HIGH
                    ))
            
            # Check session duration anomaly
            if 'session_duration' in current_activity and profile.session_durations:
                current_duration = current_activity['session_duration']
                durations = np.array(profile.session_durations)
                
                if len(durations) > 5:
                    mean_duration = np.mean(durations)
                    std_duration = np.std(durations)
                    
                    if std_duration > 0:
                        deviation = abs(current_duration - mean_duration) / std_duration
                        
                        if deviation > self.anomaly_thresholds['session_duration_anomaly']:
                            events.append(self._create_user_anomaly_event(
                                user_id, current_activity,
                                "Unusual session duration",
                                f"Duration: {current_duration:.1f}min, typical: {mean_duration:.1f}±{std_duration:.1f}min",
                                ThreatLevel.MEDIUM
                            ))
        
        except Exception as e:
            logger.error(f"Error detecting user anomalies: {e}")
        
        return events
    
    async def detect_network_anomalies(self, source_ip: str, current_data: Dict) -> List[SecurityEvent]:
        """Detect anomalies in network behavior"""
        events = []
        
        if source_ip not in self.network_profiles:
            return events
        
        profile = self.network_profiles[source_ip]
        
        try:
            # Check for unusual protocol usage
            if 'protocol' in current_data:
                protocol = current_data['protocol']
                typical_count = profile.connection_patterns.get(protocol, 0)
                current_count = current_data.get('connection_count', 1)
                
                # Check if this is a new protocol for this IP
                if typical_count == 0 and len(profile.connection_patterns) > 5:
                    events.append(self._create_network_anomaly_event(
                        source_ip, current_data,
                        "New protocol usage detected",
                        f"First time using {protocol}",
                        ThreatLevel.MEDIUM
                    ))
            
            # Check for unusual port access
            if 'destination_port' in current_data:
                port = current_data['destination_port']
                if port not in profile.port_usage and len(profile.port_usage) > 10:
                    # Check if it's a commonly attacked port
                    high_risk_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 3389]
                    threat_level = ThreatLevel.HIGH if port in high_risk_ports else ThreatLevel.MEDIUM
                    
                    events.append(self._create_network_anomaly_event(
                        source_ip, current_data,
                        "Access to new port detected",
                        f"First access to port {port}",
                        threat_level
                    ))
            
            # Check for unusual traffic volume
            if 'bytes_transferred' in current_data:
                current_bytes = current_data['bytes_transferred']
                current_hour = datetime.now().hour
                typical_bytes = profile.traffic_volume.get(f"hour_{current_hour}", 0)
                
                if typical_bytes > 0 and current_bytes > typical_bytes * self.anomaly_thresholds['data_transfer_anomaly']:
                    events.append(self._create_network_anomaly_event(
                        source_ip, current_data,
                        "Unusual data transfer volume",
                        f"Transfer: {current_bytes} bytes, typical: {typical_bytes} bytes",
                        ThreatLevel.HIGH
                    ))
            
            # Check for unusual timing patterns
            if 'protocol' in current_data:
                protocol = current_data['protocol']
                current_hour = datetime.now().hour
                typical_hours = profile.protocol_timing.get(protocol, [])
                
                if len(typical_hours) > 10:
                    hour_counts = np.bincount(typical_hours, minlength=24)
                    if hour_counts[current_hour] == 0:  # Never seen at this hour
                        events.append(self._create_network_anomaly_event(
                            source_ip, current_data,
                            "Unusual timing for protocol usage",
                            f"{protocol} usage at {current_hour}:00 (first time)",
                            ThreatLevel.MEDIUM
                        ))
        
        except Exception as e:
            logger.error(f"Error detecting network anomalies: {e}")
        
        return events
    
    def _create_user_anomaly_event(self, user_id: str, activity_data: Dict, 
                                 description: str, details: str, 
                                 threat_level: ThreatLevel) -> SecurityEvent:
        """Create user anomaly security event"""
        return SecurityEvent(
            id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            event_type=EventType.POLICY_VIOLATION,
            threat_level=threat_level,
            source_ip=activity_data.get('source_ip', 'unknown'),
            destination_ip=activity_data.get('destination_ip', 'internal'),
            source_port=activity_data.get('source_port', 0),
            destination_port=activity_data.get('destination_port', 0),
            protocol=activity_data.get('protocol', 'unknown'),
            description=description,
            raw_data={
                'user_id': user_id,
                'anomaly_details': details,
                'activity_data': activity_data,
                'detection_method': 'behavioral_analysis'
            },
            confidence_score=0.8,
            mitigation_suggested=[
                "Verify user identity",
                "Review user permissions",
                "Monitor user activity closely"
            ],
            tags=["behavioral", "user_anomaly", "authentication"]
        )
    
    def _create_network_anomaly_event(self, source_ip: str, network_data: Dict,
                                    description: str, details: str,
                                    threat_level: ThreatLevel) -> SecurityEvent:
        """Create network anomaly security event"""
        return SecurityEvent(
            id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            event_type=EventType.NETWORK_ANOMALY,
            threat_level=threat_level,
            source_ip=source_ip,
            destination_ip=network_data.get('destination_ip', 'unknown'),
            source_port=network_data.get('source_port', 0),
            destination_port=network_data.get('destination_port', 0),
            protocol=network_data.get('protocol', 'unknown'),
            description=description,
            raw_data={
                'anomaly_details': details,
                'network_data': network_data,
                'detection_method': 'behavioral_analysis'
            },
            confidence_score=0.75,
            mitigation_suggested=[
                "Investigate network activity",
                "Check for potential reconnaissance",
                "Monitor source IP behavior"
            ],
            tags=["behavioral", "network_anomaly", "pattern_analysis"]
        )

class AttackPatternDetector:
    """Detect complex attack patterns and campaigns"""
    
    def __init__(self):
        self.attack_sequences = {
            'apt_pattern': [
                EventType.PORT_SCAN,
                EventType.BRUTE_FORCE,
                EventType.SYSTEM_COMPROMISE,
                EventType.POLICY_VIOLATION
            ],
            'data_exfiltration': [
                EventType.SYSTEM_COMPROMISE,
                EventType.POLICY_VIOLATION,
                EventType.NETWORK_ANOMALY
            ],
            'lateral_movement': [
                EventType.SYSTEM_COMPROMISE,
                EventType.NETWORK_ANOMALY,
                EventType.SYSTEM_COMPROMISE
            ]
        }
        
        self.event_history = deque(maxlen=1000)
        self.attack_campaigns = {}
    
    async def analyze_attack_patterns(self, new_event: SecurityEvent) -> List[SecurityEvent]:
        """Analyze for complex attack patterns"""
        self.event_history.append(new_event)
        detected_patterns = []
        
        # Check for each attack pattern
        for pattern_name, sequence in self.attack_sequences.items():
            pattern_events = await self._detect_sequence_pattern(sequence, pattern_name)
            if pattern_events:
                detected_patterns.extend(pattern_events)
        
        # Check for coordinated attacks
        coordinated_events = await self._detect_coordinated_attacks()
        if coordinated_events:
            detected_patterns.extend(coordinated_events)
        
        return detected_patterns
    
    async def _detect_sequence_pattern(self, sequence: List[EventType], 
                                     pattern_name: str) -> List[SecurityEvent]:
        """Detect specific attack sequence patterns"""
        events = []
        
        # Look for the sequence in recent events
        recent_events = list(self.event_history)[-50:]  # Last 50 events
        
        # Group events by source IP
        ip_events = defaultdict(list)
        for event in recent_events:
            ip_events[event.source_ip].append(event)
        
        # Check each IP for the pattern
        for source_ip, ip_event_list in ip_events.items():
            if len(ip_event_list) < len(sequence):
                continue
            
            # Sort by timestamp
            ip_event_list.sort(key=lambda x: x.timestamp)
            
            # Look for the sequence
            sequence_matches = []
            sequence_index = 0
            
            for event in ip_event_list:
                if sequence_index < len(sequence) and event.event_type == sequence[sequence_index]:
                    sequence_matches.append(event)
                    sequence_index += 1
                    
                    if sequence_index == len(sequence):
                        # Found complete sequence
                        time_span = (sequence_matches[-1].timestamp - sequence_matches[0].timestamp).total_seconds()
                        
                        # Only consider if sequence occurred within reasonable timeframe
                        if time_span <= 3600:  # 1 hour
                            events.append(SecurityEvent(
                                id=str(uuid.uuid4()),
                                timestamp=datetime.now(),
                                event_type=EventType.SYSTEM_COMPROMISE,
                                threat_level=ThreatLevel.CRITICAL,
                                source_ip=source_ip,
                                destination_ip=sequence_matches[0].destination_ip,
                                source_port=sequence_matches[0].source_port,
                                destination_port=sequence_matches[0].destination_port,
                                protocol=sequence_matches[0].protocol,
                                description=f"Attack pattern detected: {pattern_name}",
                                raw_data={
                                    'pattern_name': pattern_name,
                                    'sequence_events': [e.id for e in sequence_matches],
                                    'time_span_seconds': time_span,
                                    'attack_progression': [e.event_type.value for e in sequence_matches]
                                },
                                confidence_score=0.9,
                                mitigation_suggested=[
                                    "Immediately isolate source IP",
                                    "Investigate all affected systems",
                                    "Review security logs for additional indicators",
                                    "Implement emergency response procedures"
                                ],
                                tags=["attack_pattern", pattern_name, "multi_stage", "critical"]
                            ))
                        break
        
        return events
    
    async def _detect_coordinated_attacks(self) -> List[SecurityEvent]:
        """Detect coordinated attacks from multiple sources"""
        events = []
        
        # Look for multiple IPs targeting same destination within short timeframe
        recent_events = list(self.event_history)[-100:]
        
        # Group by destination and time window
        time_windows = defaultdict(lambda: defaultdict(list))
        
        for event in recent_events:
            # 5-minute time windows
            time_window = int(event.timestamp.timestamp() // 300) * 300
            time_windows[time_window][event.destination_ip].append(event)
        
        for time_window, destinations in time_windows.items():
            for dest_ip, dest_events in destinations.items():
                # Check for multiple source IPs
                source_ips = set(event.source_ip for event in dest_events)
                
                if len(source_ips) >= 3 and len(dest_events) >= 10:  # Coordinated threshold
                    # Check for similar attack types
                    event_types = [event.event_type for event in dest_events]
                    unique_types = set(event_types)
                    
                    if len(unique_types) <= 3:  # Similar attack types
                        events.append(SecurityEvent(
                            id=str(uuid.uuid4()),
                            timestamp=datetime.now(),
                            event_type=EventType.MALICIOUS_TRAFFIC,
                            threat_level=ThreatLevel.CRITICAL,
                            source_ip=f"multiple_sources_{len(source_ips)}",
                            destination_ip=dest_ip,
                            source_port=0,
                            destination_port=dest_events[0].destination_port,
                            protocol="multiple",
                            description=f"Coordinated attack detected: {len(source_ips)} sources targeting {dest_ip}",
                            raw_data={
                                'attack_sources': list(source_ips),
                                'event_count': len(dest_events),
                                'attack_types': list(unique_types),
                                'time_window': time_window,
                                'coordination_score': len(source_ips) * len(dest_events) / 10
                            },
                            confidence_score=0.95,
                            mitigation_suggested=[
                                "Block all attacking source IPs",
                                "Implement emergency DDoS protection",
                                "Isolate target system if possible",
                                "Contact incident response team"
                            ],
                            tags=["coordinated_attack", "multiple_sources", "ddos", "critical"]
                        ))
        
        return events

# Example usage and testing
async def main():
    """Test the behavioral analysis modules"""
    profiler = BehaviorProfiler()
    pattern_detector = AttackPatternDetector()
    
    # Simulate user activity
    user_activity = {
        'login_time': datetime.now(),
        'source_ip': '192.168.1.100',
        'activity_type': 'file_access',
        'session_duration': 45.0,
        'bytes_transferred': 1024000
    }
    
    await profiler.update_user_profile('user123', user_activity)
    
    # Simulate network activity
    network_data = {
        'protocol': 'TCP',
        'destination_port': 443,
        'bytes_transferred': 2048000,
        'destination_country': 'US'
    }
    
    await profiler.update_network_profile('192.168.1.100', network_data)
    
    # Test anomaly detection
    anomalous_activity = {
        'login_time': datetime.now().replace(hour=3),  # Unusual time
        'source_ip': '10.0.0.50',  # New location
        'activity_type': 'file_access',
        'session_duration': 300.0  # Long session
    }
    
    user_anomalies = await profiler.detect_user_anomalies('user123', anomalous_activity)
    for anomaly in user_anomalies:
        print(f"User anomaly: {anomaly.description}")
    
    network_anomalies = await profiler.detect_network_anomalies('192.168.1.100', {
        'protocol': 'ICMP',  # New protocol
        'destination_port': 22,  # New port
        'bytes_transferred': 50000000  # Large transfer
    })
    
    for anomaly in network_anomalies:
        print(f"Network anomaly: {anomaly.description}")
    
    print("Behavioral analysis testing completed")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")

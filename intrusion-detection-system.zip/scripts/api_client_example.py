#!/usr/bin/env python3
"""
IDS REST API Client Example
Demonstrates how to interact with the IDS REST API
"""

import requests
import json
from datetime import datetime
import time

class IDSAPIClient:
    """Client for interacting with IDS REST API"""
    
    def __init__(self, base_url="http://127.0.0.1:8000", username="admin", password="admin123"):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.token = None
        self.headers = {"Content-Type": "application/json"}
    
    def authenticate(self):
        """Authenticate with the API and get access token"""
        try:
            response = requests.post(
                f"{self.base_url}/auth/login",
                json={"username": self.username, "password": self.password}
            )
            
            if response.status_code == 200:
                data = response.json()
                self.token = data["access_token"]
                self.headers["Authorization"] = f"Bearer {self.token}"
                print("Authentication successful!")
                return True
            else:
                print(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            print(f"Authentication error: {e}")
            return False
    
    def get_system_status(self):
        """Get system status"""
        try:
            response = requests.get(
                f"{self.base_url}/system/status",
                headers=self.headers
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Failed to get status: {response.text}")
                return None
                
        except Exception as e:
            print(f"Error getting status: {e}")
            return None
    
    def start_monitoring(self):
        """Start IDS monitoring"""
        try:
            response = requests.post(
                f"{self.base_url}/system/start",
                headers=self.headers
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"Start monitoring: {data['message']}")
                return data['success']
            else:
                print(f"Failed to start monitoring: {response.text}")
                return False
                
        except Exception as e:
            print(f"Error starting monitoring: {e}")
            return False
    
    def stop_monitoring(self):
        """Stop IDS monitoring"""
        try:
            response = requests.post(
                f"{self.base_url}/system/stop",
                headers=self.headers
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"Stop monitoring: {data['message']}")
                return data['success']
            else:
                print(f"Failed to stop monitoring: {response.text}")
                return False
                
        except Exception as e:
            print(f"Error stopping monitoring: {e}")
            return False
    
    def get_alerts(self, limit=10, severity=None):
        """Get recent alerts"""
        try:
            params = {"limit": limit}
            if severity:
                params["severity"] = severity
            
            response = requests.get(
                f"{self.base_url}/alerts",
                headers=self.headers,
                params=params
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Failed to get alerts: {response.text}")
                return []
                
        except Exception as e:
            print(f"Error getting alerts: {e}")
            return []
    
    def get_analytics_report(self):
        """Get analytics report"""
        try:
            response = requests.get(
                f"{self.base_url}/analytics/report",
                headers=self.headers
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Failed to get analytics: {response.text}")
                return None
                
        except Exception as e:
            print(f"Error getting analytics: {e}")
            return None
    
    def get_detection_rules(self):
        """Get detection rules"""
        try:
            response = requests.get(
                f"{self.base_url}/rules",
                headers=self.headers
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Failed to get rules: {response.text}")
                return []
                
        except Exception as e:
            print(f"Error getting rules: {e}")
            return []

def main():
    """Example usage of the IDS API client"""
    print("IDS REST API Client Example")
    print("=" * 40)
    
    # Create client and authenticate
    client = IDSAPIClient()
    
    if not client.authenticate():
        print("Failed to authenticate. Exiting.")
        return
    
    # Get system status
    print("\n1. Getting system status...")
    status = client.get_system_status()
    if status:
        print(f"Status: {status['status']}")
        print(f"Uptime: {status['uptime']:.0f} seconds")
        print(f"Components: {status['components_loaded']}")
        print(f"Threats detected: {status['threats_detected']}")
    
    # Start monitoring
    print("\n2. Starting monitoring...")
    client.start_monitoring()
    
    # Wait a moment
    time.sleep(2)
    
    # Get updated status
    print("\n3. Getting updated status...")
    status = client.get_system_status()
    if status:
        print(f"Monitoring active: {status['monitoring_active']}")
    
    # Get alerts
    print("\n4. Getting recent alerts...")
    alerts = client.get_alerts(limit=5)
    print(f"Found {len(alerts)} alerts")
    for alert in alerts[:3]:  # Show first 3
        print(f"  - {alert['type']} ({alert['severity']}) at {alert['timestamp']}")
    
    # Get detection rules
    print("\n5. Getting detection rules...")
    rules = client.get_detection_rules()
    print(f"Found {len(rules)} detection rules")
    for rule in rules:
        print(f"  - {rule['name']} ({rule['severity']}) - {'Enabled' if rule['enabled'] else 'Disabled'}")
    
    # Get analytics report
    print("\n6. Getting analytics report...")
    report = client.get_analytics_report()
    if report:
        print(f"Total events: {report.get('total_events', 0)}")
        print(f"High severity: {report.get('high_severity', 0)}")
    
    # Stop monitoring
    print("\n7. Stopping monitoring...")
    client.stop_monitoring()
    
    print("\nAPI client example completed!")

if __name__ == "__main__":
    main()

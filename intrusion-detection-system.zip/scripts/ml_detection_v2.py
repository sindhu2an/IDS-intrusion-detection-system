#!/usr/bin/env python3
"""
Machine Learning Detection Module v2.0
Advanced ML-based anomaly detection and threat classification
"""

import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import logging
import json
import pickle
from pathlib import Path
from dataclasses import dataclass
import uuid

# ML imports
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.cluster import DBSCAN
import joblib

from ids_core_v2 import SecurityEvent, EventType, ThreatLevel

logger = logging.getLogger(__name__)

@dataclass
class MLFeatures:
    """Feature vector for ML analysis"""
    packet_size: float
    packets_per_second: float
    bytes_per_second: float
    unique_ports: int
    connection_duration: float
    protocol_distribution: Dict[str, float]
    time_of_day: float
    day_of_week: int
    source_entropy: float
    destination_entropy: float
    payload_entropy: float
    tcp_flags_ratio: Dict[str, float]

class FeatureExtractor:
    """Extract features from network traffic for ML analysis"""
    
    def __init__(self, time_window: int = 60):
        self.time_window = time_window  # seconds
        self.traffic_history = []
        self.connection_tracker = {}
    
    def extract_features(self, packets: List[Dict]) -> MLFeatures:
        """Extract ML features from packet data"""
        if not packets:
            return self._empty_features()
        
        # Basic statistics
        packet_sizes = [p.get('packet_size', 0) for p in packets]
        total_bytes = sum(packet_sizes)
        total_packets = len(packets)
        
        # Time-based features
        time_span = self._calculate_time_span(packets)
        packets_per_second = total_packets / max(time_span, 1)
        bytes_per_second = total_bytes / max(time_span, 1)
        
        # Port diversity
        unique_ports = len(set(p.get('destination_port', 0) for p in packets))
        
        # Protocol distribution
        protocols = [p.get('protocol', 'unknown') for p in packets]
        protocol_counts = pd.Series(protocols).value_counts(normalize=True)
        protocol_distribution = protocol_counts.to_dict()
        
        # Temporal features
        first_packet_time = datetime.fromisoformat(packets[0].get('timestamp', datetime.now().isoformat()))
        time_of_day = first_packet_time.hour + first_packet_time.minute / 60.0
        day_of_week = first_packet_time.weekday()
        
        # Entropy calculations
        source_ips = [p.get('source_ip', '') for p in packets]
        dest_ips = [p.get('destination_ip', '') for p in packets]
        
        source_entropy = self._calculate_entropy(source_ips)
        destination_entropy = self._calculate_entropy(dest_ips)
        
        # Payload entropy (if available)
        payloads = [p.get('payload', b'') for p in packets if p.get('payload')]
        payload_entropy = self._calculate_payload_entropy(payloads)
        
        # TCP flags analysis
        tcp_flags_ratio = self._analyze_tcp_flags(packets)
        
        return MLFeatures(
            packet_size=np.mean(packet_sizes) if packet_sizes else 0,
            packets_per_second=packets_per_second,
            bytes_per_second=bytes_per_second,
            unique_ports=unique_ports,
            connection_duration=time_span,
            protocol_distribution=protocol_distribution,
            time_of_day=time_of_day,
            day_of_week=day_of_week,
            source_entropy=source_entropy,
            destination_entropy=destination_entropy,
            payload_entropy=payload_entropy,
            tcp_flags_ratio=tcp_flags_ratio
        )
    
    def _empty_features(self) -> MLFeatures:
        """Return empty feature set"""
        return MLFeatures(
            packet_size=0, packets_per_second=0, bytes_per_second=0,
            unique_ports=0, connection_duration=0, protocol_distribution={},
            time_of_day=0, day_of_week=0, source_entropy=0,
            destination_entropy=0, payload_entropy=0, tcp_flags_ratio={}
        )
    
    def _calculate_time_span(self, packets: List[Dict]) -> float:
        """Calculate time span of packet sequence"""
        if len(packets) < 2:
            return 1.0
        
        timestamps = [datetime.fromisoformat(p.get('timestamp', datetime.now().isoformat())) for p in packets]
        return (max(timestamps) - min(timestamps)).total_seconds()
    
    def _calculate_entropy(self, values: List[str]) -> float:
        """Calculate Shannon entropy of string values"""
        if not values:
            return 0.0
        
        value_counts = pd.Series(values).value_counts(normalize=True)
        return -sum(p * np.log2(p) for p in value_counts if p > 0)
    
    def _calculate_payload_entropy(self, payloads: List[bytes]) -> float:
        """Calculate entropy of payload data"""
        if not payloads:
            return 0.0
        
        # Combine all payloads
        combined = b''.join(payloads)
        if not combined:
            return 0.0
        
        # Calculate byte frequency
        byte_counts = np.bincount(combined, minlength=256)
        probabilities = byte_counts / len(combined)
        
        # Calculate entropy
        entropy = -sum(p * np.log2(p) for p in probabilities if p > 0)
        return entropy / 8.0  # Normalize to 0-1 range
    
    def _analyze_tcp_flags(self, packets: List[Dict]) -> Dict[str, float]:
        """Analyze TCP flags distribution"""
        tcp_packets = [p for p in packets if p.get('protocol') == 'TCP']
        if not tcp_packets:
            return {}
        
        flag_counts = {'SYN': 0, 'ACK': 0, 'FIN': 0, 'RST': 0, 'PSH': 0, 'URG': 0}
        
        for packet in tcp_packets:
            flags = packet.get('flags', {})
            for flag in flag_counts:
                if flags.get(flag, False):
                    flag_counts[flag] += 1
        
        total = len(tcp_packets)
        return {flag: count / total for flag, count in flag_counts.items()}

class AnomalyDetector:
    """ML-based anomaly detection system"""
    
    def __init__(self, model_path: str = "models/anomaly_detector.pkl"):
        self.model_path = Path(model_path)
        self.model_path.parent.mkdir(exist_ok=True)
        
        self.isolation_forest = IsolationForest(
            contamination=0.1,
            random_state=42,
            n_estimators=100
        )
        self.scaler = StandardScaler()
        self.feature_extractor = FeatureExtractor()
        
        self.is_trained = False
        self.training_data = []
        self.anomaly_threshold = -0.5
        
        # Load existing model if available
        self._load_model()
    
    def _load_model(self):
        """Load pre-trained model"""
        try:
            if self.model_path.exists():
                with open(self.model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    self.isolation_forest = model_data['model']
                    self.scaler = model_data['scaler']
                    self.is_trained = model_data['is_trained']
                    self.anomaly_threshold = model_data.get('threshold', -0.5)
                
                logger.info("Loaded pre-trained anomaly detection model")
        except Exception as e:
            logger.warning(f"Could not load model: {e}")
    
    def _save_model(self):
        """Save trained model"""
        try:
            model_data = {
                'model': self.isolation_forest,
                'scaler': self.scaler,
                'is_trained': self.is_trained,
                'threshold': self.anomaly_threshold
            }
            
            with open(self.model_path, 'wb') as f:
                pickle.dump(model_data, f)
            
            logger.info("Saved anomaly detection model")
        except Exception as e:
            logger.error(f"Could not save model: {e}")
    
    def train(self, training_packets: List[List[Dict]]):
        """Train the anomaly detection model"""
        logger.info("Training anomaly detection model...")
        
        # Extract features from training data
        feature_vectors = []
        for packet_sequence in training_packets:
            features = self.feature_extractor.extract_features(packet_sequence)
            feature_vector = self._features_to_vector(features)
            feature_vectors.append(feature_vector)
        
        if not feature_vectors:
            logger.warning("No training data available")
            return
        
        # Convert to numpy array
        X = np.array(feature_vectors)
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train isolation forest
        self.isolation_forest.fit(X_scaled)
        self.is_trained = True
        
        # Calculate threshold based on training data
        scores = self.isolation_forest.decision_function(X_scaled)
        self.anomaly_threshold = np.percentile(scores, 10)  # Bottom 10% as anomalies
        
        # Save model
        self._save_model()
        
        logger.info(f"Anomaly detection model trained on {len(feature_vectors)} samples")
    
    async def detect_anomaly(self, packets: List[Dict]) -> Optional[SecurityEvent]:
        """Detect anomalies in packet sequence"""
        if not self.is_trained:
            # Use simple heuristics if model not trained
            return await self._heuristic_detection(packets)
        
        try:
            # Extract features
            features = self.feature_extractor.extract_features(packets)
            feature_vector = self._features_to_vector(features)
            
            # Scale features
            X_scaled = self.scaler.transform([feature_vector])
            
            # Get anomaly score
            anomaly_score = self.isolation_forest.decision_function(X_scaled)[0]
            is_anomaly = self.isolation_forest.predict(X_scaled)[0] == -1
            
            if is_anomaly and anomaly_score < self.anomaly_threshold:
                # Determine threat level based on anomaly score
                if anomaly_score < -0.8:
                    threat_level = ThreatLevel.CRITICAL
                elif anomaly_score < -0.6:
                    threat_level = ThreatLevel.HIGH
                else:
                    threat_level = ThreatLevel.MEDIUM
                
                return SecurityEvent(
                    id=str(uuid.uuid4()),
                    timestamp=datetime.now(),
                    event_type=EventType.NETWORK_ANOMALY,
                    threat_level=threat_level,
                    source_ip=packets[0].get('source_ip', 'unknown'),
                    destination_ip=packets[0].get('destination_ip', 'unknown'),
                    source_port=packets[0].get('source_port', 0),
                    destination_port=packets[0].get('destination_port', 0),
                    protocol=packets[0].get('protocol', 'unknown'),
                    description=f"ML-detected network anomaly (score: {anomaly_score:.3f})",
                    raw_data={
                        'anomaly_score': anomaly_score,
                        'feature_analysis': self._analyze_anomalous_features(features),
                        'packet_count': len(packets),
                        'confidence_score': abs(anomaly_score)
                    },
                    confidence_score=min(0.95, abs(anomaly_score)),
                    mitigation_suggested=[
                        "Investigate traffic pattern",
                        "Check for potential attack",
                        "Monitor source IP behavior"
                    ],
                    tags=["ml_detection", "anomaly", "behavioral"]
                )
        
        except Exception as e:
            logger.error(f"ML anomaly detection error: {e}")
        
        return None
    
    async def _heuristic_detection(self, packets: List[Dict]) -> Optional[SecurityEvent]:
        """Simple heuristic-based detection when ML model unavailable"""
        if not packets:
            return None
        
        # Simple heuristics
        packet_count = len(packets)
        unique_ports = len(set(p.get('destination_port', 0) for p in packets))
        
        # Port scan detection
        if unique_ports > 10 and packet_count > 20:
            return SecurityEvent(
                id=str(uuid.uuid4()),
                timestamp=datetime.now(),
                event_type=EventType.PORT_SCAN,
                threat_level=ThreatLevel.HIGH,
                source_ip=packets[0].get('source_ip', 'unknown'),
                destination_ip=packets[0].get('destination_ip', 'unknown'),
                source_port=packets[0].get('source_port', 0),
                destination_port=packets[0].get('destination_port', 0),
                protocol=packets[0].get('protocol', 'unknown'),
                description=f"Heuristic-detected port scan ({unique_ports} ports)",
                raw_data={
                    'unique_ports': unique_ports,
                    'packet_count': packet_count,
                    'detection_method': 'heuristic'
                },
                confidence_score=0.7,
                mitigation_suggested=[
                    "Block source IP",
                    "Monitor for further scanning"
                ],
                tags=["heuristic", "port_scan", "reconnaissance"]
            )
        
        return None
    
    def _features_to_vector(self, features: MLFeatures) -> List[float]:
        """Convert features to numerical vector"""
        vector = [
            features.packet_size,
            features.packets_per_second,
            features.bytes_per_second,
            features.unique_ports,
            features.connection_duration,
            features.time_of_day,
            features.day_of_week,
            features.source_entropy,
            features.destination_entropy,
            features.payload_entropy
        ]
        
        # Add protocol distribution (top 5 protocols)
        common_protocols = ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS']
        for protocol in common_protocols:
            vector.append(features.protocol_distribution.get(protocol, 0.0))
        
        # Add TCP flags ratios
        common_flags = ['SYN', 'ACK', 'FIN', 'RST']
        for flag in common_flags:
            vector.append(features.tcp_flags_ratio.get(flag, 0.0))
        
        return vector
    
    def _analyze_anomalous_features(self, features: MLFeatures) -> Dict[str, str]:
        """Analyze which features contributed to anomaly detection"""
        analysis = {}
        
        if features.packets_per_second > 100:
            analysis['high_packet_rate'] = f"{features.packets_per_second:.1f} packets/sec"
        
        if features.unique_ports > 20:
            analysis['port_diversity'] = f"{features.unique_ports} unique ports"
        
        if features.source_entropy > 4:
            analysis['high_source_entropy'] = f"Entropy: {features.source_entropy:.2f}"
        
        if features.payload_entropy < 0.1:
            analysis['low_payload_entropy'] = "Potentially encrypted/compressed"
        
        return analysis

class ThreatClassifier:
    """ML-based threat classification system"""
    
    def __init__(self, model_path: str = "models/threat_classifier.pkl"):
        self.model_path = Path(model_path)
        self.model_path.parent.mkdir(exist_ok=True)
        
        self.classifier = RandomForestClassifier(
            n_estimators=100,
            random_state=42,
            max_depth=10
        )
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.feature_extractor = FeatureExtractor()
        
        self.is_trained = False
        self.threat_categories = [
            'benign', 'port_scan', 'dos', 'brute_force', 
            'malware', 'data_exfiltration', 'lateral_movement'
        ]
        
        self._load_model()
    
    def _load_model(self):
        """Load pre-trained classifier"""
        try:
            if self.model_path.exists():
                model_data = joblib.load(self.model_path)
                self.classifier = model_data['classifier']
                self.scaler = model_data['scaler']
                self.label_encoder = model_data['label_encoder']
                self.is_trained = model_data['is_trained']
                
                logger.info("Loaded pre-trained threat classifier")
        except Exception as e:
            logger.warning(f"Could not load classifier: {e}")
    
    def _save_model(self):
        """Save trained classifier"""
        try:
            model_data = {
                'classifier': self.classifier,
                'scaler': self.scaler,
                'label_encoder': self.label_encoder,
                'is_trained': self.is_trained
            }
            
            joblib.dump(model_data, self.model_path)
            logger.info("Saved threat classifier model")
        except Exception as e:
            logger.error(f"Could not save classifier: {e}")
    
    async def classify_threat(self, packets: List[Dict]) -> Optional[SecurityEvent]:
        """Classify threat type from packet sequence"""
        if not self.is_trained:
            return None
        
        try:
            # Extract features
            features = self.feature_extractor.extract_features(packets)
            feature_vector = self._features_to_vector(features)
            
            # Scale features
            X_scaled = self.scaler.transform([feature_vector])
            
            # Predict threat category
            prediction = self.classifier.predict(X_scaled)[0]
            probabilities = self.classifier.predict_proba(X_scaled)[0]
            confidence = max(probabilities)
            
            threat_category = self.label_encoder.inverse_transform([prediction])[0]
            
            # Only report if confidence is high and not benign
            if confidence > 0.7 and threat_category != 'benign':
                event_type = self._map_threat_to_event_type(threat_category)
                threat_level = self._determine_threat_level(threat_category, confidence)
                
                return SecurityEvent(
                    id=str(uuid.uuid4()),
                    timestamp=datetime.now(),
                    event_type=event_type,
                    threat_level=threat_level,
                    source_ip=packets[0].get('source_ip', 'unknown'),
                    destination_ip=packets[0].get('destination_ip', 'unknown'),
                    source_port=packets[0].get('source_port', 0),
                    destination_port=packets[0].get('destination_port', 0),
                    protocol=packets[0].get('protocol', 'unknown'),
                    description=f"ML-classified threat: {threat_category}",
                    raw_data={
                        'threat_category': threat_category,
                        'confidence': confidence,
                        'all_probabilities': dict(zip(self.threat_categories, probabilities.tolist())),
                        'packet_count': len(packets)
                    },
                    confidence_score=confidence,
                    mitigation_suggested=self._get_mitigation_for_threat(threat_category),
                    tags=["ml_classification", threat_category, "automated"]
                )
        
        except Exception as e:
            logger.error(f"Threat classification error: {e}")
        
        return None
    
    def _features_to_vector(self, features: MLFeatures) -> List[float]:
        """Convert features to numerical vector for classification"""
        # Same as anomaly detector but with additional features
        vector = [
            features.packet_size,
            features.packets_per_second,
            features.bytes_per_second,
            features.unique_ports,
            features.connection_duration,
            features.time_of_day,
            features.day_of_week,
            features.source_entropy,
            features.destination_entropy,
            features.payload_entropy
        ]
        
        # Protocol distribution
        common_protocols = ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS']
        for protocol in common_protocols:
            vector.append(features.protocol_distribution.get(protocol, 0.0))
        
        # TCP flags
        common_flags = ['SYN', 'ACK', 'FIN', 'RST', 'PSH', 'URG']
        for flag in common_flags:
            vector.append(features.tcp_flags_ratio.get(flag, 0.0))
        
        return vector
    
    def _map_threat_to_event_type(self, threat_category: str) -> EventType:
        """Map threat category to event type"""
        mapping = {
            'port_scan': EventType.PORT_SCAN,
            'dos': EventType.MALICIOUS_TRAFFIC,
            'brute_force': EventType.BRUTE_FORCE,
            'malware': EventType.MALWARE_DETECTED,
            'data_exfiltration': EventType.POLICY_VIOLATION,
            'lateral_movement': EventType.SYSTEM_COMPROMISE
        }
        return mapping.get(threat_category, EventType.NETWORK_ANOMALY)
    
    def _determine_threat_level(self, threat_category: str, confidence: float) -> ThreatLevel:
        """Determine threat level based on category and confidence"""
        high_severity = ['malware', 'data_exfiltration', 'lateral_movement']
        medium_severity = ['brute_force', 'dos']
        
        if threat_category in high_severity:
            return ThreatLevel.CRITICAL if confidence > 0.9 else ThreatLevel.HIGH
        elif threat_category in medium_severity:
            return ThreatLevel.HIGH if confidence > 0.9 else ThreatLevel.MEDIUM
        else:
            return ThreatLevel.MEDIUM if confidence > 0.8 else ThreatLevel.LOW
    
    def _get_mitigation_for_threat(self, threat_category: str) -> List[str]:
        """Get mitigation suggestions for threat category"""
        mitigations = {
            'port_scan': [
                "Block source IP",
                "Enable port scan detection",
                "Monitor for follow-up attacks"
            ],
            'dos': [
                "Implement rate limiting",
                "Block attacking IPs",
                "Scale infrastructure"
            ],
            'brute_force': [
                "Lock affected accounts",
                "Implement account lockout policies",
                "Enable MFA"
            ],
            'malware': [
                "Quarantine affected systems",
                "Run full antivirus scan",
                "Update security signatures"
            ],
            'data_exfiltration': [
                "Block data transfer",
                "Investigate data access",
                "Review access controls"
            ],
            'lateral_movement': [
                "Isolate affected systems",
                "Review network segmentation",
                "Audit privileged accounts"
            ]
        }
        return mitigations.get(threat_category, ["Investigate further", "Monitor activity"])

# Example usage and testing
async def main():
    """Test the ML detection modules"""
    # Initialize detectors
    anomaly_detector = AnomalyDetector()
    threat_classifier = ThreatClassifier()
    
    # Generate sample packet data for testing
    sample_packets = [
        {
            'timestamp': datetime.now().isoformat(),
            'source_ip': '192.168.1.100',
            'destination_ip': '192.168.1.1',
            'source_port': 12345,
            'destination_port': 22,
            'protocol': 'TCP',
            'packet_size': 64,
            'flags': {'SYN': True, 'ACK': False},
            'payload': b'test payload'
        }
        for _ in range(50)  # Simulate 50 packets
    ]
    
    # Test anomaly detection
    anomaly_event = await anomaly_detector.detect_anomaly(sample_packets)
    if anomaly_event:
        print(f"Anomaly detected: {anomaly_event.description}")
        print(f"Confidence: {anomaly_event.confidence_score}")
    
    # Test threat classification
    threat_event = await threat_classifier.classify_threat(sample_packets)
    if threat_event:
        print(f"Threat classified: {threat_event.description}")
        print(f"Threat level: {threat_event.threat_level.value}")
    
    print("ML detection testing completed")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")

#!/usr/bin/env python3
"""
IDS Quick Start Script
Simple launcher for the Intrusion Detection System
"""

import subprocess
import sys
import os
import time

def check_requirements():
    """Check if required packages are installed"""
    required_packages = [
        'scapy', 'flask', 'flask-socketio', 'scikit-learn',
        'numpy', 'pandas', 'matplotlib', 'seaborn'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("Missing required packages:")
        for package in missing_packages:
            print(f"  - {package}")
        print("\nInstall them with:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    return True

def main():
    """Quick start the IDS system"""
    print("="*60)
    print("INTRUSION DETECTION SYSTEM v2.0 - QUICK START")
    print("="*60)
    
    # Check requirements
    print("Checking requirements...")
    if not check_requirements():
        print("Please install missing packages and try again.")
        return
    
    print("All requirements satisfied!")
    
    # Check if running as root (needed for packet capture)
    if os.geteuid() != 0:
        print("\nWARNING: Not running as root.")
        print("Some features (packet capture) may not work properly.")
        print("Consider running with: sudo python3 quick_start.py")
        
        choice = input("\nContinue anyway? (y/n): ").lower()
        if choice != 'y':
            return
    
    print("\nStarting IDS Main Interface...")
    time.sleep(1)
    
    try:
        # Run the main interface
        subprocess.run([sys.executable, 'ids_main_interface.py'])
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error starting IDS: {e}")

if __name__ == "__main__":
    main()

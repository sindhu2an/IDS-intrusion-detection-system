#!/usr/bin/env python3
"""
Simplified Intrusion Detection System
A streamlined IDS with web interface for monitoring network security
"""

import os
import json
import time
import threading
import sqlite3
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import psutil
import random
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SimpleIDS:
    def __init__(self):
        self.app = Flask(__name__, template_folder='templates', static_folder='static')
        self.app.config['SECRET_KEY'] = 'ids_secret_key_2024'
        self.socketio = SocketIO(self.app, cors_allowed_origins="*")
        
        self.monitoring = False
        self.alerts = []
        self.network_stats = {
            'packets_captured': 0,
            'threats_detected': 0,
            'connections_active': 0,
            'bandwidth_usage': 0
        }
        
        # Initialize database
        self.init_database()
        
        # Setup routes
        self.setup_routes()
        
        # Start background monitoring
        self.monitor_thread = None

    def init_database(self):
        """Initialize SQLite database for storing events and alerts"""
        try:
            self.conn = sqlite3.connect('ids_data.db', check_same_thread=False)
            cursor = self.conn.cursor()
            
            # Create tables
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    type TEXT NOT NULL,
                    source_ip TEXT,
                    destination_ip TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'active'
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS network_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    source_ip TEXT,
                    destination_ip TEXT,
                    port INTEGER,
                    protocol TEXT,
                    details TEXT
                )
            ''')
            
            self.conn.commit()
            logger.info("Database initialized successfully")
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")

    def setup_routes(self):
        """Setup Flask routes"""
        
        @self.app.route('/')
        def dashboard():
            return render_template('dashboard.html')
        
        @self.app.route('/api/stats')
        def get_stats():
            # Get system stats
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            network = psutil.net_io_counters()
            
            # Update network stats with real system data
            self.network_stats.update({
                'cpu_usage': cpu_percent,
                'memory_usage': memory.percent,
                'bytes_sent': network.bytes_sent,
                'bytes_recv': network.bytes_recv,
                'connections_active': len(psutil.net_connections())
            })
            
            return jsonify(self.network_stats)
        
        @self.app.route('/api/alerts')
        def get_alerts():
            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    SELECT * FROM alerts 
                    ORDER BY timestamp DESC 
                    LIMIT 50
                ''')
                alerts = []
                for row in cursor.fetchall():
                    alerts.append({
                        'id': row[0],
                        'timestamp': row[1],
                        'severity': row[2],
                        'type': row[3],
                        'source_ip': row[4],
                        'destination_ip': row[5],
                        'description': row[6],
                        'status': row[7]
                    })
                return jsonify(alerts)
            except Exception as e:
                logger.error(f"Error fetching alerts: {e}")
                return jsonify([])
        
        @self.app.route('/api/monitoring/<action>', methods=['POST'])
        def control_monitoring(action):
            if action == 'start':
                self.start_monitoring()
                return jsonify({'status': 'started', 'message': 'Monitoring started successfully'})
            elif action == 'stop':
                self.stop_monitoring()
                return jsonify({'status': 'stopped', 'message': 'Monitoring stopped'})
            else:
                return jsonify({'error': 'Invalid action'}), 400
        
        @self.socketio.on('connect')
        def handle_connect():
            logger.info('Client connected to WebSocket')
            emit('status', {'monitoring': self.monitoring})
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            logger.info('Client disconnected from WebSocket')

    def start_monitoring(self):
        """Start network monitoring"""
        if not self.monitoring:
            self.monitoring = True
            self.monitor_thread = threading.Thread(target=self.monitor_network, daemon=True)
            self.monitor_thread.start()
            logger.info("Network monitoring started")

    def stop_monitoring(self):
        """Stop network monitoring"""
        self.monitoring = False
        logger.info("Network monitoring stopped")

    def monitor_network(self):
        """Main monitoring loop - simulates network monitoring"""
        logger.info("Starting network monitoring loop")
        
        while self.monitoring:
            try:
                # Simulate network monitoring
                self.simulate_network_activity()
                
                # Emit real-time updates
                self.socketio.emit('stats_update', self.network_stats)
                
                # Check for threats (simulation)
                if random.random() < 0.1:  # 10% chance of detecting a threat
                    self.generate_alert()
                
                time.sleep(2)  # Update every 2 seconds
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)

    def simulate_network_activity(self):
        """Simulate network activity and update stats"""
        # Simulate packet capture
        self.network_stats['packets_captured'] += random.randint(10, 100)
        
        # Simulate bandwidth usage (in MB/s)
        self.network_stats['bandwidth_usage'] = random.uniform(0.5, 10.0)
        
        # Get real system connections
        try:
            connections = psutil.net_connections()
            self.network_stats['connections_active'] = len([c for c in connections if c.status == 'ESTABLISHED'])
        except:
            self.network_stats['connections_active'] = random.randint(5, 50)

    def generate_alert(self):
        """Generate a simulated security alert"""
        alert_types = [
            ('Port Scan', 'medium', 'Suspicious port scanning activity detected'),
            ('Malware', 'high', 'Potential malware communication detected'),
            ('DDoS', 'critical', 'Distributed Denial of Service attack detected'),
            ('Brute Force', 'high', 'Multiple failed login attempts detected'),
            ('Suspicious Traffic', 'low', 'Unusual network traffic pattern detected')
        ]
        
        alert_type, severity, description = random.choice(alert_types)
        source_ip = f"192.168.1.{random.randint(1, 254)}"
        dest_ip = f"10.0.0.{random.randint(1, 254)}"
        
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                INSERT INTO alerts (timestamp, severity, type, source_ip, destination_ip, description)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (datetime.now().isoformat(), severity, alert_type, source_ip, dest_ip, description))
            
            self.conn.commit()
            self.network_stats['threats_detected'] += 1
            
            # Emit alert to connected clients
            alert_data = {
                'timestamp': datetime.now().isoformat(),
                'severity': severity,
                'type': alert_type,
                'source_ip': source_ip,
                'destination_ip': dest_ip,
                'description': description
            }
            
            self.socketio.emit('new_alert', alert_data)
            logger.info(f"Alert generated: {alert_type} - {severity}")
            
        except Exception as e:
            logger.error(f"Error generating alert: {e}")

    def run(self, host='127.0.0.1', port=5000, debug=False):
        """Run the IDS web application"""
        logger.info(f"Starting IDS web interface on http://{host}:{port}")
        self.socketio.run(self.app, host=host, port=port, debug=debug)

if __name__ == '__main__':
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    # Initialize and run IDS
    ids = SimpleIDS()
    
    print("=" * 60)
    print("🛡️  SIMPLE INTRUSION DETECTION SYSTEM")
    print("=" * 60)
    print("📊 Web Dashboard: http://127.0.0.1:5000")
    print("🔍 Features: Real-time monitoring, Alert management")
    print("⚡ Status: Ready to start monitoring")
    print("=" * 60)
    
    try:
        ids.run(host='127.0.0.1', port=5000, debug=False)
    except KeyboardInterrupt:
        print("\n🛑 Shutting down IDS...")
        ids.stop_monitoring()

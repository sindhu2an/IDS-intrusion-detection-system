#!/usr/bin/env python3
"""
Advanced Logging System for Intrusion Detection System
Provides structured logging, log rotation, and log analysis capabilities
"""

import os
import json
import gzip
import logging
import logging.handlers
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from collections import defaultdict, deque
import threading
import time
import re

class StructuredFormatter(logging.Formatter):
    """Custom formatter for structured logging"""
    
    def format(self, record):
        # Create structured log entry
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add extra fields if present
        if hasattr(record, 'extra_fields'):
            log_entry.update(record.extra_fields)
        
        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_entry)

class SecurityLogger:
    """Security-focused logger with additional context"""
    
    def __init__(self, name: str, log_dir: str = "logs"):
        self.name = name
        self.log_dir = log_dir
        self.logger = logging.getLogger(name)
        
        # Ensure log directory exists
        os.makedirs(log_dir, exist_ok=True)
        
        # Setup handlers
        self.setup_handlers()
    
    def setup_handlers(self):
        """Setup logging handlers"""
        self.logger.setLevel(logging.DEBUG)
        
        # Remove existing handlers
        for handler in self.logger.handlers[:]:
            self.logger.removeHandler(handler)
        
        # Console handler with simple format
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(console_formatter)
        self.logger.addHandler(console_handler)
        
        # File handler with structured format
        log_file = os.path.join(self.log_dir, f"{self.name}.log")
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=10
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(StructuredFormatter())
        self.logger.addHandler(file_handler)
        
        # Security events handler (separate file)
        security_log_file = os.path.join(self.log_dir, f"{self.name}_security.log")
        security_handler = logging.handlers.RotatingFileHandler(
            security_log_file,
            maxBytes=50*1024*1024,  # 50MB
            backupCount=20
        )
        security_handler.setLevel(logging.WARNING)
        security_handler.setFormatter(StructuredFormatter())
        self.logger.addHandler(security_handler)
    
    def log_security_event(self, event_type: str, description: str, 
                          severity: str = "medium", **kwargs):
        """Log security event with additional context"""
        extra_fields = {
            'event_type': event_type,
            'severity': severity,
            'source_ip': kwargs.get('source_ip'),
            'dest_ip': kwargs.get('dest_ip'),
            'protocol': kwargs.get('protocol'),
            'user': kwargs.get('user'),
            'session_id': kwargs.get('session_id'),
            'additional_data': {k: v for k, v in kwargs.items() 
                              if k not in ['source_ip', 'dest_ip', 'protocol', 'user', 'session_id']}
        }
        
        # Create log record with extra fields
        record = self.logger.makeRecord(
            self.logger.name,
            logging.WARNING,
            __file__,
            0,
            description,
            (),
            None
        )
        record.extra_fields = extra_fields
        
        self.logger.handle(record)
    
    def log_packet_analysis(self, packet_data: Dict, detections: List[Dict]):
        """Log packet analysis results"""
        extra_fields = {
            'event_type': 'packet_analysis',
            'packet_info': {
                'src_ip': packet_data.get('ip', {}).get('src_ip'),
                'dest_ip': packet_data.get('ip', {}).get('dest_ip'),
                'protocol': packet_data.get('protocol'),
                'size': packet_data.get('size')
            },
            'detections_count': len(detections),
            'detections': detections
        }
        
        if detections:
            severity = 'high' if any(d.get('severity') == 'critical' for d in detections) else 'medium'
            message = f"Packet analysis detected {len(detections)} threats"
            level = logging.WARNING
        else:
            severity = 'low'
            message = "Packet analysis completed - no threats detected"
            level = logging.DEBUG
        
        record = self.logger.makeRecord(
            self.logger.name,
            level,
            __file__,
            0,
            message,
            (),
            None
        )
        record.extra_fields = extra_fields
        
        self.logger.handle(record)
    
    def log_system_event(self, event_type: str, message: str, **kwargs):
        """Log system event"""
        extra_fields = {
            'event_type': event_type,
            'system_info': kwargs
        }
        
        record = self.logger.makeRecord(
            self.logger.name,
            logging.INFO,
            __file__,
            0,
            message,
            (),
            None
        )
        record.extra_fields = extra_fields
        
        self.logger.handle(record)

class LogAnalyzer:
    """Log analysis and pattern detection"""
    
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        self.patterns = []
        self.analysis_cache = {}
        self.logger = logging.getLogger(__name__)
        
        # Load analysis patterns
        self.load_analysis_patterns()
    
    def load_analysis_patterns(self):
        """Load log analysis patterns"""
        self.patterns = [
            {
                'name': 'Failed Login Attempts',
                'pattern': r'failed.*login|authentication.*failed|invalid.*credentials',
                'category': 'authentication',
                'severity': 'medium'
            },
            {
                'name': 'Privilege Escalation',
                'pattern': r'privilege.*escalation|sudo|su\s|admin.*access',
                'category': 'privilege_escalation',
                'severity': 'high'
            },
            {
                'name': 'File Access Violations',
                'pattern': r'access.*denied|permission.*denied|unauthorized.*access',
                'category': 'access_violation',
                'severity': 'medium'
            },
            {
                'name': 'Network Anomalies',
                'pattern': r'connection.*refused|timeout|network.*error',
                'category': 'network',
                'severity': 'low'
            },
            {
                'name': 'Malware Indicators',
                'pattern': r'malware|virus|trojan|backdoor|suspicious.*executable',
                'category': 'malware',
                'severity': 'critical'
            }
        ]
    
    def analyze_log_file(self, log_file: str, hours_back: int = 24) -> Dict:
        """Analyze log file for patterns"""
        if not os.path.exists(log_file):
            return {'error': f'Log file {log_file} not found'}
        
        analysis_results = {
            'file': log_file,
            'analysis_time': datetime.now().isoformat(),
            'time_range_hours': hours_back,
            'total_entries': 0,
            'pattern_matches': defaultdict(list),
            'timeline': defaultdict(int),
            'severity_distribution': defaultdict(int),
            'top_sources': defaultdict(int),
            'error_summary': []
        }
        
        cutoff_time = datetime.now() - timedelta(hours=hours_back)
        
        try:
            with open(log_file, 'r') as f:
                for line_num, line in enumerate(f, 1):
                    try:
                        # Try to parse as JSON (structured log)
                        if line.strip().startswith('{'):
                            log_entry = json.loads(line.strip())
                            entry_time = datetime.fromisoformat(log_entry.get('timestamp', ''))
                            
                            # Skip old entries
                            if entry_time < cutoff_time:
                                continue
                            
                            analysis_results['total_entries'] += 1
                            
                            # Analyze structured entry
                            self._analyze_structured_entry(log_entry, analysis_results)
                            
                        else:
                            # Plain text log entry
                            analysis_results['total_entries'] += 1
                            self._analyze_text_entry(line, analysis_results)
                            
                    except json.JSONDecodeError:
                        # Plain text entry
                        analysis_results['total_entries'] += 1
                        self._analyze_text_entry(line, analysis_results)
                    except Exception as e:
                        analysis_results['error_summary'].append(f"Line {line_num}: {str(e)}")
                        
        except Exception as e:
            analysis_results['error_summary'].append(f"File reading error: {str(e)}")
        
        # Convert defaultdicts to regular dicts
        analysis_results['pattern_matches'] = dict(analysis_results['pattern_matches'])
        analysis_results['timeline'] = dict(analysis_results['timeline'])
        analysis_results['severity_distribution'] = dict(analysis_results['severity_distribution'])
        analysis_results['top_sources'] = dict(analysis_results['top_sources'])
        
        return analysis_results
    
    def _analyze_structured_entry(self, log_entry: Dict, results: Dict):
        """Analyze structured log entry"""
        message = log_entry.get('message', '')
        timestamp = log_entry.get('timestamp', '')
        level = log_entry.get('level', 'INFO')
        
        # Update timeline (hourly buckets)
        try:
            entry_time = datetime.fromisoformat(timestamp)
            hour_bucket = entry_time.strftime('%Y-%m-%d %H:00')
            results['timeline'][hour_bucket] += 1
        except:
            pass
        
        # Update severity distribution
        results['severity_distribution'][level] += 1
        
        # Check for source IP
        extra_fields = log_entry.get('extra_fields', {})
        source_ip = extra_fields.get('source_ip')
        if source_ip:
            results['top_sources'][source_ip] += 1
        
        # Apply pattern matching
        self._apply_patterns(message, results, timestamp)
    
    def _analyze_text_entry(self, line: str, results: Dict):
        """Analyze plain text log entry"""
        # Extract timestamp if possible
        timestamp_match = re.search(r'\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}', line)
        timestamp = timestamp_match.group(0) if timestamp_match else ''
        
        # Apply pattern matching
        self._apply_patterns(line, results, timestamp)
    
    def _apply_patterns(self, text: str, results: Dict, timestamp: str):
        """Apply analysis patterns to text"""
        for pattern in self.patterns:
            if re.search(pattern['pattern'], text, re.IGNORECASE):
                match_info = {
                    'timestamp': timestamp,
                    'text': text[:200],  # Truncate long lines
                    'severity': pattern['severity'],
                    'category': pattern['category']
                }
                results['pattern_matches'][pattern['name']].append(match_info)
    
    def generate_analysis_report(self, log_files: List[str], hours_back: int = 24) -> Dict:
        """Generate comprehensive analysis report"""
        report = {
            'report_time': datetime.now().isoformat(),
            'time_range_hours': hours_back,
            'files_analyzed': len(log_files),
            'total_entries': 0,
            'security_events': 0,
            'critical_events': 0,
            'pattern_summary': defaultdict(int),
            'severity_summary': defaultdict(int),
            'top_threats': [],
            'recommendations': []
        }
        
        all_matches = defaultdict(list)
        
        # Analyze each log file
        for log_file in log_files:
            if os.path.exists(log_file):
                analysis = self.analyze_log_file(log_file, hours_back)
                
                report['total_entries'] += analysis.get('total_entries', 0)
                
                # Aggregate pattern matches
                for pattern_name, matches in analysis.get('pattern_matches', {}).items():
                    all_matches[pattern_name].extend(matches)
                    report['pattern_summary'][pattern_name] += len(matches)
                
                # Aggregate severity
                for severity, count in analysis.get('severity_distribution', {}).items():
                    report['severity_summary'][severity] += count
        
        # Calculate security metrics
        report['security_events'] = sum(
            len(matches) for pattern_name, matches in all_matches.items()
            if any(p['name'] == pattern_name and p['severity'] in ['high', 'critical'] 
                  for p in self.patterns)
        )
        
        report['critical_events'] = sum(
            len(matches) for pattern_name, matches in all_matches.items()
            if any(p['name'] == pattern_name and p['severity'] == 'critical' 
                  for p in self.patterns)
        )
        
        # Generate top threats
        threat_scores = {}
        for pattern_name, matches in all_matches.items():
            pattern_info = next((p for p in self.patterns if p['name'] == pattern_name), None)
            if pattern_info:
                severity_multiplier = {'low': 1, 'medium': 2, 'high': 3, 'critical': 5}
                score = len(matches) * severity_multiplier.get(pattern_info['severity'], 1)
                threat_scores[pattern_name] = {
                    'score': score,
                    'count': len(matches),
                    'severity': pattern_info['severity'],
                    'category': pattern_info['category']
                }
        
        report['top_threats'] = sorted(
            threat_scores.items(),
            key=lambda x: x[1]['score'],
            reverse=True
        )[:10]
        
        # Generate recommendations
        report['recommendations'] = self._generate_recommendations(report, all_matches)
        
        # Convert defaultdicts
        report['pattern_summary'] = dict(report['pattern_summary'])
        report['severity_summary'] = dict(report['severity_summary'])
        
        return report
    
    def _generate_recommendations(self, report: Dict, all_matches: Dict) -> List[str]:
        """Generate security recommendations based on analysis"""
        recommendations = []
        
        # Check for high-frequency attacks
        for pattern_name, matches in all_matches.items():
            if len(matches) > 50:  # High frequency threshold
                recommendations.append(
                    f"High frequency of {pattern_name} detected ({len(matches)} events). "
                    f"Consider implementing additional security controls."
                )
        
        # Check for critical events
        if report['critical_events'] > 0:
            recommendations.append(
                f"Critical security events detected ({report['critical_events']}). "
                f"Immediate investigation recommended."
            )
        
        # Check for authentication issues
        auth_patterns = ['Failed Login Attempts', 'Privilege Escalation']
        auth_events = sum(len(all_matches.get(pattern, [])) for pattern in auth_patterns)
        if auth_events > 20:
            recommendations.append(
                "High number of authentication-related events. "
                "Review access controls and implement account lockout policies."
            )
        
        # Check for malware indicators
        malware_events = len(all_matches.get('Malware Indicators', []))
        if malware_events > 0:
            recommendations.append(
                f"Malware indicators detected ({malware_events} events). "
                f"Run full system scan and update antivirus definitions."
            )
        
        return recommendations

def main():
    """Test logging system"""
    print("Logging System Test")
    print("=" * 30)
    
    # Create security logger
    security_logger = SecurityLogger("ids_test")
    
    # Log various events
    print("Logging test events...")
    
    security_logger.log_security_event(
        "malware_detection",
        "Suspicious file detected in network traffic",
        severity="critical",
        source_ip="192.168.1.100",
        file_hash="abc123def456",
        signature="trojan.generic"
    )
    
    security_logger.log_security_event(
        "port_scan",
        "Port scanning activity detected",
        severity="high",
        source_ip="10.0.0.50",
        dest_ip="192.168.1.10",
        ports_scanned=[22, 80, 443, 8080]
    )
    
    security_logger.log_system_event(
        "system_startup",
        "IDS system started successfully",
        version="1.0.0",
        config_file="ids.conf"
    )
    
    # Test packet analysis logging
    packet_data = {
        'ip': {'src_ip': '192.168.1.100', 'dest_ip': '192.168.1.1'},
        'protocol': 'TCP',
        'size': 1500
    }
    
    detections = [
        {'type': 'signature_match', 'severity': 'high', 'rule': 'malware_001'},
        {'type': 'anomaly', 'severity': 'medium', 'description': 'unusual_size'}
    ]
    
    security_logger.log_packet_analysis(packet_data, detections)
    
    # Test log analysis
    print("\nAnalyzing logs...")
    analyzer = LogAnalyzer()
    
    log_files = [
        os.path.join("logs", "ids_test.log"),
        os.path.join("logs", "ids_test_security.log")
    ]
    
    # Generate analysis report
    report = analyzer.generate_analysis_report(log_files, hours_back=1)
    
    print(f"Analysis Report:")
    print(f"  Total entries: {report['total_entries']}")
    print(f"  Security events: {report['security_events']}")
    print(f"  Critical events: {report['critical_events']}")
    print(f"  Pattern matches: {dict(report['pattern_summary'])}")
    
    if report['recommendations']:
        print(f"  Recommendations:")
        for rec in report['recommendations']:
            print(f"    - {rec}")

if __name__ == "__main__":
    main()

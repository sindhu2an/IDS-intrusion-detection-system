#!/usr/bin/env python3
"""
Threat Intelligence Module for IDS
Integrates with threat intelligence feeds and maintains IOC databases
"""

import json
import time
import hashlib
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Set, Optional
import ipaddress
import logging

class ThreatIntelligence:
    """Threat Intelligence management system"""
    
    def __init__(self, cache_duration=3600):  # 1 hour cache
        self.cache_duration = cache_duration
        self.malicious_ips = set()
        self.malicious_domains = set()
        self.malicious_hashes = set()
        self.reputation_cache = {}
        self.last_update = None
        self.logger = logging.getLogger(__name__)
        
        # Load local threat data
        self.load_local_threats()
    
    def load_local_threats(self):
        """Load local threat intelligence data"""
        # Sample malicious IPs (in real implementation, load from file/database)
        sample_malicious_ips = [
            '192.168.100.100',  # Test malicious IP
            '10.0.0.666',       # Invalid but for testing
            '172.16.0.100'      # Test internal threat
        ]
        
        # Sample malicious domains
        sample_malicious_domains = [
            'malware-test.com',
            'phishing-example.org',
            'botnet-c2.net'
        ]
        
        # Sample malicious file hashes
        sample_malicious_hashes = [
            'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',  # Empty file SHA256
            'd41d8cd98f00b204e9800998ecf8427e',  # Empty file MD5
        ]
        
        self.malicious_ips.update(sample_malicious_ips)
        self.malicious_domains.update(sample_malicious_domains)
        self.malicious_hashes.update(sample_malicious_hashes)
        
        self.logger.info(f"Loaded {len(self.malicious_ips)} malicious IPs, "
                        f"{len(self.malicious_domains)} domains, "
                        f"{len(self.malicious_hashes)} hashes")
    
    def check_ip_reputation(self, ip_address: str) -> Dict:
        """Check IP address reputation"""
        # Check cache first
        cache_key = f"ip_{ip_address}"
        if cache_key in self.reputation_cache:
            cached_result = self.reputation_cache[cache_key]
            if datetime.now() - cached_result['timestamp'] < timedelta(seconds=self.cache_duration):
                return cached_result['data']
        
        reputation = {
            'ip': ip_address,
            'is_malicious': False,
            'threat_types': [],
            'confidence': 0,
            'sources': [],
            'last_seen': None
        }
        
        # Check against local blacklist
        if ip_address in self.malicious_ips:
            reputation['is_malicious'] = True
            reputation['threat_types'].append('blacklisted')
            reputation['confidence'] = 90
            reputation['sources'].append('local_blacklist')
        
        # Check IP characteristics
        try:
            ip_obj = ipaddress.ip_address(ip_address)
            
            # Check for private/reserved ranges
            if ip_obj.is_private:
                reputation['threat_types'].append('private_ip')
            elif ip_obj.is_reserved:
                reputation['threat_types'].append('reserved_ip')
            elif ip_obj.is_loopback:
                reputation['threat_types'].append('loopback')
            
            # Check for suspicious ranges
            if str(ip_obj).startswith('192.168.100.'):  # Example suspicious range
                reputation['is_malicious'] = True
                reputation['threat_types'].append('suspicious_range')
                reputation['confidence'] = 70
                reputation['sources'].append('range_analysis')
                
        except ValueError:
            reputation['threat_types'].append('invalid_ip')
        
        # Cache result
        self.reputation_cache[cache_key] = {
            'data': reputation,
            'timestamp': datetime.now()
        }
        
        return reputation
    
    def check_domain_reputation(self, domain: str) -> Dict:
        """Check domain reputation"""
        cache_key = f"domain_{domain}"
        if cache_key in self.reputation_cache:
            cached_result = self.reputation_cache[cache_key]
            if datetime.now() - cached_result['timestamp'] < timedelta(seconds=self.cache_duration):
                return cached_result['data']
        
        reputation = {
            'domain': domain,
            'is_malicious': False,
            'threat_types': [],
            'confidence': 0,
            'sources': []
        }
        
        # Check against local blacklist
        if domain in self.malicious_domains:
            reputation['is_malicious'] = True
            reputation['threat_types'].append('blacklisted')
            reputation['confidence'] = 95
            reputation['sources'].append('local_blacklist')
        
        # Check domain characteristics
        if any(keyword in domain.lower() for keyword in ['malware', 'phishing', 'botnet', 'c2']):
            reputation['is_malicious'] = True
            reputation['threat_types'].append('suspicious_keywords')
            reputation['confidence'] = 80
            reputation['sources'].append('keyword_analysis')
        
        # Cache result
        self.reputation_cache[cache_key] = {
            'data': reputation,
            'timestamp': datetime.now()
        }
        
        return reputation
    
    def check_hash_reputation(self, file_hash: str) -> Dict:
        """Check file hash reputation"""
        cache_key = f"hash_{file_hash}"
        if cache_key in self.reputation_cache:
            cached_result = self.reputation_cache[cache_key]
            if datetime.now() - cached_result['timestamp'] < timedelta(seconds=self.cache_duration):
                return cached_result['data']
        
        reputation = {
            'hash': file_hash,
            'is_malicious': False,
            'threat_types': [],
            'confidence': 0,
            'sources': []
        }
        
        # Check against local blacklist
        if file_hash in self.malicious_hashes:
            reputation['is_malicious'] = True
            reputation['threat_types'].append('known_malware')
            reputation['confidence'] = 95
            reputation['sources'].append('local_blacklist')
        
        # Cache result
        self.reputation_cache[cache_key] = {
            'data': reputation,
            'timestamp': datetime.now()
        }
        
        return reputation
    
    def analyze_packet_threats(self, packet_data: Dict) -> List[Dict]:
        """Analyze packet for threat intelligence matches"""
        threats = []
        
        # Check source IP
        src_ip = packet_data.get('ip', {}).get('src_ip')
        if src_ip:
            ip_reputation = self.check_ip_reputation(src_ip)
            if ip_reputation['is_malicious']:
                threats.append({
                    'type': 'malicious_ip',
                    'severity': 'high',
                    'description': f'Traffic from malicious IP: {src_ip}',
                    'details': ip_reputation,
                    'timestamp': datetime.now().isoformat()
                })
        
        # Check destination IP
        dest_ip = packet_data.get('ip', {}).get('dest_ip')
        if dest_ip:
            ip_reputation = self.check_ip_reputation(dest_ip)
            if ip_reputation['is_malicious']:
                threats.append({
                    'type': 'malicious_destination',
                    'severity': 'medium',
                    'description': f'Traffic to malicious IP: {dest_ip}',
                    'details': ip_reputation,
                    'timestamp': datetime.now().isoformat()
                })
        
        return threats
    
    def update_threat_feeds(self):
        """Update threat intelligence feeds (placeholder for real implementation)"""
        self.logger.info("Updating threat intelligence feeds...")
        
        # In a real implementation, this would:
        # 1. Download from threat intelligence providers
        # 2. Parse various feed formats (STIX, CSV, JSON)
        # 3. Update local databases
        # 4. Handle rate limiting and authentication
        
        # For now, just update timestamp
        self.last_update = datetime.now()
        self.logger.info("Threat intelligence feeds updated")
    
    def get_threat_summary(self) -> Dict:
        """Get threat intelligence summary"""
        return {
            'malicious_ips': len(self.malicious_ips),
            'malicious_domains': len(self.malicious_domains),
            'malicious_hashes': len(self.malicious_hashes),
            'cache_entries': len(self.reputation_cache),
            'last_update': self.last_update.isoformat() if self.last_update else None
        }
    
    def add_ioc(self, ioc_type: str, value: str, source: str = 'manual'):
        """Add Indicator of Compromise (IOC)"""
        if ioc_type == 'ip':
            self.malicious_ips.add(value)
        elif ioc_type == 'domain':
            self.malicious_domains.add(value)
        elif ioc_type == 'hash':
            self.malicious_hashes.add(value)
        
        self.logger.info(f"Added {ioc_type} IOC: {value} from {source}")
    
    def remove_ioc(self, ioc_type: str, value: str):
        """Remove Indicator of Compromise (IOC)"""
        if ioc_type == 'ip' and value in self.malicious_ips:
            self.malicious_ips.remove(value)
        elif ioc_type == 'domain' and value in self.malicious_domains:
            self.malicious_domains.remove(value)
        elif ioc_type == 'hash' and value in self.malicious_hashes:
            self.malicious_hashes.remove(value)
        
        self.logger.info(f"Removed {ioc_type} IOC: {value}")

def main():
    """Test threat intelligence module"""
    print("Threat Intelligence Test")
    print("=" * 30)
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create threat intelligence instance
    ti = ThreatIntelligence()
    
    # Test IP reputation checks
    test_ips = ['192.168.100.100', '8.8.8.8', '192.168.1.1', '127.0.0.1']
    
    print("Testing IP reputation checks:")
    for ip in test_ips:
        reputation = ti.check_ip_reputation(ip)
        print(f"  {ip}: {'MALICIOUS' if reputation['is_malicious'] else 'CLEAN'} "
              f"(confidence: {reputation['confidence']}%)")
        if reputation['threat_types']:
            print(f"    Threat types: {', '.join(reputation['threat_types'])}")
    
    # Test domain reputation
    test_domains = ['malware-test.com', 'google.com', 'phishing-example.org']
    
    print("\nTesting domain reputation checks:")
    for domain in test_domains:
        reputation = ti.check_domain_reputation(domain)
        print(f"  {domain}: {'MALICIOUS' if reputation['is_malicious'] else 'CLEAN'} "
              f"(confidence: {reputation['confidence']}%)")
    
    # Test packet analysis
    test_packet = {
        'ip': {
            'src_ip': '192.168.100.100',
            'dest_ip': '8.8.8.8'
        },
        'protocol': 'TCP'
    }
    
    print("\nTesting packet threat analysis:")
    threats = ti.analyze_packet_threats(test_packet)
    if threats:
        for threat in threats:
            print(f"  Threat: {threat['description']} (severity: {threat['severity']})")
    else:
        print("  No threats detected")
    
    # Show summary
    summary = ti.get_threat_summary()
    print(f"\nThreat Intelligence Summary:")
    print(f"  Malicious IPs: {summary['malicious_ips']}")
    print(f"  Malicious domains: {summary['malicious_domains']}")
    print(f"  Malicious hashes: {summary['malicious_hashes']}")
    print(f"  Cache entries: {summary['cache_entries']}")

if __name__ == "__main__":
    main()

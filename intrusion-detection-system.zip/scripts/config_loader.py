#!/usr/bin/env python3
"""
Configuration Loader for IDS v2.0
Handles loading and validation of configuration files
"""

import yaml
import json
import os
import logging
from typing import Dict, Any, Optional
from pathlib import Path
import jsonschema
from jsonschema import validate

class ConfigLoader:
    """Configuration loader and validator"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = config_path
        self.config = {}
        self.logger = logging.getLogger("ConfigLoader")
        
        # Configuration schema for validation
        self.schema = {
            "type": "object",
            "properties": {
                "system": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "version": {"type": "string"},
                        "log_level": {"type": "string", "enum": ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]},
                        "data_directory": {"type": "string"},
                        "log_directory": {"type": "string"}
                    },
                    "required": ["name", "version"]
                },
                "network": {
                    "type": "object",
                    "properties": {
                        "interface": {"type": "string"},
                        "capture_filter": {"type": "string"},
                        "packet_limit": {"type": "integer", "minimum": 1},
                        "promiscuous_mode": {"type": "boolean"}
                    },
                    "required": ["interface"]
                },
                "database": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string", "enum": ["sqlite", "postgresql", "mysql"]},
                        "pool_size": {"type": "integer", "minimum": 1}
                    },
                    "required": ["type"]
                }
            },
            "required": ["system", "network", "database"]
        }
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        try:
            if not os.path.exists(self.config_path):
                self.logger.error(f"Configuration file not found: {self.config_path}")
                return self._get_default_config()
            
            with open(self.config_path, 'r') as file:
                if self.config_path.endswith('.yaml') or self.config_path.endswith('.yml'):
                    self.config = yaml.safe_load(file)
                elif self.config_path.endswith('.json'):
                    self.config = json.load(file)
                else:
                    raise ValueError("Unsupported configuration file format")
            
            # Validate configuration
            self._validate_config()
            
            # Apply environment variable overrides
            self._apply_env_overrides()
            
            # Create necessary directories
            self._create_directories()
            
            self.logger.info(f"Configuration loaded successfully from {self.config_path}")
            return self.config
            
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {e}")
            return self._get_default_config()
    
    def _validate_config(self):
        """Validate configuration against schema"""
        try:
            validate(instance=self.config, schema=self.schema)
            self.logger.info("Configuration validation passed")
        except jsonschema.exceptions.ValidationError as e:
            self.logger.error(f"Configuration validation failed: {e.message}")
            raise
    
    def _apply_env_overrides(self):
        """Apply environment variable overrides"""
        env_mappings = {
            'IDS_LOG_LEVEL': ['system', 'log_level'],
            'IDS_NETWORK_INTERFACE': ['network', 'interface'],
            'IDS_DATABASE_TYPE': ['database', 'type'],
            'IDS_WEB_HOST': ['web', 'host'],
            'IDS_WEB_PORT': ['web', 'port'],
            'IDS_API_HOST': ['api', 'host'],
            'IDS_API_PORT': ['api', 'port']
        }
        
        for env_var, config_path in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value:
                self._set_nested_value(self.config, config_path, env_value)
                self.logger.info(f"Applied environment override: {env_var} = {env_value}")
    
    def _set_nested_value(self, config: Dict, path: list, value: Any):
        """Set nested configuration value"""
        for key in path[:-1]:
            config = config.setdefault(key, {})
        
        # Convert string values to appropriate types
        if isinstance(value, str):
            if value.lower() in ['true', 'false']:
                value = value.lower() == 'true'
            elif value.isdigit():
                value = int(value)
            elif value.replace('.', '').isdigit():
                value = float(value)
        
        config[path[-1]] = value
    
    def _create_directories(self):
        """Create necessary directories"""
        directories = [
            self.config.get('system', {}).get('data_directory', './data'),
            self.config.get('system', {}).get('log_directory', './logs'),
            self.config.get('system', {}).get('backup_directory', './backups')
        ]
        
        for directory in directories:
            if directory:
                Path(directory).mkdir(parents=True, exist_ok=True)
                self.logger.debug(f"Created directory: {directory}")
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "system": {
                "name": "IDS-v2",
                "version": "2.0.0",
                "log_level": "INFO",
                "data_directory": "./data",
                "log_directory": "./logs"
            },
            "network": {
                "interface": "eth0",
                "capture_filter": "",
                "packet_limit": 1000,
                "promiscuous_mode": True
            },
            "database": {
                "type": "sqlite",
                "sqlite": {"path": "./data/ids.db"}
            },
            "detection": {
                "ml_anomaly": {"enabled": True, "threshold": 0.7},
                "behavioral": {"enabled": True, "threshold": 0.8},
                "signatures": {"enabled": True}
            },
            "alerts": {
                "notifications": {
                    "email": {"enabled": False},
                    "webhook": {"enabled": False},
                    "syslog": {"enabled": True}
                }
            },
            "web": {
                "host": "127.0.0.1",
                "port": 5000,
                "debug": False
            },
            "api": {
                "host": "127.0.0.1",
                "port": 8000,
                "debug": False
            }
        }
    
    def save_config(self, config: Dict[str, Any], path: Optional[str] = None):
        """Save configuration to file"""
        try:
            save_path = path or self.config_path
            
            with open(save_path, 'w') as file:
                if save_path.endswith('.yaml') or save_path.endswith('.yml'):
                    yaml.dump(config, file, default_flow_style=False, indent=2)
                elif save_path.endswith('.json'):
                    json.dump(config, file, indent=2)
                else:
                    raise ValueError("Unsupported configuration file format")
            
            self.logger.info(f"Configuration saved to {save_path}")
            
        except Exception as e:
            self.logger.error(f"Failed to save configuration: {e}")
            raise
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """Get configuration value by dot-separated path"""
        keys = key_path.split('.')
        value = self.config
        
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key_path: str, value: Any):
        """Set configuration value by dot-separated path"""
        keys = key_path.split('.')
        config = self.config
        
        for key in keys[:-1]:
            config = config.setdefault(key, {})
        
        config[keys[-1]] = value
        self.logger.info(f"Configuration updated: {key_path} = {value}")

# Global configuration instance
config_loader = ConfigLoader()

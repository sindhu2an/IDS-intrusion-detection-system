#!/usr/bin/env python3
"""
Advanced Network Capture Module v2.0
High-performance packet capture with async processing
"""

import asyncio
import socket
import struct
import time
import threading
from datetime import datetime
from typing import Dict, List, Optional, Callable, Tuple
import logging
from dataclasses import dataclass
import json
import uuid

from ids_core_v2 import SecurityEvent, EventType, ThreatLevel, IDSCore

logger = logging.getLogger(__name__)

@dataclass
class PacketInfo:
    """Enhanced packet information structure"""
    timestamp: datetime
    source_ip: str
    destination_ip: str
    source_port: int
    destination_port: int
    protocol: str
    packet_size: int
    flags: Dict[str, bool]
    payload: bytes
    raw_packet: bytes

class ProtocolAnalyzer:
    """Advanced protocol analysis and anomaly detection"""
    
    def __init__(self):
        self.protocol_stats = {}
        self.connection_tracker = {}
        self.suspicious_patterns = {
            'port_scan_threshold': 10,  # ports per minute
            'connection_flood_threshold': 100,  # connections per minute
            'payload_anomaly_threshold': 0.8
        }
    
    def analyze_packet(self, packet: PacketInfo) -> List[SecurityEvent]:
        """Analyze packet for security threats"""
        events = []
        
        # Update statistics
        self._update_stats(packet)
        
        # Check for port scanning
        port_scan_event = self._detect_port_scan(packet)
        if port_scan_event:
            events.append(port_scan_event)
        
        # Check for connection flooding
        flood_event = self._detect_connection_flood(packet)
        if flood_event:
            events.append(flood_event)
        
        # Analyze payload for malicious content
        payload_event = self._analyze_payload(packet)
        if payload_event:
            events.append(payload_event)
        
        return events
    
    def _update_stats(self, packet: PacketInfo):
        """Update protocol statistics"""
        key = f"{packet.source_ip}:{packet.protocol}"
        
        if key not in self.protocol_stats:
            self.protocol_stats[key] = {
                'packet_count': 0,
                'byte_count': 0,
                'ports_accessed': set(),
                'first_seen': packet.timestamp,
                'last_seen': packet.timestamp
            }
        
        stats = self.protocol_stats[key]
        stats['packet_count'] += 1
        stats['byte_count'] += packet.packet_size
        stats['ports_accessed'].add(packet.destination_port)
        stats['last_seen'] = packet.timestamp
    
    def _detect_port_scan(self, packet: PacketInfo) -> Optional[SecurityEvent]:
        """Detect potential port scanning activity"""
        key = f"{packet.source_ip}:{packet.protocol}"
        
        if key in self.protocol_stats:
            stats = self.protocol_stats[key]
            time_window = (packet.timestamp - stats['first_seen']).total_seconds() / 60
            
            if time_window > 0:
                ports_per_minute = len(stats['ports_accessed']) / time_window
                
                if ports_per_minute > self.suspicious_patterns['port_scan_threshold']:
                    return SecurityEvent(
                        id=str(uuid.uuid4()),
                        timestamp=packet.timestamp,
                        event_type=EventType.PORT_SCAN,
                        threat_level=ThreatLevel.HIGH,
                        source_ip=packet.source_ip,
                        destination_ip=packet.destination_ip,
                        source_port=packet.source_port,
                        destination_port=packet.destination_port,
                        protocol=packet.protocol,
                        description=f"Port scan detected: {len(stats['ports_accessed'])} ports in {time_window:.1f} minutes",
                        raw_data={
                            'ports_accessed': list(stats['ports_accessed']),
                            'scan_rate': ports_per_minute,
                            'duration': time_window
                        },
                        confidence_score=min(0.9, ports_per_minute / 50),
                        mitigation_suggested=[
                            "Block source IP temporarily",
                            "Monitor for further scanning activity",
                            "Check firewall rules"
                        ],
                        tags=["reconnaissance", "port_scan", "automated"]
                    )
        
        return None
    
    def _detect_connection_flood(self, packet: PacketInfo) -> Optional[SecurityEvent]:
        """Detect connection flooding attacks"""
        if packet.protocol == "TCP" and packet.flags.get('SYN', False):
            key = f"{packet.source_ip}_flood"
            
            if key not in self.connection_tracker:
                self.connection_tracker[key] = {
                    'connections': [],
                    'first_connection': packet.timestamp
                }
            
            tracker = self.connection_tracker[key]
            tracker['connections'].append(packet.timestamp)
            
            # Clean old connections (older than 1 minute)
            cutoff = packet.timestamp.timestamp() - 60
            tracker['connections'] = [
                ts for ts in tracker['connections'] 
                if ts.timestamp() > cutoff
            ]
            
            if len(tracker['connections']) > self.suspicious_patterns['connection_flood_threshold']:
                return SecurityEvent(
                    id=str(uuid.uuid4()),
                    timestamp=packet.timestamp,
                    event_type=EventType.MALICIOUS_TRAFFIC,
                    threat_level=ThreatLevel.CRITICAL,
                    source_ip=packet.source_ip,
                    destination_ip=packet.destination_ip,
                    source_port=packet.source_port,
                    destination_port=packet.destination_port,
                    protocol=packet.protocol,
                    description=f"Connection flood detected: {len(tracker['connections'])} connections in 1 minute",
                    raw_data={
                        'connection_count': len(tracker['connections']),
                        'attack_duration': (packet.timestamp - tracker['first_connection']).total_seconds()
                    },
                    confidence_score=0.95,
                    mitigation_suggested=[
                        "Implement rate limiting",
                        "Block source IP",
                        "Enable SYN flood protection"
                    ],
                    tags=["dos", "flood", "tcp"]
                )
        
        return None
    
    def _analyze_payload(self, packet: PacketInfo) -> Optional[SecurityEvent]:
        """Analyze packet payload for malicious content"""
        if not packet.payload:
            return None
        
        try:
            payload_str = packet.payload.decode('utf-8', errors='ignore').lower()
            
            # Check for common attack patterns
            malicious_patterns = [
                ('sql injection', ['union select', 'drop table', '1=1', 'or 1=1']),
                ('xss', ['<script>', 'javascript:', 'onerror=', 'onload=']),
                ('command injection', ['|', '&&', ';', '../', '/etc/passwd']),
                ('buffer overflow', ['\x90' * 10, 'AAAA' * 20])  # NOP sled, buffer patterns
            ]
            
            for attack_type, patterns in malicious_patterns:
                for pattern in patterns:
                    if pattern in payload_str or pattern.encode() in packet.payload:
                        return SecurityEvent(
                            id=str(uuid.uuid4()),
                            timestamp=packet.timestamp,
                            event_type=EventType.MALICIOUS_TRAFFIC,
                            threat_level=ThreatLevel.HIGH,
                            source_ip=packet.source_ip,
                            destination_ip=packet.destination_ip,
                            source_port=packet.source_port,
                            destination_port=packet.destination_port,
                            protocol=packet.protocol,
                            description=f"Malicious payload detected: {attack_type}",
                            raw_data={
                                'attack_type': attack_type,
                                'pattern_matched': pattern,
                                'payload_size': len(packet.payload),
                                'payload_preview': payload_str[:200]
                            },
                            confidence_score=0.85,
                            mitigation_suggested=[
                                "Block malicious request",
                                "Investigate source IP",
                                "Update WAF rules"
                            ],
                            tags=["payload_analysis", attack_type.replace(' ', '_'), "malicious"]
                        )
            
        except Exception as e:
            logger.debug(f"Payload analysis error: {e}")
        
        return None

class NetworkCapture:
    """High-performance network capture with async processing"""
    
    def __init__(self, interface: str = "eth0"):
        self.interface = interface
        self.running = False
        self.analyzer = ProtocolAnalyzer()
        self.ids_core: Optional[IDSCore] = None
        self.capture_stats = {
            'packets_captured': 0,
            'packets_analyzed': 0,
            'events_generated': 0,
            'start_time': None
        }
    
    def set_ids_core(self, ids_core: IDSCore):
        """Set the IDS core for event processing"""
        self.ids_core = ids_core
    
    async def start_capture(self):
        """Start network packet capture"""
        if self.running:
            logger.warning("Network capture already running")
            return
        
        self.running = True
        self.capture_stats['start_time'] = datetime.now()
        logger.info(f"Starting network capture on {self.interface}")
        
        try:
            # Create raw socket
            sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
            sock.bind((self.interface, 0))
            sock.settimeout(1.0)  # Non-blocking with timeout
            
            while self.running:
                try:
                    # Capture packet
                    raw_packet, addr = sock.recvfrom(65535)
                    self.capture_stats['packets_captured'] += 1
                    
                    # Parse packet in background
                    asyncio.create_task(self._process_packet(raw_packet))
                    
                    # Yield control to other tasks
                    await asyncio.sleep(0)
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    logger.error(f"Packet capture error: {e}")
                    await asyncio.sleep(1)
        
        except Exception as e:
            logger.error(f"Network capture initialization error: {e}")
        finally:
            self.running = False
            logger.info("Network capture stopped")
    
    async def _process_packet(self, raw_packet: bytes):
        """Process captured packet"""
        try:
            packet_info = self._parse_packet(raw_packet)
            if packet_info:
                self.capture_stats['packets_analyzed'] += 1
                
                # Analyze for threats
                events = self.analyzer.analyze_packet(packet_info)
                
                # Send events to IDS core
                if events and self.ids_core:
                    for event in events:
                        await self.ids_core.process_security_event(event)
                        self.capture_stats['events_generated'] += 1
        
        except Exception as e:
            logger.debug(f"Packet processing error: {e}")
    
    def _parse_packet(self, raw_packet: bytes) -> Optional[PacketInfo]:
        """Parse raw packet into structured information"""
        try:
            # Parse Ethernet header
            eth_header = raw_packet[:14]
            eth = struct.unpack('!6s6sH', eth_header)
            eth_protocol = socket.ntohs(eth[2])
            
            # Only process IP packets
            if eth_protocol != 0x0800:
                return None
            
            # Parse IP header
            ip_header = raw_packet[14:34]
            iph = struct.unpack('!BBHHHBBH4s4s', ip_header)
            
            version_ihl = iph[0]
            ihl = version_ihl & 0xF
            iph_length = ihl * 4
            
            protocol = iph[6]
            source_ip = socket.inet_ntoa(iph[8])
            destination_ip = socket.inet_ntoa(iph[9])
            
            # Parse transport layer
            transport_header_start = 14 + iph_length
            source_port = destination_port = 0
            flags = {}
            
            if protocol == 6:  # TCP
                tcp_header = raw_packet[transport_header_start:transport_header_start + 20]
                if len(tcp_header) >= 20:
                    tcph = struct.unpack('!HHLLBBHHH', tcp_header)
                    source_port = tcph[0]
                    destination_port = tcph[1]
                    
                    # Parse TCP flags
                    tcp_flags = tcph[5]
                    flags = {
                        'FIN': bool(tcp_flags & 0x01),
                        'SYN': bool(tcp_flags & 0x02),
                        'RST': bool(tcp_flags & 0x04),
                        'PSH': bool(tcp_flags & 0x08),
                        'ACK': bool(tcp_flags & 0x10),
                        'URG': bool(tcp_flags & 0x20)
                    }
                    
                    payload = raw_packet[transport_header_start + 20:]
                    protocol_name = "TCP"
            
            elif protocol == 17:  # UDP
                udp_header = raw_packet[transport_header_start:transport_header_start + 8]
                if len(udp_header) >= 8:
                    udph = struct.unpack('!HHHH', udp_header)
                    source_port = udph[0]
                    destination_port = udph[1]
                    payload = raw_packet[transport_header_start + 8:]
                    protocol_name = "UDP"
            
            else:
                payload = raw_packet[transport_header_start:]
                protocol_name = f"Protocol-{protocol}"
            
            return PacketInfo(
                timestamp=datetime.now(),
                source_ip=source_ip,
                destination_ip=destination_ip,
                source_port=source_port,
                destination_port=destination_port,
                protocol=protocol_name,
                packet_size=len(raw_packet),
                flags=flags,
                payload=payload,
                raw_packet=raw_packet
            )
        
        except Exception as e:
            logger.debug(f"Packet parsing error: {e}")
            return None
    
    def stop_capture(self):
        """Stop network capture"""
        self.running = False
        logger.info("Stopping network capture...")
    
    def get_statistics(self) -> Dict[str, any]:
        """Get capture statistics"""
        if self.capture_stats['start_time']:
            uptime = (datetime.now() - self.capture_stats['start_time']).total_seconds()
            pps = self.capture_stats['packets_captured'] / max(uptime, 1)
        else:
            uptime = 0
            pps = 0
        
        return {
            'packets_captured': self.capture_stats['packets_captured'],
            'packets_analyzed': self.capture_stats['packets_analyzed'],
            'events_generated': self.capture_stats['events_generated'],
            'uptime_seconds': uptime,
            'packets_per_second': pps,
            'running': self.running
        }

# Example usage
async def main():
    """Test the network capture module"""
    ids_core = IDSCore()
    capture = NetworkCapture("lo")  # Use loopback for testing
    capture.set_ids_core(ids_core)
    
    # Start IDS core
    core_task = asyncio.create_task(ids_core.start())
    
    # Start capture
    capture_task = asyncio.create_task(capture.start_capture())
    
    # Run for a short time
    await asyncio.sleep(10)
    
    # Stop capture
    capture.stop_capture()
    ids_core.stop()
    
    # Show statistics
    capture_stats = capture.get_statistics()
    ids_stats = ids_core.get_statistics()
    
    print(f"Capture Stats: {json.dumps(capture_stats, indent=2)}")
    print(f"IDS Stats: {json.dumps(ids_stats, indent=2)}")
    
    # Wait for tasks to complete
    try:
        await asyncio.gather(capture_task, core_task, return_exceptions=True)
    except asyncio.CancelledError:
        pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")

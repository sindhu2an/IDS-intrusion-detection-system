#!/bin/bash

# IDS v2.0 Installation Script
# Installs and configures the Intrusion Detection System

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
IDS_USER="ids"
IDS_HOME="/opt/ids"
IDS_SERVICE="ids-monitor"
PYTHON_VERSION="3.8"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Intrusion Detection System v2.0      ${NC}"
echo -e "${BLUE}  Installation Script                   ${NC}"
echo -e "${BLUE}========================================${NC}"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root${NC}"
   exit 1
fi

# Function to print status
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check Python version
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is not installed"
        exit 1
    fi
    
    PYTHON_VER=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
    if [[ $(echo "$PYTHON_VER >= $PYTHON_VERSION" | bc -l) -eq 0 ]]; then
        print_error "Python $PYTHON_VERSION or higher is required (found $PYTHON_VER)"
        exit 1
    fi
    
    # Check for required system packages
    REQUIRED_PACKAGES=("python3-pip" "python3-dev" "libpcap-dev" "build-essential")
    
    for package in "${REQUIRED_PACKAGES[@]}"; do
        if ! dpkg -l | grep -q "^ii  $package "; then
            print_warning "$package is not installed. Installing..."
            apt-get update
            apt-get install -y "$package"
        fi
    done
    
    print_status "System requirements check completed"
}

# Create IDS user and directories
setup_user_and_directories() {
    print_status "Setting up user and directories..."
    
    # Create IDS user if it doesn't exist
    if ! id "$IDS_USER" &>/dev/null; then
        useradd -r -s /bin/false -d "$IDS_HOME" "$IDS_USER"
        print_status "Created user: $IDS_USER"
    fi
    
    # Create directories
    mkdir -p "$IDS_HOME"/{bin,config,data,logs,backups,rules}
    chown -R "$IDS_USER:$IDS_USER" "$IDS_HOME"
    chmod 755 "$IDS_HOME"
    
    print_status "Directories created and configured"
}

# Install Python dependencies
install_python_dependencies() {
    print_status "Installing Python dependencies..."
    
    # Create virtual environment
    python3 -m venv "$IDS_HOME/venv"
    source "$IDS_HOME/venv/bin/activate"
    
    # Upgrade pip
    pip install --upgrade pip
    
    # Install required packages
    pip install -r requirements_v2.txt
    
    # Set ownership
    chown -R "$IDS_USER:$IDS_USER" "$IDS_HOME/venv"
    
    print_status "Python dependencies installed"
}

# Copy IDS files
install_ids_files() {
    print_status "Installing IDS files..."
    
    # Copy Python scripts
    cp *.py "$IDS_HOME/bin/"
    
    # Copy configuration
    cp config.yaml "$IDS_HOME/config/"
    
    # Copy requirements
    cp requirements_v2.txt "$IDS_HOME/"
    
    # Set permissions
    chmod +x "$IDS_HOME/bin"/*.py
    chown -R "$IDS_USER:$IDS_USER" "$IDS_HOME/bin" "$IDS_HOME/config"
    
    print_status "IDS files installed"
}

# Create systemd service
create_systemd_service() {
    print_status "Creating systemd service..."
    
    cat > /etc/systemd/system/${IDS_SERVICE}.service << EOF
[Unit]
Description=Intrusion Detection System v2.0
After=network.target
Wants=network.target

[Service]
Type=simple
User=$IDS_USER
Group=$IDS_USER
WorkingDirectory=$IDS_HOME/bin
Environment=PATH=$IDS_HOME/venv/bin
ExecStart=$IDS_HOME/venv/bin/python $IDS_HOME/bin/ids_main_interface.py
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ids-monitor

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$IDS_HOME

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable ${IDS_SERVICE}
    
    print_status "Systemd service created and enabled"
}

# Configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    
    if command -v ufw &> /dev/null; then
        # Allow web interface
        ufw allow 5000/tcp comment "IDS Web Interface"
        # Allow API
        ufw allow 8000/tcp comment "IDS REST API"
        print_status "UFW firewall rules added"
    elif command -v firewall-cmd &> /dev/null; then
        # CentOS/RHEL firewall
        firewall-cmd --permanent --add-port=5000/tcp
        firewall-cmd --permanent --add-port=8000/tcp
        firewall-cmd --reload
        print_status "Firewalld rules added"
    else
        print_warning "No supported firewall found. Please manually configure firewall rules."
    fi
}

# Create log rotation
setup_log_rotation() {
    print_status "Setting up log rotation..."
    
    cat > /etc/logrotate.d/ids << EOF
$IDS_HOME/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 $IDS_USER $IDS_USER
    postrotate
        systemctl reload ${IDS_SERVICE} > /dev/null 2>&1 || true
    endscript
}
EOF

    print_status "Log rotation configured"
}

# Main installation function
main() {
    print_status "Starting IDS v2.0 installation..."
    
    check_requirements
    setup_user_and_directories
    install_python_dependencies
    install_ids_files
    create_systemd_service
    configure_firewall
    setup_log_rotation
    
    print_status "Installation completed successfully!"
    echo
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  Installation Summary                  ${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo -e "IDS Home: ${BLUE}$IDS_HOME${NC}"
    echo -e "IDS User: ${BLUE}$IDS_USER${NC}"
    echo -e "Service: ${BLUE}$IDS_SERVICE${NC}"
    echo -e "Configuration: ${BLUE}$IDS_HOME/config/config.yaml${NC}"
    echo -e "Logs: ${BLUE}$IDS_HOME/logs/${NC}"
    echo
    echo -e "${YELLOW}Next Steps:${NC}"
    echo "1. Edit configuration: $IDS_HOME/config/config.yaml"
    echo "2. Start the service: systemctl start $IDS_SERVICE"
    echo "3. Check status: systemctl status $IDS_SERVICE"
    echo "4. View logs: journalctl -u $IDS_SERVICE -f"
    echo "5. Access web interface: http://localhost:5000"
    echo "6. Access API docs: http://localhost:8000/docs"
    echo
}

# Run main function
main "$@"

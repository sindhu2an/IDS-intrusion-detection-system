#!/usr/bin/env python3
"""
Data Analytics Module v2.0
Advanced analytics and reporting for IDS data
"""

import asyncio
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import logging
import json
from pathlib import Path
import io
import base64

# Statistical analysis
from scipy import stats
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from database_manager_v2 import AdvancedDatabaseManager, DatabaseConfig

logger = logging.getLogger(__name__)

class ThreatAnalytics:
    """Advanced threat analytics and visualization"""
    
    def __init__(self, db_manager: AdvancedDatabaseManager):
        self.db_manager = db_manager
        self.reports_dir = Path("reports")
        self.reports_dir.mkdir(exist_ok=True)
        
        # Configure matplotlib for non-interactive use
        plt.style.use('seaborn-v0_8')
        plt.rcParams['figure.figsize'] = (12, 8)
        plt.rcParams['font.size'] = 10
    
    async def generate_threat_report(self, time_range: str = "7d") -> Dict[str, Any]:
        """Generate comprehensive threat analysis report"""
        try:
            logger.info(f"Generating threat report for {time_range}")
            
            # Get data
            events_data = await self._get_events_dataframe(time_range)
            
            if events_data.empty:
                return {"error": "No data available for the specified time range"}
            
            report = {
                "metadata": {
                    "generated_at": datetime.now().isoformat(),
                    "time_range": time_range,
                    "total_events": len(events_data)
                },
                "summary": await self._generate_summary_stats(events_data),
                "temporal_analysis": await self._analyze_temporal_patterns(events_data),
                "source_analysis": await self._analyze_source_patterns(events_data),
                "threat_clustering": await self._perform_threat_clustering(events_data),
                "anomaly_detection": await self._detect_statistical_anomalies(events_data),
                "visualizations": await self._generate_visualizations(events_data, time_range)
            }
            
            # Save report
            report_file = self.reports_dir / f"threat_report_{time_range}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            logger.info(f"Threat report saved to {report_file}")
            return report
        
        except Exception as e:
            logger.error(f"Error generating threat report: {e}")
            return {"error": str(e)}
    
    async def _get_events_dataframe(self, time_range: str) -> pd.DataFrame:
        """Get events data as pandas DataFrame"""
        try:
            # Calculate time range
            if time_range == "1h":
                start_time = datetime.now() - timedelta(hours=1)
            elif time_range == "24h":
                start_time = datetime.now() - timedelta(days=1)
            elif time_range == "7d":
                start_time = datetime.now() - timedelta(days=7)
            elif time_range == "30d":
                start_time = datetime.now() - timedelta(days=30)
            else:
                start_time = datetime.now() - timedelta(days=7)
            
            # Get events from database
            filters = {"start_time": start_time.isoformat()}
            events = await self.db_manager.get_events(limit=10000, filters=filters)
            
            if not events:
                return pd.DataFrame()
            
            # Convert to DataFrame
            df = pd.DataFrame(events)
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Add derived columns
            df['hour'] = df['timestamp'].dt.hour
            df['day_of_week'] = df['timestamp'].dt.dayofweek
            df['date'] = df['timestamp'].dt.date
            
            return df
        
        except Exception as e:
            logger.error(f"Error creating events DataFrame: {e}")
            return pd.DataFrame()
    
    async def _generate_summary_stats(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Generate summary statistics"""
        try:
            summary = {
                "total_events": len(df),
                "unique_source_ips": df['source_ip'].nunique(),
                "unique_destination_ips": df['destination_ip'].nunique(),
                "date_range": {
                    "start": df['timestamp'].min().isoformat(),
                    "end": df['timestamp'].max().isoformat()
                },
                "threat_level_distribution": df['threat_level'].value_counts().to_dict(),
                "event_type_distribution": df['event_type'].value_counts().to_dict(),
                "protocol_distribution": df['protocol'].value_counts().to_dict(),
                "average_confidence_score": float(df['confidence_score'].mean()),
                "confidence_score_std": float(df['confidence_score'].std())
            }
            
            # Top source IPs
            top_sources = df['source_ip'].value_counts().head(10)
            summary["top_source_ips"] = [
                {"ip": ip, "count": int(count)} 
                for ip, count in top_sources.items()
            ]
            
            # Top destination ports
            top_ports = df['destination_port'].value_counts().head(10)
            summary["top_destination_ports"] = [
                {"port": int(port), "count": int(count)} 
                for port, count in top_ports.items()
            ]
            
            return summary
        
        except Exception as e:
            logger.error(f"Error generating summary stats: {e}")
            return {}
    
    async def _analyze_temporal_patterns(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze temporal patterns in threat data"""
        try:
            temporal = {}
            
            # Events by hour
            hourly_counts = df.groupby('hour').size()
            temporal["hourly_distribution"] = hourly_counts.to_dict()
            
            # Events by day of week
            daily_counts = df.groupby('day_of_week').size()
            day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            temporal["daily_distribution"] = {
                day_names[day]: int(count) for day, count in daily_counts.items()
            }
            
            # Time series analysis
            daily_events = df.groupby('date').size()
            temporal["daily_time_series"] = [
                {"date": str(date), "count": int(count)} 
                for date, count in daily_events.items()
            ]
            
            # Peak activity detection
            peak_hour = hourly_counts.idxmax()
            peak_day = daily_counts.idxmax()
            
            temporal["peak_activity"] = {
                "peak_hour": int(peak_hour),
                "peak_hour_count": int(hourly_counts[peak_hour]),
                "peak_day": day_names[peak_day],
                "peak_day_count": int(daily_counts[peak_day])
            }
            
            # Trend analysis
            if len(daily_events) > 1:
                # Calculate trend using linear regression
                x = np.arange(len(daily_events))
                y = daily_events.values
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
                
                temporal["trend_analysis"] = {
                    "slope": float(slope),
                    "r_squared": float(r_value ** 2),
                    "p_value": float(p_value),
                    "trend_direction": "increasing" if slope > 0 else "decreasing" if slope < 0 else "stable"
                }
            
            return temporal
        
        except Exception as e:
            logger.error(f"Error analyzing temporal patterns: {e}")
            return {}
    
    async def _analyze_source_patterns(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze source IP patterns and behaviors"""
        try:
            source_analysis = {}
            
            # Source IP statistics
            source_stats = df.groupby('source_ip').agg({
                'timestamp': ['count', 'min', 'max'],
                'threat_level': lambda x: x.value_counts().to_dict(),
                'event_type': lambda x: x.value_counts().to_dict(),
                'confidence_score': ['mean', 'std'],
                'destination_port': 'nunique'
            }).round(3)
            
            # Flatten column names
            source_stats.columns = ['_'.join(col).strip() for col in source_stats.columns]
            
            # Convert to list of dictionaries
            source_list = []
            for ip, row in source_stats.iterrows():
                source_info = {
                    "ip": ip,
                    "event_count": int(row['timestamp_count']),
                    "first_seen": row['timestamp_min'].isoformat(),
                    "last_seen": row['timestamp_max'].isoformat(),
                    "avg_confidence": float(row['confidence_score_mean']),
                    "unique_ports": int(row['destination_port_nunique']),
                    "threat_levels": row['threat_level_<lambda>'],
                    "event_types": row['event_type_<lambda>']
                }
                
                # Calculate activity duration
                duration = (row['timestamp_max'] - row['timestamp_min']).total_seconds()
                source_info["activity_duration_hours"] = round(duration / 3600, 2)
                
                # Calculate threat score
                threat_weights = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
                threat_score = sum(
                    threat_weights.get(level, 0) * count 
                    for level, count in source_info["threat_levels"].items()
                ) / source_info["event_count"]
                source_info["threat_score"] = round(threat_score, 2)
                
                source_list.append(source_info)
            
            # Sort by threat score
            source_list.sort(key=lambda x: x["threat_score"], reverse=True)
            
            source_analysis["top_threat_sources"] = source_list[:20]
            
            # Identify suspicious patterns
            suspicious_sources = []
            for source in source_list:
                if (source["unique_ports"] > 10 or 
                    source["threat_score"] > 3.0 or
                    source["event_count"] > 100):
                    suspicious_sources.append(source)
            
            source_analysis["suspicious_sources"] = suspicious_sources[:10]
            
            return source_analysis
        
        except Exception as e:
            logger.error(f"Error analyzing source patterns: {e}")
            return {}
    
    async def _perform_threat_clustering(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform clustering analysis on threat data"""
        try:
            clustering = {}
            
            # Prepare features for clustering
            features = []
            source_ips = []
            
            for ip in df['source_ip'].unique():
                ip_data = df[df['source_ip'] == ip]
                
                # Create feature vector
                feature_vector = [
                    len(ip_data),  # Event count
                    ip_data['confidence_score'].mean(),  # Avg confidence
                    ip_data['destination_port'].nunique(),  # Unique ports
                    len(ip_data['event_type'].unique()),  # Unique event types
                    (ip_data['timestamp'].max() - ip_data['timestamp'].min()).total_seconds() / 3600,  # Duration hours
                ]
                
                # Add threat level distribution
                threat_counts = ip_data['threat_level'].value_counts()
                for level in ['low', 'medium', 'high', 'critical']:
                    feature_vector.append(threat_counts.get(level, 0))
                
                features.append(feature_vector)
                source_ips.append(ip)
            
            if len(features) < 3:
                return {"error": "Insufficient data for clustering"}
            
            # Normalize features
            scaler = StandardScaler()
            features_scaled = scaler.fit_transform(features)
            
            # K-means clustering
            n_clusters = min(5, len(features) // 2)
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            cluster_labels = kmeans.fit_predict(features_scaled)
            
            # DBSCAN for anomaly detection
            dbscan = DBSCAN(eps=0.5, min_samples=2)
            anomaly_labels = dbscan.fit_predict(features_scaled)
            
            # Analyze clusters
            clusters = {}
            for i in range(n_clusters):
                cluster_ips = [source_ips[j] for j in range(len(source_ips)) if cluster_labels[j] == i]
                cluster_data = df[df['source_ip'].isin(cluster_ips)]
                
                clusters[f"cluster_{i}"] = {
                    "size": len(cluster_ips),
                    "ips": cluster_ips[:10],  # Top 10 IPs
                    "avg_events_per_ip": len(cluster_data) / len(cluster_ips),
                    "dominant_event_types": cluster_data['event_type'].value_counts().head(3).to_dict(),
                    "avg_confidence": float(cluster_data['confidence_score'].mean()),
                    "threat_level_distribution": cluster_data['threat_level'].value_counts().to_dict()
                }
            
            clustering["kmeans_clusters"] = clusters
            
            # Identify anomalous IPs
            anomalous_ips = [source_ips[j] for j in range(len(source_ips)) if anomaly_labels[j] == -1]
            clustering["anomalous_sources"] = {
                "count": len(anomalous_ips),
                "ips": anomalous_ips[:10]
            }
            
            return clustering
        
        except Exception as e:
            logger.error(f"Error performing threat clustering: {e}")
            return {}
    
    async def _detect_statistical_anomalies(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Detect statistical anomalies in the data"""
        try:
            anomalies = {}
            
            # Confidence score anomalies
            confidence_scores = df['confidence_score'].dropna()
            if len(confidence_scores) > 10:
                q1 = confidence_scores.quantile(0.25)
                q3 = confidence_scores.quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                
                confidence_anomalies = df[
                    (df['confidence_score'] < lower_bound) | 
                    (df['confidence_score'] > upper_bound)
                ]
                
                anomalies["confidence_anomalies"] = {
                    "count": len(confidence_anomalies),
                    "low_confidence_events": len(confidence_anomalies[confidence_anomalies['confidence_score'] < lower_bound]),
                    "high_confidence_events": len(confidence_anomalies[confidence_anomalies['confidence_score'] > upper_bound])
                }
            
            # Temporal anomalies
            hourly_counts = df.groupby('hour').size()
            hourly_mean = hourly_counts.mean()
            hourly_std = hourly_counts.std()
            
            anomalous_hours = []
            for hour, count in hourly_counts.items():
                z_score = abs((count - hourly_mean) / hourly_std) if hourly_std > 0 else 0
                if z_score > 2:  # More than 2 standard deviations
                    anomalous_hours.append({
                        "hour": int(hour),
                        "count": int(count),
                        "z_score": float(z_score)
                    })
            
            anomalies["temporal_anomalies"] = anomalous_hours
            
            # Port usage anomalies
            port_counts = df['destination_port'].value_counts()
            unusual_ports = []
            
            for port, count in port_counts.items():
                # Check if port is in unusual range or has unusual activity
                if port > 49152 or count == 1:  # Ephemeral ports or single occurrences
                    unusual_ports.append({
                        "port": int(port),
                        "count": int(count),
                        "category": "ephemeral" if port > 49152 else "rare"
                    })
            
            anomalies["port_anomalies"] = unusual_ports[:20]  # Top 20
            
            return anomalies
        
        except Exception as e:
            logger.error(f"Error detecting statistical anomalies: {e}")
            return {}
    
    async def _generate_visualizations(self, df: pd.DataFrame, time_range: str) -> Dict[str, str]:
        """Generate visualization charts as base64 encoded images"""
        try:
            visualizations = {}
            
            # 1. Threat level distribution pie chart
            plt.figure(figsize=(10, 6))
            threat_counts = df['threat_level'].value_counts()
            colors = ['#dc3545', '#fd7e14', '#ffc107', '#28a745']  # Critical, High, Medium, Low
            plt.pie(threat_counts.values, labels=threat_counts.index, autopct='%1.1f%%', colors=colors)
            plt.title('Threat Level Distribution')
            visualizations['threat_level_pie'] = self._plot_to_base64()
            
            # 2. Events over time
            plt.figure(figsize=(12, 6))
            daily_events = df.groupby('date').size()
            plt.plot(daily_events.index, daily_events.values, marker='o')
            plt.title('Events Over Time')
            plt.xlabel('Date')
            plt.ylabel('Number of Events')
            plt.xticks(rotation=45)
            plt.tight_layout()
            visualizations['events_timeline'] = self._plot_to_base64()
            
            # 3. Hourly activity heatmap
            plt.figure(figsize=(12, 6))
            hourly_data = df.groupby(['day_of_week', 'hour']).size().unstack(fill_value=0)
            day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
            hourly_data.index = day_names
            sns.heatmap(hourly_data, cmap='YlOrRd', annot=False, fmt='d')
            plt.title('Activity Heatmap (Day vs Hour)')
            plt.xlabel('Hour of Day')
            plt.ylabel('Day of Week')
            visualizations['activity_heatmap'] = self._plot_to_base64()
            
            # 4. Top source IPs bar chart
            plt.figure(figsize=(12, 6))
            top_sources = df['source_ip'].value_counts().head(10)
            plt.bar(range(len(top_sources)), top_sources.values)
            plt.title('Top 10 Source IPs by Event Count')
            plt.xlabel('Source IP')
            plt.ylabel('Event Count')
            plt.xticks(range(len(top_sources)), top_sources.index, rotation=45)
            plt.tight_layout()
            visualizations['top_sources_bar'] = self._plot_to_base64()
            
            # 5. Event type distribution
            plt.figure(figsize=(10, 6))
            event_counts = df['event_type'].value_counts()
            plt.bar(event_counts.index, event_counts.values)
            plt.title('Event Type Distribution')
            plt.xlabel('Event Type')
            plt.ylabel('Count')
            plt.xticks(rotation=45)
            plt.tight_layout()
            visualizations['event_types_bar'] = self._plot_to_base64()
            
            # 6. Confidence score distribution
            plt.figure(figsize=(10, 6))
            plt.hist(df['confidence_score'].dropna(), bins=20, alpha=0.7, color='skyblue')
            plt.title('Confidence Score Distribution')
            plt.xlabel('Confidence Score')
            plt.ylabel('Frequency')
            plt.axvline(df['confidence_score'].mean(), color='red', linestyle='--', label='Mean')
            plt.legend()
            visualizations['confidence_histogram'] = self._plot_to_base64()
            
            return visualizations
        
        except Exception as e:
            logger.error(f"Error generating visualizations: {e}")
            return {}
    
    def _plot_to_base64(self) -> str:
        """Convert current matplotlib plot to base64 string"""
        try:
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            return image_base64
        except Exception as e:
            logger.error(f"Error converting plot to base64: {e}")
            plt.close()
            return ""
    
    async def generate_executive_summary(self, time_range: str = "7d") -> Dict[str, Any]:
        """Generate executive summary report"""
        try:
            # Get full threat report
            full_report = await self.generate_threat_report(time_range)
            
            if "error" in full_report:
                return full_report
            
            # Extract key insights for executive summary
            summary = full_report["summary"]
            temporal = full_report["temporal_analysis"]
            
            executive_summary = {
                "report_period": time_range,
                "generated_at": datetime.now().isoformat(),
                "key_metrics": {
                    "total_security_events": summary["total_events"],
                    "unique_threat_sources": summary["unique_source_ips"],
                    "critical_threats": summary["threat_level_distribution"].get("critical", 0),
                    "high_threats": summary["threat_level_distribution"].get("high", 0),
                    "average_confidence": round(summary["average_confidence_score"], 2)
                },
                "threat_landscape": {
                    "most_common_threat": max(summary["event_type_distribution"], key=summary["event_type_distribution"].get),
                    "peak_activity_hour": temporal.get("peak_activity", {}).get("peak_hour", "Unknown"),
                    "trend": temporal.get("trend_analysis", {}).get("trend_direction", "Unknown")
                },
                "top_concerns": [],
                "recommendations": []
            }
            
            # Identify top concerns
            if summary["threat_level_distribution"].get("critical", 0) > 0:
                executive_summary["top_concerns"].append(
                    f"{summary['threat_level_distribution']['critical']} critical threats detected"
                )
            
            if summary["unique_source_ips"] > 100:
                executive_summary["top_concerns"].append(
                    f"High number of unique threat sources ({summary['unique_source_ips']})"
                )
            
            # Generate recommendations
            if summary["average_confidence_score"] < 0.7:
                executive_summary["recommendations"].append(
                    "Review detection rules - average confidence score is below optimal threshold"
                )
            
            if temporal.get("trend_analysis", {}).get("trend_direction") == "increasing":
                executive_summary["recommendations"].append(
                    "Threat activity is trending upward - consider enhanced monitoring"
                )
            
            return executive_summary
        
        except Exception as e:
            logger.error(f"Error generating executive summary: {e}")
            return {"error": str(e)}

# Example usage
async def main():
    """Test the data analytics module"""
    
    # Initialize database manager
    config = DatabaseConfig(backend="sqlite", sqlite_path="test_ids_v2.db")
    db_manager = AdvancedDatabaseManager(config)
    
    # Initialize analytics
    analytics = ThreatAnalytics(db_manager)
    
    # Generate threat report
    report = await analytics.generate_threat_report("24h")
    print(f"Generated threat report with {len(report)} sections")
    
    # Generate executive summary
    summary = await analytics.generate_executive_summary("24h")
    print(f"Executive summary: {json.dumps(summary, indent=2)}")
    
    # Close database
    db_manager.close()
    
    print("Analytics testing completed")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nTesting interrupted by user")
    except Exception as e:
        print(f"Error: {e}")

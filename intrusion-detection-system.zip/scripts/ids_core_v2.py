#!/usr/bin/env python3
"""
Advanced Intrusion Detection System - Core Engine v2.0
Modern async-based architecture with enhanced capabilities
"""

import asyncio
import logging
import json
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, asdict
from enum import Enum
import sqlite3
from pathlib import Path
import signal
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ids_v2.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ThreatLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class EventType(Enum):
    NETWORK_ANOMALY = "network_anomaly"
    MALICIOUS_TRAFFIC = "malicious_traffic"
    PORT_SCAN = "port_scan"
    BRUTE_FORCE = "brute_force"
    MALWARE_DETECTED = "malware_detected"
    POLICY_VIOLATION = "policy_violation"
    SYSTEM_COMPROMISE = "system_compromise"

@dataclass
class SecurityEvent:
    """Enhanced security event with comprehensive metadata"""
    id: str
    timestamp: datetime
    event_type: EventType
    threat_level: ThreatLevel
    source_ip: str
    destination_ip: str
    source_port: int
    destination_port: int
    protocol: str
    description: str
    raw_data: Dict[str, Any]
    confidence_score: float
    mitigation_suggested: List[str]
    tags: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data['timestamp'] = self.timestamp.isoformat()
        data['event_type'] = self.event_type.value
        data['threat_level'] = self.threat_level.value
        return data

class EventProcessor:
    """Advanced event processing with correlation and analysis"""
    
    def __init__(self):
        self.event_handlers: Dict[EventType, List[Callable]] = {}
        self.correlation_rules: List[Dict] = []
        self.event_history: List[SecurityEvent] = []
        self.max_history = 10000
        
    def register_handler(self, event_type: EventType, handler: Callable):
        """Register event handler for specific event types"""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
        logger.info(f"Registered handler for {event_type.value}")
    
    async def process_event(self, event: SecurityEvent):
        """Process security event with correlation analysis"""
        try:
            # Add to history
            self.event_history.append(event)
            if len(self.event_history) > self.max_history:
                self.event_history.pop(0)
            
            # Run correlation analysis
            correlated_events = await self._correlate_events(event)
            
            # Execute registered handlers
            if event.event_type in self.event_handlers:
                for handler in self.event_handlers[event.event_type]:
                    try:
                        await handler(event, correlated_events)
                    except Exception as e:
                        logger.error(f"Handler error: {e}")
            
            logger.info(f"Processed event: {event.event_type.value} from {event.source_ip}")
            
        except Exception as e:
            logger.error(f"Event processing error: {e}")
    
    async def _correlate_events(self, current_event: SecurityEvent) -> List[SecurityEvent]:
        """Correlate current event with historical events"""
        correlated = []
        cutoff_time = current_event.timestamp - timedelta(minutes=30)
        
        for event in reversed(self.event_history[-100:]):  # Check last 100 events
            if event.timestamp < cutoff_time:
                break
                
            # Same source IP correlation
            if (event.source_ip == current_event.source_ip and 
                event.id != current_event.id):
                correlated.append(event)
            
            # Attack pattern correlation
            if (event.event_type in [EventType.PORT_SCAN, EventType.BRUTE_FORCE] and
                current_event.event_type == EventType.SYSTEM_COMPROMISE and
                event.source_ip == current_event.source_ip):
                correlated.append(event)
        
        return correlated

class DatabaseManager:
    """Enhanced database management with async support"""
    
    def __init__(self, db_path: str = "ids_v2.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database with enhanced schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Events table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                threat_level TEXT NOT NULL,
                source_ip TEXT NOT NULL,
                destination_ip TEXT NOT NULL,
                source_port INTEGER,
                destination_port INTEGER,
                protocol TEXT,
                description TEXT,
                raw_data TEXT,
                confidence_score REAL,
                mitigation_suggested TEXT,
                tags TEXT,
                processed BOOLEAN DEFAULT FALSE,
                acknowledged BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # Statistics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS statistics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                metric_value REAL NOT NULL,
                metadata TEXT
            )
        ''')
        
        # Configuration table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS configuration (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')
        
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")
    
    async def store_event(self, event: SecurityEvent):
        """Store security event in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO events 
                (id, timestamp, event_type, threat_level, source_ip, destination_ip,
                 source_port, destination_port, protocol, description, raw_data,
                 confidence_score, mitigation_suggested, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                event.id,
                event.timestamp.isoformat(),
                event.event_type.value,
                event.threat_level.value,
                event.source_ip,
                event.destination_ip,
                event.source_port,
                event.destination_port,
                event.protocol,
                event.description,
                json.dumps(event.raw_data),
                event.confidence_score,
                json.dumps(event.mitigation_suggested),
                json.dumps(event.tags)
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"Database storage error: {e}")
    
    async def get_recent_events(self, limit: int = 100) -> List[Dict]:
        """Retrieve recent security events"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM events 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (limit,))
            
            columns = [description[0] for description in cursor.description]
            events = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            conn.close()
            return events
            
        except Exception as e:
            logger.error(f"Database retrieval error: {e}")
            return []

class ConfigurationManager:
    """Advanced configuration management"""
    
    def __init__(self, config_file: str = "ids_config_v2.json"):
        self.config_file = config_file
        self.config = self.load_config()
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        default_config = {
            "network": {
                "interface": "eth0",
                "capture_filter": "",
                "promiscuous_mode": True
            },
            "detection": {
                "enable_signature_detection": True,
                "enable_anomaly_detection": True,
                "enable_behavioral_analysis": True,
                "confidence_threshold": 0.7
            },
            "alerting": {
                "email_notifications": False,
                "webhook_url": "",
                "alert_cooldown": 300
            },
            "logging": {
                "log_level": "INFO",
                "max_log_size": "100MB",
                "log_retention_days": 30
            },
            "performance": {
                "max_concurrent_events": 1000,
                "event_processing_timeout": 30,
                "database_batch_size": 100
            }
        }
        
        try:
            if Path(self.config_file).exists():
                with open(self.config_file, 'r') as f:
                    loaded_config = json.load(f)
                    # Merge with defaults
                    self._deep_merge(default_config, loaded_config)
            
            return default_config
            
        except Exception as e:
            logger.error(f"Config loading error: {e}")
            return default_config
    
    def _deep_merge(self, base: Dict, update: Dict):
        """Deep merge configuration dictionaries"""
        for key, value in update.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
    
    def save_config(self):
        """Save current configuration to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info("Configuration saved successfully")
        except Exception as e:
            logger.error(f"Config saving error: {e}")
    
    def get(self, key_path: str, default=None):
        """Get configuration value using dot notation"""
        keys = key_path.split('.')
        value = self.config
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value

class IDSCore:
    """Main IDS Core Engine v2.0"""
    
    def __init__(self):
        self.config = ConfigurationManager()
        self.db_manager = DatabaseManager()
        self.event_processor = EventProcessor()
        self.running = False
        self.tasks: List[asyncio.Task] = []
        
        # Statistics
        self.stats = {
            'events_processed': 0,
            'threats_detected': 0,
            'start_time': datetime.now(),
            'last_event_time': None
        }
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info("IDS Core v2.0 initialized")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.stop()
    
    async def start(self):
        """Start the IDS core engine"""
        if self.running:
            logger.warning("IDS Core already running")
            return
        
        self.running = True
        logger.info("Starting IDS Core v2.0...")
        
        try:
            # Start core tasks
            self.tasks.append(asyncio.create_task(self._statistics_updater()))
            self.tasks.append(asyncio.create_task(self._health_monitor()))
            
            # Register default event handlers
            self._register_default_handlers()
            
            # Wait for all tasks
            await asyncio.gather(*self.tasks, return_exceptions=True)
            
        except Exception as e:
            logger.error(f"Core engine error: {e}")
        finally:
            self.running = False
    
    def stop(self):
        """Stop the IDS core engine"""
        self.running = False
        
        # Cancel all tasks
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        logger.info("IDS Core v2.0 stopped")
    
    async def _statistics_updater(self):
        """Update system statistics periodically"""
        while self.running:
            try:
                uptime = datetime.now() - self.stats['start_time']
                
                stats_data = {
                    'uptime_seconds': uptime.total_seconds(),
                    'events_processed': self.stats['events_processed'],
                    'threats_detected': self.stats['threats_detected'],
                    'events_per_minute': self._calculate_event_rate()
                }
                
                logger.debug(f"Stats: {stats_data}")
                await asyncio.sleep(60)  # Update every minute
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Statistics update error: {e}")
                await asyncio.sleep(60)
    
    async def _health_monitor(self):
        """Monitor system health and performance"""
        while self.running:
            try:
                # Check memory usage, disk space, etc.
                import psutil
                
                cpu_percent = psutil.cpu_percent()
                memory_percent = psutil.virtual_memory().percent
                
                if cpu_percent > 90:
                    logger.warning(f"High CPU usage: {cpu_percent}%")
                
                if memory_percent > 90:
                    logger.warning(f"High memory usage: {memory_percent}%")
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health monitor error: {e}")
                await asyncio.sleep(30)
    
    def _calculate_event_rate(self) -> float:
        """Calculate events per minute"""
        if not self.stats['last_event_time']:
            return 0.0
        
        time_diff = (datetime.now() - self.stats['start_time']).total_seconds() / 60
        return self.stats['events_processed'] / max(time_diff, 1)
    
    def _register_default_handlers(self):
        """Register default event handlers"""
        
        async def log_event_handler(event: SecurityEvent, correlated: List[SecurityEvent]):
            """Default logging handler"""
            await self.db_manager.store_event(event)
            self.stats['events_processed'] += 1
            self.stats['last_event_time'] = datetime.now()
            
            if event.threat_level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL]:
                self.stats['threats_detected'] += 1
                logger.warning(f"High threat detected: {event.description}")
        
        async def correlation_handler(event: SecurityEvent, correlated: List[SecurityEvent]):
            """Handle correlated events"""
            if correlated:
                logger.info(f"Event correlation found {len(correlated)} related events")
                
                # Escalate if multiple related events
                if len(correlated) >= 3:
                    logger.critical(f"Attack pattern detected from {event.source_ip}")
        
        # Register handlers for all event types
        for event_type in EventType:
            self.event_processor.register_handler(event_type, log_event_handler)
            self.event_processor.register_handler(event_type, correlation_handler)
    
    async def process_security_event(self, event: SecurityEvent):
        """Process a security event through the engine"""
        await self.event_processor.process_event(event)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get current system statistics"""
        uptime = datetime.now() - self.stats['start_time']
        
        return {
            'uptime_seconds': uptime.total_seconds(),
            'events_processed': self.stats['events_processed'],
            'threats_detected': self.stats['threats_detected'],
            'events_per_minute': self._calculate_event_rate(),
            'running': self.running,
            'last_event_time': self.stats['last_event_time'].isoformat() if self.stats['last_event_time'] else None
        }

# Example usage and testing
async def main():
    """Main function for testing the IDS Core"""
    ids_core = IDSCore()
    
    # Create a test event
    test_event = SecurityEvent(
        id="test_001",
        timestamp=datetime.now(),
        event_type=EventType.PORT_SCAN,
        threat_level=ThreatLevel.MEDIUM,
        source_ip="192.168.1.100",
        destination_ip="192.168.1.1",
        source_port=12345,
        destination_port=22,
        protocol="TCP",
        description="Potential port scan detected",
        raw_data={"packets": 10, "duration": 5},
        confidence_score=0.8,
        mitigation_suggested=["Block source IP", "Monitor for further activity"],
        tags=["reconnaissance", "scanning"]
    )
    
    # Start IDS core in background
    core_task = asyncio.create_task(ids_core.start())
    
    # Process test event
    await ids_core.process_security_event(test_event)
    
    # Show statistics
    stats = ids_core.get_statistics()
    print(f"IDS Statistics: {json.dumps(stats, indent=2)}")
    
    # Stop after a short time
    await asyncio.sleep(5)
    ids_core.stop()
    
    try:
        await core_task
    except asyncio.CancelledError:
        pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")

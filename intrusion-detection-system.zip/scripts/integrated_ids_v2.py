#!/usr/bin/env python3
"""
Integrated IDS System v2.0
Complete integration of all IDS components with the web dashboard
"""

import asyncio
import logging
import signal
import sys
import threading
import time
from datetime import datetime
from typing import Dict, List, Optional

# Import all IDS components
from ids_core_v2 import IDSCore, SecurityEvent, EventType, ThreatLevel
from network_capture_v2 import NetworkCapture
from ml_detection_v2 import AnomalyDetector, ThreatClassifier
from behavioral_analysis_v2 import BehaviorProfiler, AttackPatternDetector
from web_dashboard_v2 import IDSDashboard

logger = logging.getLogger(__name__)

class IntegratedIDSSystem:
    """Complete integrated IDS system with all components"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or self._default_config()
        
        # Initialize core components
        self.ids_core = IDSCore()
        self.network_capture = NetworkCapture(
            interface=self.config.get('network_interface', 'eth0')
        )
        
        # Initialize detection engines
        self.anomaly_detector = AnomalyDetector()
        self.threat_classifier = ThreatClassifier()
        self.behavior_profiler = BehaviorProfiler()
        self.pattern_detector = AttackPatternDetector()
        
        # Initialize web dashboard
        self.dashboard = IDSDashboard(
            host=self.config.get('dashboard_host', '0.0.0.0'),
            port=self.config.get('dashboard_port', 5000)
        )
        
        # System state
        self.running = False
        self.components_started = False
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        # Setup component integration
        self._setup_integration()
        
        logger.info("Integrated IDS System v2.0 initialized")
    
    def _default_config(self) -> Dict:
        """Default system configuration"""
        return {
            'network_interface': 'eth0',
            'dashboard_host': '0.0.0.0',
            'dashboard_port': 5000,
            'enable_ml_detection': True,
            'enable_behavioral_analysis': True,
            'enable_pattern_detection': True,
            'log_level': 'INFO',
            'auto_start_monitoring': True
        }
    
    def _setup_integration(self):
        """Setup integration between components"""
        
        # Connect network capture to IDS core
        self.network_capture.set_ids_core(self.ids_core)
        
        # Setup enhanced event processing
        async def enhanced_event_handler(event: SecurityEvent, correlated: List[SecurityEvent]):
            """Enhanced event handler with ML and behavioral analysis"""
            try:
                # Run ML detection if enabled
                if self.config.get('enable_ml_detection', True):
                    # Convert event to packet format for ML analysis
                    packet_data = [{
                        'timestamp': event.timestamp.isoformat(),
                        'source_ip': event.source_ip,
                        'destination_ip': event.destination_ip,
                        'source_port': event.source_port,
                        'destination_port': event.destination_port,
                        'protocol': event.protocol,
                        'packet_size': event.raw_data.get('packet_size', 0),
                        'flags': event.raw_data.get('flags', {}),
                        'payload': event.raw_data.get('payload', b'')
                    }]
                    
                    # Run anomaly detection
                    anomaly_event = await self.anomaly_detector.detect_anomaly(packet_data)
                    if anomaly_event:
                        await self.ids_core.process_security_event(anomaly_event)
                    
                    # Run threat classification
                    threat_event = await self.threat_classifier.classify_threat(packet_data)
                    if threat_event:
                        await self.ids_core.process_security_event(threat_event)
                
                # Run behavioral analysis if enabled
                if self.config.get('enable_behavioral_analysis', True):
                    # Update behavioral profiles
                    await self.behavior_profiler.update_network_profile(
                        event.source_ip,
                        {
                            'protocol': event.protocol,
                            'destination_port': event.destination_port,
                            'bytes_transferred': event.raw_data.get('packet_size', 0),
                            'destination_country': 'unknown'  # Would need GeoIP lookup
                        }
                    )
                    
                    # Check for behavioral anomalies
                    behavioral_events = await self.behavior_profiler.detect_network_anomalies(
                        event.source_ip,
                        {
                            'protocol': event.protocol,
                            'destination_port': event.destination_port,
                            'bytes_transferred': event.raw_data.get('packet_size', 0)
                        }
                    )
                    
                    for behavioral_event in behavioral_events:
                        await self.ids_core.process_security_event(behavioral_event)
                
                # Run pattern detection if enabled
                if self.config.get('enable_pattern_detection', True):
                    pattern_events = await self.pattern_detector.analyze_attack_patterns(event)
                    for pattern_event in pattern_events:
                        await self.ids_core.process_security_event(pattern_event)
                
            except Exception as e:
                logger.error(f"Enhanced event handler error: {e}")
        
        # Register enhanced handler for all event types
        for event_type in EventType:
            self.ids_core.event_processor.register_handler(event_type, enhanced_event_handler)
        
        # Connect components to dashboard
        self.dashboard.ids_core = self.ids_core
        self.dashboard.network_capture = self.network_capture
        self.dashboard.anomaly_detector = self.anomaly_detector
        self.dashboard.threat_classifier = self.threat_classifier
        self.dashboard.behavior_profiler = self.behavior_profiler
        self.dashboard.pattern_detector = self.pattern_detector
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.stop()
        sys.exit(0)
    
    async def start_components(self):
        """Start all IDS components"""
        if self.components_started:
            logger.warning("Components already started")
            return
        
        logger.info("Starting IDS components...")
        
        try:
            # Start IDS core
            core_task = asyncio.create_task(self.ids_core.start())
            
            # Start network capture
            capture_task = asyncio.create_task(self.network_capture.start_capture())
            
            # Wait a bit for components to initialize
            await asyncio.sleep(2)
            
            self.components_started = True
            logger.info("All IDS components started successfully")
            
            # Keep components running
            await asyncio.gather(core_task, capture_task, return_exceptions=True)
            
        except Exception as e:
            logger.error(f"Error starting components: {e}")
            self.components_started = False
    
    def start_dashboard(self):
        """Start the web dashboard"""
        logger.info("Starting web dashboard...")
        
        try:
            # Start dashboard in separate thread
            dashboard_thread = threading.Thread(
                target=self.dashboard.run,
                kwargs={'debug': False},
                daemon=True
            )
            dashboard_thread.start()
            
            logger.info(f"Web dashboard started on http://{self.config['dashboard_host']}:{self.config['dashboard_port']}")
            return dashboard_thread
            
        except Exception as e:
            logger.error(f"Error starting dashboard: {e}")
            return None
    
    def start(self):
        """Start the complete integrated IDS system"""
        if self.running:
            logger.warning("IDS system already running")
            return
        
        self.running = True
        logger.info("Starting Integrated IDS System v2.0...")
        
        try:
            # Start web dashboard first
            dashboard_thread = self.start_dashboard()
            
            if not dashboard_thread:
                logger.error("Failed to start dashboard")
                return
            
            # Auto-start monitoring if configured
            if self.config.get('auto_start_monitoring', True):
                time.sleep(3)  # Give dashboard time to initialize
                logger.info("Auto-starting monitoring components...")
                
                # Start components in background
                components_thread = threading.Thread(
                    target=lambda: asyncio.run(self.start_components()),
                    daemon=True
                )
                components_thread.start()
            
            # Keep main thread alive
            logger.info("IDS System running. Access dashboard at http://localhost:5000")
            logger.info("Press Ctrl+C to stop the system")
            
            try:
                while self.running:
                    time.sleep(1)
            except KeyboardInterrupt:
                logger.info("Shutdown requested by user")
            
        except Exception as e:
            logger.error(f"Error running IDS system: {e}")
        finally:
            self.stop()
    
    def stop(self):
        """Stop the complete IDS system"""
        if not self.running:
            return
        
        logger.info("Stopping Integrated IDS System...")
        self.running = False
        
        # Stop components
        if self.components_started:
            self.ids_core.stop()
            self.network_capture.stop_capture()
            self.components_started = False
        
        # Stop dashboard
        if hasattr(self.dashboard, '_stop_background_tasks'):
            self.dashboard._stop_background_tasks()
        
        logger.info("IDS System stopped")
    
    def get_system_status(self) -> Dict:
        """Get comprehensive system status"""
        return {
            'system_running': self.running,
            'components_started': self.components_started,
            'ids_stats': self.ids_core.get_statistics() if self.components_started else {},
            'capture_stats': self.network_capture.get_statistics() if self.components_started else {},
            'dashboard_url': f"http://{self.config['dashboard_host']}:{self.config['dashboard_port']}",
            'config': self.config,
            'timestamp': datetime.now().isoformat()
        }

# Main execution
def main():
    """Main function to run the integrated IDS system"""
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('integrated_ids_v2.log'),
            logging.StreamHandler()
        ]
    )
    
    # Custom configuration (optional)
    custom_config = {
        'network_interface': 'lo',  # Use loopback for testing
        'dashboard_host': '0.0.0.0',
        'dashboard_port': 5000,
        'enable_ml_detection': True,
        'enable_behavioral_analysis': True,
        'enable_pattern_detection': True,
        'auto_start_monitoring': True
    }
    
    # Initialize and start IDS system
    ids_system = IntegratedIDSSystem(config=custom_config)
    
    try:
        # Print system information
        print("\n" + "="*60)
        print("INTEGRATED INTRUSION DETECTION SYSTEM v2.0")
        print("="*60)
        print(f"Dashboard URL: http://localhost:5000")
        print(f"Network Interface: {custom_config['network_interface']}")
        print(f"ML Detection: {'Enabled' if custom_config['enable_ml_detection'] else 'Disabled'}")
        print(f"Behavioral Analysis: {'Enabled' if custom_config['enable_behavioral_analysis'] else 'Disabled'}")
        print(f"Pattern Detection: {'Enabled' if custom_config['enable_pattern_detection'] else 'Disabled'}")
        print("="*60)
        print("Starting system...")
        print("="*60 + "\n")
        
        # Start the system
        ids_system.start()
        
    except Exception as e:
        logger.error(f"System error: {e}")
        print(f"Error: {e}")
    finally:
        print("\nSystem shutdown complete.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Intrusion Detection System - REST API v2.0
Comprehensive REST API for IDS management and monitoring
"""

from fastapi import FastAPI, HTTPException, Depends, status, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import asyncio
import logging
import jwt
import hashlib
from datetime import datetime, timedelta
import uvicorn
import os

# Import IDS components
try:
    from ids_core_v2 import IDSCore
    from network_capture_v2 import NetworkCapture
    from ml_detection_v2 import MLAnomalyDetector, ThreatClassifier
    from behavioral_analysis_v2 import BehaviorAnalyzer, AttackPatternDetector
    from database_manager_v2 import DatabaseManager
    from data_analytics_v2 import DataAnalytics
except ImportError as e:
    print(f"Error importing IDS components: {e}")

# Pydantic models for API requests/responses
class SystemStatus(BaseModel):
    status: str
    uptime: float
    components_loaded: int
    monitoring_active: bool
    packets_processed: int
    threats_detected: int
    alerts_generated: int

class AlertResponse(BaseModel):
    id: Optional[int]
    timestamp: datetime
    type: str
    severity: str
    source_ip: Optional[str]
    destination_ip: Optional[str]
    description: str
    data: Dict[str, Any]

class ConfigurationUpdate(BaseModel):
    section: str
    key: str
    value: Any

class DetectionRule(BaseModel):
    name: str
    pattern: str
    severity: str
    enabled: bool = True
    description: Optional[str] = None

class UserCredentials(BaseModel):
    username: str
    password: str

class APIResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None

# Global IDS instance
ids_instance = None
security = HTTPBearer()

# JWT Configuration
SECRET_KEY = "your-secret-key-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Simple user store (in production, use proper database)
USERS_DB = {
    "admin": {
        "username": "admin",
        "password_hash": hashlib.sha256("admin123".encode()).hexdigest(),
        "role": "admin"
    },
    "analyst": {
        "username": "analyst",
        "password_hash": hashlib.sha256("analyst123".encode()).hexdigest(),
        "role": "analyst"
    }
}

class IDSRestAPI:
    """REST API for Intrusion Detection System"""
    
    def __init__(self):
        self.app = FastAPI(
            title="Intrusion Detection System API",
            description="Comprehensive REST API for IDS management and monitoring",
            version="2.0.0",
            docs_url="/docs",
            redoc_url="/redoc"
        )
        
        # Add CORS middleware
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        self.setup_logging()
        self.components = {}
        self.monitoring_active = False
        self.stats = {
            'start_time': datetime.now(),
            'packets_processed': 0,
            'threats_detected': 0,
            'alerts_generated': 0
        }
        
        self.setup_routes()
    
    def setup_logging(self):
        """Setup API logging"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("IDS-API")
    
    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None):
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=15)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return encoded_jwt
    
    def verify_token(self, credentials: HTTPAuthorizationCredentials = Depends(security)):
        """Verify JWT token"""
        try:
            payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
            username: str = payload.get("sub")
            if username is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Could not validate credentials"
                )
            return username
        except jwt.PyJWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )
    
    async def initialize_components(self):
        """Initialize all IDS components"""
        try:
            self.logger.info("Initializing IDS components for API...")
            
            # Initialize database
            self.components['database'] = DatabaseManager()
            await self.components['database'].initialize()
            
            # Initialize core components
            self.components['core'] = IDSCore()
            self.components['network'] = NetworkCapture()
            self.components['ml_detector'] = MLAnomalyDetector()
            self.components['threat_classifier'] = ThreatClassifier()
            self.components['behavior_analyzer'] = BehaviorAnalyzer()
            self.components['attack_detector'] = AttackPatternDetector()
            self.components['analytics'] = DataAnalytics(self.components['database'])
            
            self.logger.info("All API components initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize API components: {e}")
            return False
    
    def setup_routes(self):
        """Setup all API routes"""
        
        # Authentication endpoints
        @self.app.post("/auth/login", response_model=Dict[str, str])
        async def login(credentials: UserCredentials):
            """Authenticate user and return JWT token"""
            user = USERS_DB.get(credentials.username)
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )
            
            password_hash = hashlib.sha256(credentials.password.encode()).hexdigest()
            if password_hash != user["password_hash"]:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )
            
            access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
            access_token = self.create_access_token(
                data={"sub": credentials.username, "role": user["role"]},
                expires_delta=access_token_expires
            )
            
            return {
                "access_token": access_token,
                "token_type": "bearer",
                "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
            }
        
        # System control endpoints
        @self.app.get("/system/status", response_model=SystemStatus)
        async def get_system_status(username: str = Depends(self.verify_token)):
            """Get current system status"""
            uptime = (datetime.now() - self.stats['start_time']).total_seconds()
            
            return SystemStatus(
                status="running" if self.monitoring_active else "stopped",
                uptime=uptime,
                components_loaded=len(self.components),
                monitoring_active=self.monitoring_active,
                packets_processed=self.stats['packets_processed'],
                threats_detected=self.stats['threats_detected'],
                alerts_generated=self.stats['alerts_generated']
            )
        
        @self.app.post("/system/start", response_model=APIResponse)
        async def start_monitoring(background_tasks: BackgroundTasks, username: str = Depends(self.verify_token)):
            """Start IDS monitoring"""
            if self.monitoring_active:
                return APIResponse(
                    success=False,
                    message="Monitoring is already active"
                )
            
            try:
                background_tasks.add_task(self._start_monitoring_background)
                return APIResponse(
                    success=True,
                    message="IDS monitoring started successfully"
                )
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to start monitoring: {str(e)}"
                )
        
        @self.app.post("/system/stop", response_model=APIResponse)
        async def stop_monitoring(username: str = Depends(self.verify_token)):
            """Stop IDS monitoring"""
            if not self.monitoring_active:
                return APIResponse(
                    success=False,
                    message="Monitoring is not active"
                )
            
            try:
                self.monitoring_active = False
                return APIResponse(
                    success=True,
                    message="IDS monitoring stopped successfully"
                )
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to stop monitoring: {str(e)}"
                )
        
        # Alert management endpoints
        @self.app.get("/alerts", response_model=List[AlertResponse])
        async def get_alerts(
            limit: int = 100,
            severity: Optional[str] = None,
            username: str = Depends(self.verify_token)
        ):
            """Get recent alerts"""
            try:
                if 'database' not in self.components:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="Database component not available"
                    )
                
                alerts = await self.components['database'].get_recent_alerts(
                    limit=limit,
                    severity_filter=severity
                )
                
                return [
                    AlertResponse(
                        id=alert.get('id'),
                        timestamp=alert.get('timestamp', datetime.now()),
                        type=alert.get('type', 'unknown'),
                        severity=alert.get('severity', 'medium'),
                        source_ip=alert.get('source_ip'),
                        destination_ip=alert.get('destination_ip'),
                        description=alert.get('description', ''),
                        data=alert.get('data', {})
                    )
                    for alert in alerts
                ]
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to retrieve alerts: {str(e)}"
                )
        
        @self.app.get("/alerts/{alert_id}", response_model=AlertResponse)
        async def get_alert_details(alert_id: int, username: str = Depends(self.verify_token)):
            """Get detailed information about a specific alert"""
            try:
                if 'database' not in self.components:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="Database component not available"
                    )
                
                alert = await self.components['database'].get_alert_by_id(alert_id)
                if not alert:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Alert not found"
                    )
                
                return AlertResponse(
                    id=alert.get('id'),
                    timestamp=alert.get('timestamp', datetime.now()),
                    type=alert.get('type', 'unknown'),
                    severity=alert.get('severity', 'medium'),
                    source_ip=alert.get('source_ip'),
                    destination_ip=alert.get('destination_ip'),
                    description=alert.get('description', ''),
                    data=alert.get('data', {})
                )
                
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to retrieve alert: {str(e)}"
                )
        
        # Analytics endpoints
        @self.app.get("/analytics/report", response_model=Dict[str, Any])
        async def get_analytics_report(username: str = Depends(self.verify_token)):
            """Generate comprehensive analytics report"""
            try:
                if 'analytics' not in self.components:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="Analytics component not available"
                    )
                
                report = await self.components['analytics'].generate_security_report()
                return report
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to generate report: {str(e)}"
                )
        
        @self.app.get("/analytics/statistics", response_model=Dict[str, Any])
        async def get_statistics(username: str = Depends(self.verify_token)):
            """Get real-time system statistics"""
            try:
                uptime = (datetime.now() - self.stats['start_time']).total_seconds()
                
                return {
                    "uptime_seconds": uptime,
                    "packets_processed": self.stats['packets_processed'],
                    "threats_detected": self.stats['threats_detected'],
                    "alerts_generated": self.stats['alerts_generated'],
                    "monitoring_active": self.monitoring_active,
                    "components_status": {
                        name: "active" for name in self.components.keys()
                    }
                }
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to get statistics: {str(e)}"
                )
        
        # Configuration endpoints
        @self.app.get("/config", response_model=Dict[str, Any])
        async def get_configuration(username: str = Depends(self.verify_token)):
            """Get current system configuration"""
            try:
                # Return mock configuration for now
                return {
                    "monitoring": {
                        "interface": "eth0",
                        "capture_filter": "",
                        "packet_limit": 1000
                    },
                    "detection": {
                        "ml_threshold": 0.7,
                        "behavioral_threshold": 0.8,
                        "signature_matching": True
                    },
                    "alerts": {
                        "email_notifications": True,
                        "webhook_url": "",
                        "severity_threshold": "medium"
                    }
                }
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to get configuration: {str(e)}"
                )
        
        @self.app.post("/config", response_model=APIResponse)
        async def update_configuration(
            config_update: ConfigurationUpdate,
            username: str = Depends(self.verify_token)
        ):
            """Update system configuration"""
            try:
                # Mock configuration update
                self.logger.info(f"Configuration update: {config_update.section}.{config_update.key} = {config_update.value}")
                
                return APIResponse(
                    success=True,
                    message=f"Configuration updated: {config_update.section}.{config_update.key}",
                    data={"section": config_update.section, "key": config_update.key, "value": config_update.value}
                )
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to update configuration: {str(e)}"
                )
        
        # Detection rules endpoints
        @self.app.get("/rules", response_model=List[DetectionRule])
        async def get_detection_rules(username: str = Depends(self.verify_token)):
            """Get all detection rules"""
            try:
                # Mock detection rules
                return [
                    DetectionRule(
                        name="Port Scan Detection",
                        pattern="multiple_connections_same_source",
                        severity="high",
                        enabled=True,
                        description="Detects port scanning activities"
                    ),
                    DetectionRule(
                        name="SQL Injection",
                        pattern="sql_injection_patterns",
                        severity="critical",
                        enabled=True,
                        description="Detects SQL injection attempts"
                    ),
                    DetectionRule(
                        name="DDoS Detection",
                        pattern="high_connection_rate",
                        severity="high",
                        enabled=True,
                        description="Detects DDoS attacks"
                    )
                ]
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to get detection rules: {str(e)}"
                )
        
        @self.app.post("/rules", response_model=APIResponse)
        async def create_detection_rule(
            rule: DetectionRule,
            username: str = Depends(self.verify_token)
        ):
            """Create a new detection rule"""
            try:
                self.logger.info(f"Creating detection rule: {rule.name}")
                
                return APIResponse(
                    success=True,
                    message=f"Detection rule '{rule.name}' created successfully",
                    data=rule.dict()
                )
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to create detection rule: {str(e)}"
                )
        
        # Health check endpoint
        @self.app.get("/health")
        async def health_check():
            """Health check endpoint"""
            return {"status": "healthy", "timestamp": datetime.now()}
    
    async def _start_monitoring_background(self):
        """Start monitoring in background"""
        try:
            self.monitoring_active = True
            self.logger.info("Background monitoring started")
            
            # Start core monitoring components
            if 'core' in self.components:
                await self.components['core'].start_monitoring()
                
        except Exception as e:
            self.logger.error(f"Error in background monitoring: {e}")
            self.monitoring_active = False

# Global API instance
api_instance = IDSRestAPI()

async def startup_event():
    """Startup event handler"""
    await api_instance.initialize_components()

# Add startup event
api_instance.app.add_event_handler("startup", startup_event)

def run_api_server(host="127.0.0.1", port=8000):
    """Run the API server"""
    print(f"Starting IDS REST API server at http://{host}:{port}")
    print(f"API Documentation: http://{host}:{port}/docs")
    print(f"Alternative Docs: http://{host}:{port}/redoc")
    
    uvicorn.run(
        "rest_api_v2:api_instance.app",
        host=host,
        port=port,
        reload=False,
        log_level="info"
    )

if __name__ == "__main__":
    run_api_server()

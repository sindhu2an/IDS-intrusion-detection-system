#!/usr/bin/env python3
"""
Network Monitoring Module for IDS
Monitors network interfaces and system resources
"""

import psutil
import time
import json
import logging
from datetime import datetime
from collections import defaultdict, deque

class NetworkMonitor:
    def __init__(self, monitoring_interval=5):
        self.monitoring_interval = monitoring_interval
        self.network_stats = deque(maxlen=1000)
        self.interface_stats = defaultdict(lambda: deque(maxlen=100))
        self.running = False
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
    def get_network_interfaces(self):
        """Get all network interfaces"""
        interfaces = {}
        for interface, addrs in psutil.net_if_addrs().items():
            interface_info = {
                'name': interface,
                'addresses': []
            }
            
            for addr in addrs:
                interface_info['addresses'].append({
                    'family': str(addr.family),
                    'address': addr.address,
                    'netmask': addr.netmask,
                    'broadcast': addr.broadcast
                })
            
            interfaces[interface] = interface_info
        
        return interfaces
    
    def get_network_stats(self):
        """Get current network statistics"""
        net_io = psutil.net_io_counters(pernic=True)
        connections = psutil.net_connections()
        
        stats = {
            'timestamp': datetime.now().isoformat(),
            'interfaces': {},
            'connections': {
                'total': len(connections),
                'established': len([c for c in connections if c.status == 'ESTABLISHED']),
                'listening': len([c for c in connections if c.status == 'LISTEN']),
                'time_wait': len([c for c in connections if c.status == 'TIME_WAIT'])
            },
            'system': {
                'cpu_percent': psutil.cpu_percent(),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent
            }
        }
        
        # Interface statistics
        for interface, io_stats in net_io.items():
            stats['interfaces'][interface] = {
                'bytes_sent': io_stats.bytes_sent,
                'bytes_recv': io_stats.bytes_recv,
                'packets_sent': io_stats.packets_sent,
                'packets_recv': io_stats.packets_recv,
                'errin': io_stats.errin,
                'errout': io_stats.errout,
                'dropin': io_stats.dropin,
                'dropout': io_stats.dropout
            }
        
        return stats
    
    def detect_network_anomalies(self, current_stats, previous_stats=None):
        """Detect network anomalies"""
        anomalies = []
        
        if not previous_stats:
            return anomalies
        
        # Check for unusual traffic spikes
        for interface in current_stats['interfaces']:
            if interface in previous_stats['interfaces']:
                current_bytes = current_stats['interfaces'][interface]['bytes_recv']
                previous_bytes = previous_stats['interfaces'][interface]['bytes_recv']
                
                bytes_diff = current_bytes - previous_bytes
                
                # Threshold: 100MB in monitoring interval
                if bytes_diff > 100 * 1024 * 1024:
                    anomalies.append({
                        'type': 'traffic_spike',
                        'interface': interface,
                        'bytes_received': bytes_diff,
                        'timestamp': current_stats['timestamp']
                    })
        
        # Check for too many connections
        if current_stats['connections']['total'] > 1000:
            anomalies.append({
                'type': 'high_connection_count',
                'count': current_stats['connections']['total'],
                'timestamp': current_stats['timestamp']
            })
        
        # Check system resources
        if current_stats['system']['cpu_percent'] > 90:
            anomalies.append({
                'type': 'high_cpu_usage',
                'cpu_percent': current_stats['system']['cpu_percent'],
                'timestamp': current_stats['timestamp']
            })
        
        if current_stats['system']['memory_percent'] > 90:
            anomalies.append({
                'type': 'high_memory_usage',
                'memory_percent': current_stats['system']['memory_percent'],
                'timestamp': current_stats['timestamp']
            })
        
        return anomalies
    
    def monitor_network(self):
        """Main monitoring loop"""
        self.logger.info("Starting network monitoring")
        previous_stats = None
        
        while self.running:
            try:
                current_stats = self.get_network_stats()
                self.network_stats.append(current_stats)
                
                # Detect anomalies
                anomalies = self.detect_network_anomalies(current_stats, previous_stats)
                
                for anomaly in anomalies:
                    self.logger.warning(f"Network anomaly detected: {anomaly}")
                
                previous_stats = current_stats
                time.sleep(self.monitoring_interval)
                
            except Exception as e:
                self.logger.error(f"Error in network monitoring: {e}")
                time.sleep(self.monitoring_interval)
    
    def start_monitoring(self):
        """Start network monitoring"""
        if self.running:
            return
        
        self.running = True
        import threading
        self.monitor_thread = threading.Thread(target=self.monitor_network)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        self.logger.info("Network monitoring started")
    
    def stop_monitoring(self):
        """Stop network monitoring"""
        self.running = False
        self.logger.info("Network monitoring stopped")
    
    def get_current_status(self):
        """Get current network status"""
        if not self.network_stats:
            return None
        
        return self.network_stats[-1]
    
    def export_stats(self, filename=None):
        """Export network statistics"""
        if not filename:
            filename = f"network_stats_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(list(self.network_stats), f, indent=2)
            self.logger.info(f"Network stats exported to {filename}")
            return filename
        except Exception as e:
            self.logger.error(f"Failed to export stats: {e}")
            return None

def main():
    """Test network monitoring"""
    print("Network Monitor Test")
    print("=" * 30)
    
    monitor = NetworkMonitor(monitoring_interval=2)
    
    try:
        # Get interfaces
        interfaces = monitor.get_network_interfaces()
        print(f"Found {len(interfaces)} network interfaces:")
        for name, info in interfaces.items():
            print(f"  {name}: {len(info['addresses'])} addresses")
        
        # Start monitoring
        monitor.start_monitoring()
        
        # Monitor for 20 seconds
        print("\nMonitoring network for 20 seconds...")
        time.sleep(20)
        
        # Stop monitoring
        monitor.stop_monitoring()
        
        # Show current status
        status = monitor.get_current_status()
        if status:
            print(f"\nFinal Status:")
            print(f"Total connections: {status['connections']['total']}")
            print(f"CPU usage: {status['system']['cpu_percent']}%")
            print(f"Memory usage: {status['system']['memory_percent']}%")
        
        # Export stats
        export_file = monitor.export_stats()
        if export_file:
            print(f"Stats exported to: {export_file}")
            
    except KeyboardInterrupt:
        print("\nMonitoring interrupted")
        monitor.stop_monitoring()

if __name__ == "__main__":
    main()

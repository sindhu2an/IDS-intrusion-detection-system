"""
Premium Intrusion Detection System
A sophisticated cybersecurity monitoring platform with real-time threat detection
"""

import asyncio
import json
import sqlite3
import threading
import time
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import psutil
import random
import logging
from typing import Dict, List, Any
import os

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PremiumIDS:
    def __init__(self):
        self.app = Flask(__name__, template_folder='templates')
        self.app.config['SECRET_KEY'] = 'premium_ids_secret_key_2024'
        self.socketio = SocketIO(self.app, cors_allowed_origins="*")
        
        self.monitoring = False
        self.alerts = []
        self.system_stats = {}
        self.threat_patterns = {
            'port_scan': {'count': 0, 'last_seen': None},
            'brute_force': {'count': 0, 'last_seen': None},
            'malware': {'count': 0, 'last_seen': None},
            'ddos': {'count': 0, 'last_seen': None},
            'intrusion': {'count': 0, 'last_seen': None}
        }
        
        self.init_database()
        self.setup_routes()
        self.setup_socketio()
        
    def init_database(self):
        """Initialize SQLite database for storing alerts and events"""
        try:
            conn = sqlite3.connect('premium_ids.db')
            cursor = conn.cursor()
            
            # Create alerts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    threat_type TEXT NOT NULL,
                    source_ip TEXT,
                    target_ip TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'active'
                )
            ''')
            
            # Create events table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    details TEXT,
                    processed BOOLEAN DEFAULT FALSE
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("Database initialized successfully")
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
    
    def setup_routes(self):
        """Setup Flask routes"""
        
        @self.app.route('/')
        def dashboard():
            return render_template('premium_dashboard.html')
        
        @self.app.route('/api/system-stats')
        def get_system_stats():
            return jsonify(self.get_system_statistics())
        
        @self.app.route('/api/alerts')
        def get_alerts():
            return jsonify(self.get_recent_alerts())
        
        @self.app.route('/api/threats')
        def get_threats():
            return jsonify(self.threat_patterns)
        
        @self.app.route('/api/start-monitoring', methods=['POST'])
        def start_monitoring():
            if not self.monitoring:
                self.start_threat_detection()
                return jsonify({'status': 'success', 'message': 'Monitoring started'})
            return jsonify({'status': 'info', 'message': 'Already monitoring'})
        
        @self.app.route('/api/stop-monitoring', methods=['POST'])
        def stop_monitoring():
            self.monitoring = False
            return jsonify({'status': 'success', 'message': 'Monitoring stopped'})
    
    def setup_socketio(self):
        """Setup WebSocket events"""
        
        @self.socketio.on('connect')
        def handle_connect():
            logger.info('Client connected to WebSocket')
            emit('status', {'message': 'Connected to Premium IDS'})
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            logger.info('Client disconnected from WebSocket')
    
    def get_system_statistics(self) -> Dict[str, Any]:
        """Get current system performance statistics"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            network = psutil.net_io_counters()
            
            return {
                'cpu_usage': cpu_percent,
                'memory_usage': memory.percent,
                'memory_total': memory.total // (1024**3),  # GB
                'memory_used': memory.used // (1024**3),   # GB
                'disk_usage': disk.percent,
                'disk_total': disk.total // (1024**3),     # GB
                'disk_used': disk.used // (1024**3),       # GB
                'network_sent': network.bytes_sent // (1024**2),  # MB
                'network_recv': network.bytes_recv // (1024**2),  # MB
                'active_connections': len(psutil.net_connections()),
                'processes': len(psutil.pids())
            }
        except Exception as e:
            logger.error(f"Error getting system stats: {e}")
            return {}
    
    def generate_threat_alert(self) -> Dict[str, Any]:
        """Generate realistic threat alerts"""
        threat_types = ['port_scan', 'brute_force', 'malware', 'ddos', 'intrusion']
        severities = ['critical', 'high', 'medium', 'low']
        
        threat_type = random.choice(threat_types)
        severity = random.choice(severities)
        
        # Generate realistic IP addresses
        source_ip = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
        target_ip = f"192.168.1.{random.randint(1,254)}"
        
        descriptions = {
            'port_scan': f"Port scan detected from {source_ip} targeting multiple ports",
            'brute_force': f"Brute force attack detected from {source_ip} on SSH service",
            'malware': f"Malware signature detected in traffic from {source_ip}",
            'ddos': f"DDoS attack pattern detected from {source_ip}",
            'intrusion': f"Unauthorized access attempt from {source_ip}"
        }
        
        alert = {
            'id': len(self.alerts) + 1,
            'timestamp': datetime.now().isoformat(),
            'severity': severity,
            'threat_type': threat_type,
            'source_ip': source_ip,
            'target_ip': target_ip,
            'description': descriptions[threat_type],
            'status': 'active'
        }
        
        # Update threat patterns
        self.threat_patterns[threat_type]['count'] += 1
        self.threat_patterns[threat_type]['last_seen'] = alert['timestamp']
        
        return alert
    
    def store_alert(self, alert: Dict[str, Any]):
        """Store alert in database"""
        try:
            conn = sqlite3.connect('premium_ids.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO alerts (timestamp, severity, threat_type, source_ip, target_ip, description, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                alert['timestamp'], alert['severity'], alert['threat_type'],
                alert['source_ip'], alert['target_ip'], alert['description'], alert['status']
            ))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error storing alert: {e}")
    
    def get_recent_alerts(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent alerts from database"""
        try:
            conn = sqlite3.connect('premium_ids.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, timestamp, severity, threat_type, source_ip, target_ip, description, status
                FROM alerts
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (limit,))
            
            alerts = []
            for row in cursor.fetchall():
                alerts.append({
                    'id': row[0],
                    'timestamp': row[1],
                    'severity': row[2],
                    'threat_type': row[3],
                    'source_ip': row[4],
                    'target_ip': row[5],
                    'description': row[6],
                    'status': row[7]
                })
            
            conn.close()
            return alerts
        except Exception as e:
            logger.error(f"Error getting alerts: {e}")
            return []
    
    def threat_detection_loop(self):
        """Main threat detection loop"""
        while self.monitoring:
            try:
                # Generate threat alert (simulate detection)
                if random.random() < 0.3:  # 30% chance of generating alert
                    alert = self.generate_threat_alert()
                    self.alerts.append(alert)
                    self.store_alert(alert)
                    
                    # Emit alert via WebSocket
                    self.socketio.emit('new_alert', alert)
                    logger.info(f"New {alert['severity']} alert: {alert['threat_type']}")
                
                # Update system statistics
                self.system_stats = self.get_system_statistics()
                self.socketio.emit('system_stats', self.system_stats)
                
                # Keep only last 100 alerts in memory
                if len(self.alerts) > 100:
                    self.alerts = self.alerts[-100:]
                
                time.sleep(2)  # Check every 2 seconds
                
            except Exception as e:
                logger.error(f"Error in threat detection loop: {e}")
                time.sleep(5)
    
    def start_threat_detection(self):
        """Start threat detection in background thread"""
        if not self.monitoring:
            self.monitoring = True
            detection_thread = threading.Thread(target=self.threat_detection_loop)
            detection_thread.daemon = True
            detection_thread.start()
            logger.info("Threat detection started")
    
    def run(self, host='127.0.0.1', port=5000, debug=False):
        """Run the Premium IDS application"""
        logger.info(f"Starting Premium IDS on {host}:{port}")
        self.socketio.run(self.app, host=host, port=port, debug=debug)

if __name__ == '__main__':
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    
    # Initialize and run Premium IDS
    ids = PremiumIDS()
    
    print("=" * 60)
    print("🛡️  PREMIUM INTRUSION DETECTION SYSTEM v2.0")
    print("=" * 60)
    print("🌐 Web Dashboard: http://127.0.0.1:5000")
    print("🔒 Features: Real-time monitoring, Advanced analytics")
    print("⚡ Status: Starting up...")
    print("=" * 60)
    
    try:
        ids.run(host='127.0.0.1', port=5000, debug=False)
    except KeyboardInterrupt:
        print("\n🛑 Premium IDS shutting down...")
    except Exception as e:
        print(f"❌ Error starting Premium IDS: {e}")

#!/usr/bin/env python3
"""
Detection Engine for Intrusion Detection System
Implements various detection algorithms including signature-based and anomaly-based detection
"""

import re
import json
import time
import logging
import hashlib
import statistics
from datetime import datetime, timedelta
from collections import defaultdict, deque
from typing import Dict, List, Any, Optional
import ipaddress

class DetectionRule:
    """Represents a detection rule"""
    def __init__(self, rule_id: str, name: str, description: str, 
                 pattern: str, severity: str, category: str):
        self.rule_id = rule_id
        self.name = name
        self.description = description
        self.pattern = re.compile(pattern, re.IGNORECASE) if pattern else None
        self.severity = severity  # critical, high, medium, low
        self.category = category  # malware, dos, scan, exploit, etc.
        self.matches = 0
        self.last_match = None

class SignatureDetection:
    """Signature-based detection engine"""
    
    def __init__(self):
        self.rules = {}
        self.logger = logging.getLogger(__name__)
        self.load_default_rules()
    
    def load_default_rules(self):
        """Load default detection rules"""
        default_rules = [
            {
                'rule_id': 'SCAN_001',
                'name': 'Port Scan Detection',
                'description': 'Detects potential port scanning activity',
                'pattern': r'SYN.*multiple_ports',
                'severity': 'medium',
                'category': 'scan'
            },
            {
                'rule_id': 'DOS_001',
                'name': 'SYN Flood Attack',
                'description': 'Detects SYN flood DoS attacks',
                'pattern': r'SYN_flood',
                'severity': 'high',
                'category': 'dos'
            },
            {
                'rule_id': 'MALWARE_001',
                'name': 'Suspicious Payload',
                'description': 'Detects suspicious payload patterns',
                'pattern': r'(cmd\.exe|powershell|/bin/sh)',
                'severity': 'critical',
                'category': 'malware'
            },
            {
                'rule_id': 'EXPLOIT_001',
                'name': 'SQL Injection Attempt',
                'description': 'Detects SQL injection patterns',
                'pattern': r'(union.*select|drop.*table|insert.*into)',
                'severity': 'high',
                'category': 'exploit'
            },
            {
                'rule_id': 'EXPLOIT_002',
                'name': 'XSS Attempt',
                'description': 'Detects cross-site scripting attempts',
                'pattern': r'(<script|javascript:|onload=|onerror=)',
                'severity': 'medium',
                'category': 'exploit'
            }
        ]
        
        for rule_data in default_rules:
            rule = DetectionRule(**rule_data)
            self.rules[rule.rule_id] = rule
    
    def add_rule(self, rule: DetectionRule):
        """Add a new detection rule"""
        self.rules[rule.rule_id] = rule
        self.logger.info(f"Added detection rule: {rule.name}")
    
    def check_packet(self, packet_data: Dict) -> List[Dict]:
        """Check packet against all signature rules"""
        matches = []
        
        # Convert packet to searchable string
        packet_str = json.dumps(packet_data)
        
        for rule in self.rules.values():
            if rule.pattern and rule.pattern.search(packet_str):
                match = {
                    'rule_id': rule.rule_id,
                    'rule_name': rule.name,
                    'description': rule.description,
                    'severity': rule.severity,
                    'category': rule.category,
                    'timestamp': datetime.now().isoformat(),
                    'packet_info': {
                        'src_ip': packet_data.get('ip', {}).get('src_ip'),
                        'dest_ip': packet_data.get('ip', {}).get('dest_ip'),
                        'protocol': packet_data.get('protocol')
                    }
                }
                
                rule.matches += 1
                rule.last_match = datetime.now()
                matches.append(match)
                
                self.logger.warning(f"Signature match: {rule.name} from {match['packet_info']['src_ip']}")
        
        return matches

class AnomalyDetection:
    """Anomaly-based detection using statistical analysis"""
    
    def __init__(self, window_size=1000, threshold_multiplier=3.0):
        self.window_size = window_size
        self.threshold_multiplier = threshold_multiplier
        self.packet_sizes = deque(maxlen=window_size)
        self.connection_rates = deque(maxlen=window_size)
        self.protocol_distribution = defaultdict(lambda: deque(maxlen=window_size))
        self.ip_frequencies = defaultdict(lambda: deque(maxlen=window_size))
        self.logger = logging.getLogger(__name__)
    
    def update_baseline(self, packet_data: Dict):
        """Update baseline statistics with new packet"""
        # Packet size analysis
        packet_size = packet_data.get('size', 0)
        self.packet_sizes.append(packet_size)
        
        # Protocol distribution
        protocol = packet_data.get('protocol', 'unknown')
        current_time = time.time()
        self.protocol_distribution[protocol].append(current_time)
        
        # IP frequency analysis
        src_ip = packet_data.get('ip', {}).get('src_ip')
        if src_ip:
            self.ip_frequencies[src_ip].append(current_time)
    
    def detect_size_anomaly(self, packet_size: int) -> Optional[Dict]:
        """Detect packet size anomalies"""
        if len(self.packet_sizes) < 100:  # Need baseline
            return None
        
        mean_size = statistics.mean(self.packet_sizes)
        std_size = statistics.stdev(self.packet_sizes)
        
        threshold = mean_size + (self.threshold_multiplier * std_size)
        
        if packet_size > threshold:
            return {
                'type': 'size_anomaly',
                'severity': 'medium',
                'description': f'Unusually large packet: {packet_size} bytes (threshold: {threshold:.0f})',
                'packet_size': packet_size,
                'baseline_mean': mean_size,
                'threshold': threshold
            }
        
        return None
    
    def detect_frequency_anomaly(self, src_ip: str) -> Optional[Dict]:
        """Detect IP frequency anomalies"""
        if src_ip not in self.ip_frequencies:
            return None
        
        ip_times = list(self.ip_frequencies[src_ip])
        if len(ip_times) < 10:
            return None
        
        # Calculate packets per minute
        current_time = time.time()
        recent_packets = [t for t in ip_times if current_time - t < 60]  # Last minute
        packets_per_minute = len(recent_packets)
        
        # Threshold: more than 100 packets per minute from single IP
        if packets_per_minute > 100:
            return {
                'type': 'frequency_anomaly',
                'severity': 'high',
                'description': f'High packet frequency from {src_ip}: {packets_per_minute} packets/minute',
                'src_ip': src_ip,
                'packets_per_minute': packets_per_minute,
                'threshold': 100
            }
        
        return None
    
    def detect_protocol_anomaly(self, protocol: str) -> Optional[Dict]:
        """Detect protocol distribution anomalies"""
        if protocol not in self.protocol_distribution:
            return None
        
        protocol_times = list(self.protocol_distribution[protocol])
        if len(protocol_times) < 50:
            return None
        
        # Calculate recent protocol usage
        current_time = time.time()
        recent_usage = [t for t in protocol_times if current_time - t < 300]  # Last 5 minutes
        usage_rate = len(recent_usage) / 5  # per minute
        
        # Check if this protocol is being used unusually frequently
        total_recent = sum(len([t for t in times if current_time - t < 300]) 
                          for times in self.protocol_distribution.values())
        
        if total_recent > 0:
            protocol_percentage = (len(recent_usage) / total_recent) * 100
            
            # Alert if single protocol dominates (>80% of traffic)
            if protocol_percentage > 80 and len(recent_usage) > 100:
                return {
                    'type': 'protocol_anomaly',
                    'severity': 'medium',
                    'description': f'Protocol {protocol} dominates traffic: {protocol_percentage:.1f}%',
                    'protocol': protocol,
                    'percentage': protocol_percentage,
                    'threshold': 80
                }
        
        return None
    
    def analyze_packet(self, packet_data: Dict) -> List[Dict]:
        """Analyze packet for anomalies"""
        anomalies = []
        
        # Update baseline first
        self.update_baseline(packet_data)
        
        # Check for size anomalies
        packet_size = packet_data.get('size', 0)
        size_anomaly = self.detect_size_anomaly(packet_size)
        if size_anomaly:
            anomalies.append(size_anomaly)
        
        # Check for frequency anomalies
        src_ip = packet_data.get('ip', {}).get('src_ip')
        if src_ip:
            freq_anomaly = self.detect_frequency_anomaly(src_ip)
            if freq_anomaly:
                anomalies.append(freq_anomaly)
        
        # Check for protocol anomalies
        protocol = packet_data.get('protocol')
        if protocol:
            proto_anomaly = self.detect_protocol_anomaly(protocol)
            if proto_anomaly:
                anomalies.append(proto_anomaly)
        
        return anomalies

class BehavioralAnalysis:
    """Behavioral analysis for detecting attack patterns"""
    
    def __init__(self):
        self.connection_tracker = defaultdict(lambda: {
            'connections': deque(maxlen=1000),
            'ports_accessed': set(),
            'first_seen': None,
            'last_seen': None
        })
        self.logger = logging.getLogger(__name__)
    
    def track_connection(self, packet_data: Dict):
        """Track connection behavior"""
        src_ip = packet_data.get('ip', {}).get('src_ip')
        if not src_ip:
            return
        
        current_time = datetime.now()
        
        # Update connection tracking
        tracker = self.connection_tracker[src_ip]
        tracker['connections'].append(current_time)
        tracker['last_seen'] = current_time
        
        if tracker['first_seen'] is None:
            tracker['first_seen'] = current_time
        
        # Track accessed ports
        if 'tcp' in packet_data:
            dest_port = packet_data['tcp'].get('dest_port')
            if dest_port:
                tracker['ports_accessed'].add(dest_port)
        elif 'udp' in packet_data:
            dest_port = packet_data['udp'].get('dest_port')
            if dest_port:
                tracker['ports_accessed'].add(dest_port)
    
    def detect_port_scan(self, src_ip: str) -> Optional[Dict]:
        """Detect port scanning behavior"""
        if src_ip not in self.connection_tracker:
            return None
        
        tracker = self.connection_tracker[src_ip]
        ports_count = len(tracker['ports_accessed'])
        
        # Port scan threshold: accessing more than 20 different ports
        if ports_count > 20:
            time_span = (tracker['last_seen'] - tracker['first_seen']).total_seconds()
            
            return {
                'type': 'port_scan',
                'severity': 'high',
                'description': f'Port scan detected from {src_ip}: {ports_count} ports in {time_span:.0f} seconds',
                'src_ip': src_ip,
                'ports_scanned': ports_count,
                'time_span': time_span,
                'ports_list': list(tracker['ports_accessed'])[:50]  # Limit output
            }
        
        return None
    
    def detect_connection_flood(self, src_ip: str) -> Optional[Dict]:
        """Detect connection flooding"""
        if src_ip not in self.connection_tracker:
            return None
        
        tracker = self.connection_tracker[src_ip]
        connections = list(tracker['connections'])
        
        if len(connections) < 100:
            return None
        
        # Check connections in last minute
        current_time = datetime.now()
        recent_connections = [c for c in connections if (current_time - c).total_seconds() < 60]
        
        # Threshold: more than 50 connections per minute
        if len(recent_connections) > 50:
            return {
                'type': 'connection_flood',
                'severity': 'high',
                'description': f'Connection flood from {src_ip}: {len(recent_connections)} connections/minute',
                'src_ip': src_ip,
                'connections_per_minute': len(recent_connections),
                'threshold': 50
            }
        
        return None
    
    def analyze_behavior(self, packet_data: Dict) -> List[Dict]:
        """Analyze packet for behavioral anomalies"""
        behaviors = []
        
        # Track the connection
        self.track_connection(packet_data)
        
        src_ip = packet_data.get('ip', {}).get('src_ip')
        if not src_ip:
            return behaviors
        
        # Check for port scanning
        port_scan = self.detect_port_scan(src_ip)
        if port_scan:
            behaviors.append(port_scan)
        
        # Check for connection flooding
        conn_flood = self.detect_connection_flood(src_ip)
        if conn_flood:
            behaviors.append(conn_flood)
        
        return behaviors

class DetectionEngine:
    """Main detection engine coordinating all detection methods"""
    
    def __init__(self):
        self.signature_detection = SignatureDetection()
        self.anomaly_detection = AnomalyDetection()
        self.behavioral_analysis = BehavioralAnalysis()
        self.detection_results = deque(maxlen=10000)
        self.logger = logging.getLogger(__name__)
    
    def analyze_packet(self, packet_data: Dict) -> List[Dict]:
        """Analyze packet using all detection methods"""
        all_detections = []
        
        try:
            # Signature-based detection
            signature_matches = self.signature_detection.check_packet(packet_data)
            all_detections.extend(signature_matches)
            
            # Anomaly detection
            anomalies = self.anomaly_detection.analyze_packet(packet_data)
            for anomaly in anomalies:
                anomaly['detection_type'] = 'anomaly'
                anomaly['timestamp'] = datetime.now().isoformat()
                anomaly['packet_info'] = {
                    'src_ip': packet_data.get('ip', {}).get('src_ip'),
                    'dest_ip': packet_data.get('ip', {}).get('dest_ip'),
                    'protocol': packet_data.get('protocol')
                }
            all_detections.extend(anomalies)
            
            # Behavioral analysis
            behaviors = self.behavioral_analysis.analyze_behavior(packet_data)
            for behavior in behaviors:
                behavior['detection_type'] = 'behavioral'
                behavior['timestamp'] = datetime.now().isoformat()
                behavior['packet_info'] = {
                    'src_ip': packet_data.get('ip', {}).get('src_ip'),
                    'dest_ip': packet_data.get('ip', {}).get('dest_ip'),
                    'protocol': packet_data.get('protocol')
                }
            all_detections.extend(behaviors)
            
            # Store results
            for detection in all_detections:
                self.detection_results.append(detection)
            
        except Exception as e:
            self.logger.error(f"Error in packet analysis: {e}")
        
        return all_detections
    
    def get_detection_summary(self) -> Dict:
        """Get summary of recent detections"""
        if not self.detection_results:
            return {'total': 0, 'by_severity': {}, 'by_type': {}}
        
        recent_detections = [d for d in self.detection_results 
                           if datetime.fromisoformat(d['timestamp']) > datetime.now() - timedelta(hours=1)]
        
        summary = {
            'total': len(recent_detections),
            'by_severity': defaultdict(int),
            'by_type': defaultdict(int),
            'by_category': defaultdict(int)
        }
        
        for detection in recent_detections:
            summary['by_severity'][detection.get('severity', 'unknown')] += 1
            summary['by_type'][detection.get('detection_type', detection.get('type', 'unknown'))] += 1
            summary['by_category'][detection.get('category', 'unknown')] += 1
        
        return dict(summary)
    
    def export_detections(self, filename=None) -> str:
        """Export detection results"""
        if not filename:
            filename = f"detections_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(list(self.detection_results), f, indent=2)
            self.logger.info(f"Detections exported to {filename}")
            return filename
        except Exception as e:
            self.logger.error(f"Failed to export detections: {e}")
            return None

def main():
    """Test detection engine"""
    print("Detection Engine Test")
    print("=" * 30)
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create detection engine
    engine = DetectionEngine()
    
    # Test with mock packet data
    test_packets = [
        {
            'timestamp': datetime.now().isoformat(),
            'ip': {'src_ip': '192.168.1.100', 'dest_ip': '192.168.1.1', 'protocol': 6},
            'tcp': {'src_port': 12345, 'dest_port': 80, 'flags': {'syn': True, 'ack': False}},
            'protocol': 'TCP',
            'size': 64
        },
        {
            'timestamp': datetime.now().isoformat(),
            'ip': {'src_ip': '10.0.0.50', 'dest_ip': '192.168.1.1', 'protocol': 6},
            'tcp': {'src_port': 54321, 'dest_port': 22, 'flags': {'syn': True, 'ack': False}},
            'protocol': 'TCP',
            'size': 5000  # Unusually large
        }
    ]
    
    print("Analyzing test packets...")
    for i, packet in enumerate(test_packets):
        print(f"\nPacket {i+1}:")
        detections = engine.analyze_packet(packet)
        
        if detections:
            for detection in detections:
                print(f"  Detection: {detection.get('description', detection.get('rule_name', 'Unknown'))}")
                print(f"  Severity: {detection.get('severity', 'unknown')}")
        else:
            print("  No detections")
    
    # Show summary
    summary = engine.get_detection_summary()
    print(f"\nDetection Summary:")
    print(f"Total detections: {summary['total']}")
    print(f"By severity: {dict(summary['by_severity'])}")
    print(f"By type: {dict(summary['by_type'])}")

if __name__ == "__main__":
    main()

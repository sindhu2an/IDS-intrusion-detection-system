#!/usr/bin/env python3
"""
Real-time Web Dashboard v2.0
Flask-based web interface with WebSocket support for live IDS monitoring
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import threading
import time
from pathlib import Path

# Flask and WebSocket imports
from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_socketio import SocketIO, emit, join_room, leave_room
import sqlite3

# Import our IDS components
from ids_core_v2 import IDSCore, SecurityEvent, EventType, ThreatLevel
from network_capture_v2 import NetworkCapture
from ml_detection_v2 import AnomalyDetector, ThreatClassifier
from behavioral_analysis_v2 import BehaviorProfiler, AttackPatternDetector

logger = logging.getLogger(__name__)

class IDSDashboard:
    """Main IDS Dashboard Application"""
    
    def __init__(self, host='0.0.0.0', port=5000):
        self.host = host
        self.port = port
        
        # Initialize Flask app
        self.app = Flask(__name__, 
                        template_folder='templates',
                        static_folder='static')
        self.app.config['SECRET_KEY'] = 'ids_dashboard_secret_key_2024'
        
        # Initialize SocketIO
        self.socketio = SocketIO(self.app, cors_allowed_origins="*", async_mode='threading')
        
        # Initialize IDS components
        self.ids_core = IDSCore()
        self.network_capture = NetworkCapture()
        self.anomaly_detector = AnomalyDetector()
        self.threat_classifier = ThreatClassifier()
        self.behavior_profiler = BehaviorProfiler()
        self.pattern_detector = AttackPatternDetector()
        
        # Dashboard state
        self.dashboard_stats = {
            'total_events': 0,
            'active_threats': 0,
            'blocked_ips': 0,
            'system_uptime': 0,
            'last_update': datetime.now()
        }
        
        self.recent_events = []
        self.active_alerts = []
        self.system_metrics = {}
        
        # Setup routes and WebSocket handlers
        self._setup_routes()
        self._setup_websocket_handlers()
        
        # Background tasks
        self.background_tasks = []
        self.running = False
    
    def _setup_routes(self):
        """Setup Flask routes"""
        
        @self.app.route('/')
        def dashboard():
            """Main dashboard page"""
            return render_template('dashboard.html')
        
        @self.app.route('/alerts')
        def alerts():
            """Alerts management page"""
            return render_template('alerts.html')
        
        @self.app.route('/network')
        def network():
            """Network monitoring page"""
            return render_template('network.html')
        
        @self.app.route('/analytics')
        def analytics():
            """Analytics and ML insights page"""
            return render_template('analytics.html')
        
        @self.app.route('/config')
        def config():
            """Configuration management page"""
            return render_template('config.html')
        
        @self.app.route('/api/stats')
        def api_stats():
            """API endpoint for dashboard statistics"""
            return jsonify({
                'dashboard_stats': self.dashboard_stats,
                'ids_stats': self.ids_core.get_statistics(),
                'capture_stats': self.network_capture.get_statistics(),
                'system_metrics': self.system_metrics
            })
        
        @self.app.route('/api/events')
        def api_events():
            """API endpoint for recent events"""
            limit = request.args.get('limit', 50, type=int)
            return jsonify({
                'events': self.recent_events[-limit:],
                'total_count': len(self.recent_events)
            })
        
        @self.app.route('/api/alerts')
        def api_alerts():
            """API endpoint for active alerts"""
            return jsonify({
                'alerts': self.active_alerts,
                'alert_count': len(self.active_alerts)
            })
        
        @self.app.route('/api/control/<action>', methods=['POST'])
        def api_control(action):
            """API endpoint for system control"""
            try:
                if action == 'start_monitoring':
                    if not self.running:
                        self._start_background_tasks()
                        return jsonify({'status': 'success', 'message': 'Monitoring started'})
                    else:
                        return jsonify({'status': 'info', 'message': 'Already running'})
                
                elif action == 'stop_monitoring':
                    if self.running:
                        self._stop_background_tasks()
                        return jsonify({'status': 'success', 'message': 'Monitoring stopped'})
                    else:
                        return jsonify({'status': 'info', 'message': 'Already stopped'})
                
                elif action == 'clear_alerts':
                    self.active_alerts.clear()
                    return jsonify({'status': 'success', 'message': 'Alerts cleared'})
                
                else:
                    return jsonify({'status': 'error', 'message': 'Unknown action'})
            
            except Exception as e:
                return jsonify({'status': 'error', 'message': str(e)})
    
    def _setup_websocket_handlers(self):
        """Setup WebSocket event handlers"""
        
        @self.socketio.on('connect')
        def handle_connect():
            """Handle client connection"""
            logger.info(f"Client connected: {request.sid}")
            join_room('dashboard')
            
            # Send initial data
            emit('dashboard_stats', self.dashboard_stats)
            emit('recent_events', self.recent_events[-10:])
            emit('active_alerts', self.active_alerts)
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            """Handle client disconnection"""
            logger.info(f"Client disconnected: {request.sid}")
            leave_room('dashboard')
        
        @self.socketio.on('request_update')
        def handle_request_update():
            """Handle client request for data update"""
            emit('dashboard_stats', self.dashboard_stats)
            emit('system_metrics', self.system_metrics)
    
    def _start_background_tasks(self):
        """Start background monitoring tasks"""
        if self.running:
            return
        
        self.running = True
        logger.info("Starting IDS Dashboard background tasks...")
        
        # Start IDS core
        ids_thread = threading.Thread(target=self._run_ids_core, daemon=True)
        ids_thread.start()
        self.background_tasks.append(ids_thread)
        
        # Start network capture
        capture_thread = threading.Thread(target=self._run_network_capture, daemon=True)
        capture_thread.start()
        self.background_tasks.append(capture_thread)
        
        # Start dashboard updater
        dashboard_thread = threading.Thread(target=self._dashboard_updater, daemon=True)
        dashboard_thread.start()
        self.background_tasks.append(dashboard_thread)
        
        # Start metrics collector
        metrics_thread = threading.Thread(target=self._metrics_collector, daemon=True)
        metrics_thread.start()
        self.background_tasks.append(metrics_thread)
    
    def _stop_background_tasks(self):
        """Stop background monitoring tasks"""
        self.running = False
        self.ids_core.stop()
        self.network_capture.stop_capture()
        logger.info("Stopped IDS Dashboard background tasks")
    
    def _run_ids_core(self):
        """Run IDS core in background thread"""
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(self.ids_core.start())
        except Exception as e:
            logger.error(f"IDS Core error: {e}")
    
    def _run_network_capture(self):
        """Run network capture in background thread"""
        try:
            self.network_capture.set_ids_core(self.ids_core)
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(self.network_capture.start_capture())
        except Exception as e:
            logger.error(f"Network capture error: {e}")
    
    def _dashboard_updater(self):
        """Update dashboard statistics periodically"""
        while self.running:
            try:
                # Update dashboard stats
                self.dashboard_stats.update({
                    'total_events': self.ids_core.stats['events_processed'],
                    'active_threats': self.ids_core.stats['threats_detected'],
                    'system_uptime': (datetime.now() - self.ids_core.stats['start_time']).total_seconds(),
                    'last_update': datetime.now().isoformat()
                })
                
                # Get recent events from database
                recent_events = asyncio.run(self.ids_core.db_manager.get_recent_events(50))
                self.recent_events = recent_events
                
                # Update active alerts (high/critical threats)
                self.active_alerts = [
                    event for event in recent_events 
                    if event.get('threat_level') in ['high', 'critical'] and 
                    not event.get('acknowledged', False)
                ]
                
                # Broadcast updates to connected clients
                self.socketio.emit('dashboard_stats', self.dashboard_stats, room='dashboard')
                self.socketio.emit('recent_events', self.recent_events[-10:], room='dashboard')
                self.socketio.emit('active_alerts', self.active_alerts, room='dashboard')
                
                time.sleep(5)  # Update every 5 seconds
                
            except Exception as e:
                logger.error(f"Dashboard updater error: {e}")
                time.sleep(10)
    
    def _metrics_collector(self):
        """Collect system metrics periodically"""
        while self.running:
            try:
                import psutil
                
                # System metrics
                self.system_metrics = {
                    'cpu_percent': psutil.cpu_percent(interval=1),
                    'memory_percent': psutil.virtual_memory().percent,
                    'disk_percent': psutil.disk_usage('/').percent,
                    'network_io': dict(psutil.net_io_counters()._asdict()),
                    'timestamp': datetime.now().isoformat()
                }
                
                # IDS-specific metrics
                ids_stats = self.ids_core.get_statistics()
                capture_stats = self.network_capture.get_statistics()
                
                self.system_metrics.update({
                    'ids_events_per_minute': ids_stats.get('events_per_minute', 0),
                    'packets_per_second': capture_stats.get('packets_per_second', 0),
                    'detection_accuracy': 0.95,  # Placeholder
                    'false_positive_rate': 0.05  # Placeholder
                })
                
                # Broadcast metrics
                self.socketio.emit('system_metrics', self.system_metrics, room='dashboard')
                
                time.sleep(30)  # Update every 30 seconds
                
            except Exception as e:
                logger.error(f"Metrics collector error: {e}")
                time.sleep(60)
    
    def run(self, debug=False):
        """Run the dashboard application"""
        logger.info(f"Starting IDS Dashboard on {self.host}:{self.port}")
        
        # Start background tasks
        self._start_background_tasks()
        
        try:
            # Run Flask-SocketIO app
            self.socketio.run(
                self.app,
                host=self.host,
                port=self.port,
                debug=debug,
                allow_unsafe_werkzeug=True
            )
        except KeyboardInterrupt:
            logger.info("Dashboard shutdown requested")
        finally:
            self._stop_background_tasks()

# Create dashboard templates
def create_templates():
    """Create HTML templates for the dashboard"""
    
    templates_dir = Path("scripts/templates")
    templates_dir.mkdir(exist_ok=True)
    
    # Base template
    base_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}IDS Dashboard v2.0{% endblock %}</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Socket.IO -->
    <script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
    
    <style>
        .threat-critical { color: #dc3545; font-weight: bold; }
        .threat-high { color: #fd7e14; font-weight: bold; }
        .threat-medium { color: #ffc107; }
        .threat-low { color: #28a745; }
        
        .metric-card {
            transition: transform 0.2s;
        }
        .metric-card:hover {
            transform: translateY(-2px);
        }
        
        .event-item {
            border-left: 4px solid #dee2e6;
            margin-bottom: 0.5rem;
        }
        .event-item.critical { border-left-color: #dc3545; }
        .event-item.high { border-left-color: #fd7e14; }
        .event-item.medium { border-left-color: #ffc107; }
        .event-item.low { border-left-color: #28a745; }
        
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .status-running { background-color: #28a745; }
        .status-stopped { background-color: #dc3545; }
        .status-warning { background-color: #ffc107; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">
                <strong>IDS Dashboard v2.0</strong>
            </a>
            
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="/">Dashboard</a>
                <a class="nav-link" href="/alerts">Alerts</a>
                <a class="nav-link" href="/network">Network</a>
                <a class="nav-link" href="/analytics">Analytics</a>
                <a class="nav-link" href="/config">Config</a>
            </div>
            
            <div class="ms-3">
                <span class="status-indicator" id="connection-status"></span>
                <span id="connection-text">Connecting...</span>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container-fluid mt-4">
        {% block content %}{% endblock %}
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Base JavaScript -->
    <script>
        // Initialize Socket.IO connection
        const socket = io();
        
        // Connection status handling
        socket.on('connect', function() {
            document.getElementById('connection-status').className = 'status-indicator status-running';
            document.getElementById('connection-text').textContent = 'Connected';
        });
        
        socket.on('disconnect', function() {
            document.getElementById('connection-status').className = 'status-indicator status-stopped';
            document.getElementById('connection-text').textContent = 'Disconnected';
        });
        
        // Utility functions
        function formatTimestamp(timestamp) {
            return new Date(timestamp).toLocaleString();
        }
        
        function getThreatClass(level) {
            return 'threat-' + level.toLowerCase();
        }
        
        function formatBytes(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
    </script>
    
    {% block scripts %}{% endblock %}
</body>
</html>'''
    
    # Dashboard template
    dashboard_template = '''{% extends "base.html" %}

{% block content %}
<!-- System Status Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card metric-card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Total Events</h5>
                <h2 id="total-events">0</h2>
                <small>Events processed</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card metric-card bg-danger text-white">
            <div class="card-body">
                <h5 class="card-title">Active Threats</h5>
                <h2 id="active-threats">0</h2>
                <small>Threats detected</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card metric-card bg-warning text-white">
            <div class="card-body">
                <h5 class="card-title">System Load</h5>
                <h2 id="cpu-usage">0%</h2>
                <small>CPU utilization</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card metric-card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Uptime</h5>
                <h2 id="system-uptime">0h</h2>
                <small>System running</small>
            </div>
        </div>
    </div>
</div>

<!-- Control Panel -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5>System Control</h5>
            </div>
            <div class="card-body">
                <button class="btn btn-success me-2" onclick="startMonitoring()">Start Monitoring</button>
                <button class="btn btn-danger me-2" onclick="stopMonitoring()">Stop Monitoring</button>
                <button class="btn btn-warning me-2" onclick="clearAlerts()">Clear Alerts</button>
                <button class="btn btn-info" onclick="refreshData()">Refresh Data</button>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5>Threat Detection Over Time</h5>
            </div>
            <div class="card-body">
                <canvas id="threatChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5>System Performance</h5>
            </div>
            <div class="card-body">
                <canvas id="performanceChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Recent Events and Active Alerts -->
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5>Recent Security Events</h5>
            </div>
            <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                <div id="recent-events">
                    <p class="text-muted">No recent events</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>Active Alerts</h5>
            </div>
            <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                <div id="active-alerts">
                    <p class="text-muted">No active alerts</p>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}
<script>
    // Initialize charts
    let threatChart, performanceChart;
    
    // Threat detection chart
    const threatCtx = document.getElementById('threatChart').getContext('2d');
    threatChart = new Chart(threatCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Threats Detected',
                data: [],
                borderColor: 'rgb(220, 53, 69)',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // Performance chart
    const perfCtx = document.getElementById('performanceChart').getContext('2d');
    performanceChart = new Chart(perfCtx, {
        type: 'doughnut',
        data: {
            labels: ['CPU', 'Memory', 'Available'],
            datasets: [{
                data: [0, 0, 100],
                backgroundColor: [
                    'rgb(255, 193, 7)',
                    'rgb(220, 53, 69)',
                    'rgb(40, 167, 69)'
                ]
            }]
        },
        options: {
            responsive: true
        }
    });
    
    // Socket event handlers
    socket.on('dashboard_stats', function(stats) {
        document.getElementById('total-events').textContent = stats.total_events || 0;
        document.getElementById('active-threats').textContent = stats.active_threats || 0;
        
        if (stats.system_uptime) {
            const hours = Math.floor(stats.system_uptime / 3600);
            document.getElementById('system-uptime').textContent = hours + 'h';
        }
    });
    
    socket.on('system_metrics', function(metrics) {
        if (metrics.cpu_percent !== undefined) {
            document.getElementById('cpu-usage').textContent = Math.round(metrics.cpu_percent) + '%';
            
            // Update performance chart
            performanceChart.data.datasets[0].data = [
                metrics.cpu_percent,
                metrics.memory_percent || 0,
                100 - (metrics.cpu_percent + (metrics.memory_percent || 0)) / 2
            ];
            performanceChart.update();
        }
    });
    
    socket.on('recent_events', function(events) {
        const container = document.getElementById('recent-events');
        if (events.length === 0) {
            container.innerHTML = '<p class="text-muted">No recent events</p>';
            return;
        }
        
        container.innerHTML = events.map(event => `
            <div class="event-item ${event.threat_level} p-2 mb-2 bg-light rounded">
                <div class="d-flex justify-content-between">
                    <strong class="${getThreatClass(event.threat_level)}">${event.description}</strong>
                    <small class="text-muted">${formatTimestamp(event.timestamp)}</small>
                </div>
                <div class="small">
                    ${event.source_ip} → ${event.destination_ip}:${event.destination_port} (${event.protocol})
                </div>
            </div>
        `).join('');
    });
    
    socket.on('active_alerts', function(alerts) {
        const container = document.getElementById('active-alerts');
        if (alerts.length === 0) {
            container.innerHTML = '<p class="text-muted">No active alerts</p>';
            return;
        }
        
        container.innerHTML = alerts.map(alert => `
            <div class="alert alert-${alert.threat_level === 'critical' ? 'danger' : 'warning'} alert-dismissible fade show" role="alert">
                <strong>${alert.event_type}</strong><br>
                <small>${alert.description}</small>
                <button type="button" class="btn-close" onclick="dismissAlert('${alert.id}')"></button>
            </div>
        `).join('');
    });
    
    // Control functions
    function startMonitoring() {
        fetch('/api/control/start_monitoring', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showNotification('Monitoring started', 'success');
                }
            });
    }
    
    function stopMonitoring() {
        fetch('/api/control/stop_monitoring', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showNotification('Monitoring stopped', 'warning');
                }
            });
    }
    
    function clearAlerts() {
        fetch('/api/control/clear_alerts', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showNotification('Alerts cleared', 'info');
                }
            });
    }
    
    function refreshData() {
        socket.emit('request_update');
        showNotification('Data refreshed', 'info');
    }
    
    function showNotification(message, type) {
        // Simple notification system
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(alert);
        
        setTimeout(() => {
            if (alert.parentNode) {
                alert.parentNode.removeChild(alert);
            }
        }, 5000);
    }
    
    // Request initial data
    socket.emit('request_update');
</script>
{% endblock %}'''
    
    # Write templates
    with open(templates_dir / "base.html", "w") as f:
        f.write(base_template)
    
    with open(templates_dir / "dashboard.html", "w") as f:
        f.write(dashboard_template)
    
    # Create simple templates for other pages
    simple_pages = {
        "alerts.html": "Alert Management",
        "network.html": "Network Monitoring", 
        "analytics.html": "Analytics & ML Insights",
        "config.html": "Configuration Management"
    }
    
    for filename, title in simple_pages.items():
        template = f'''{{{% extends "base.html" %}}

{{{% block title %}}}{title} - IDS Dashboard{{{% endblock %}}

{{{% block content %}}
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3>{title}</h3>
            </div>
            <div class="card-body">
                <p class="lead">This page is under development.</p>
                <p>The {title.lower()} interface will provide comprehensive tools for managing and monitoring your IDS system.</p>
            </div>
        </div>
    </div>
</div>
{{{% endblock %}}'''
        
        with open(templates_dir / filename, "w") as f:
            f.write(template)

# Main execution
if __name__ == "__main__":
    # Create templates
    create_templates()
    
    # Initialize and run dashboard
    dashboard = IDSDashboard(host='0.0.0.0', port=5000)
    
    try:
        dashboard.run(debug=True)
    except KeyboardInterrupt:
        print("\nDashboard shutdown requested by user")
    except Exception as e:
        print(f"Dashboard error: {e}")

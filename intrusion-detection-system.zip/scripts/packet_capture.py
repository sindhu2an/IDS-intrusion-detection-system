#!/usr/bin/env python3
"""
Core Packet Capture Engine for Intrusion Detection System
Captures and analyzes network packets in real-time
"""

import socket
import struct
import threading
import time
import json
import logging
from datetime import datetime
from collections import defaultdict, deque
import ipaddress

class PacketCapture:
    def __init__(self, interface='eth0', max_packets=10000):
        self.interface = interface
        self.max_packets = max_packets
        self.captured_packets = deque(maxlen=max_packets)
        self.packet_stats = defaultdict(int)
        self.suspicious_ips = set()
        self.running = False
        self.capture_thread = None
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('ids_capture.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def create_raw_socket(self):
        """Create raw socket for packet capture"""
        try:
            # Create raw socket
            sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
            sock.bind((self.interface, 0))
            return sock
        except PermissionError:
            self.logger.error("Permission denied. Run as root or with CAP_NET_RAW capability")
            return None
        except Exception as e:
            self.logger.error(f"Failed to create socket: {e}")
            return None
    
    def parse_ethernet_header(self, packet):
        """Parse Ethernet header"""
        eth_header = struct.unpack('!6s6sH', packet[:14])
        dest_mac = ':'.join(f'{b:02x}' for b in eth_header[0])
        src_mac = ':'.join(f'{b:02x}' for b in eth_header[1])
        eth_type = eth_header[2]
        
        return {
            'dest_mac': dest_mac,
            'src_mac': src_mac,
            'type': eth_type,
            'payload': packet[14:]
        }
    
    def parse_ip_header(self, packet):
        """Parse IP header"""
        if len(packet) < 20:
            return None
            
        ip_header = struct.unpack('!BBHHHBBH4s4s', packet[:20])
        
        version = ip_header[0] >> 4
        ihl = (ip_header[0] & 0xF) * 4
        ttl = ip_header[5]
        protocol = ip_header[6]
        src_ip = socket.inet_ntoa(ip_header[8])
        dest_ip = socket.inet_ntoa(ip_header[9])
        
        return {
            'version': version,
            'header_length': ihl,
            'ttl': ttl,
            'protocol': protocol,
            'src_ip': src_ip,
            'dest_ip': dest_ip,
            'payload': packet[ihl:]
        }
    
    def parse_tcp_header(self, packet):
        """Parse TCP header"""
        if len(packet) < 20:
            return None
            
        tcp_header = struct.unpack('!HHLLBBHHH', packet[:20])
        
        src_port = tcp_header[0]
        dest_port = tcp_header[1]
        seq_num = tcp_header[2]
        ack_num = tcp_header[3]
        flags = tcp_header[5]
        
        # Extract flag bits
        fin = flags & 0x01
        syn = flags & 0x02
        rst = flags & 0x04
        psh = flags & 0x08
        ack = flags & 0x10
        urg = flags & 0x20
        
        return {
            'src_port': src_port,
            'dest_port': dest_port,
            'seq_num': seq_num,
            'ack_num': ack_num,
            'flags': {
                'fin': bool(fin),
                'syn': bool(syn),
                'rst': bool(rst),
                'psh': bool(psh),
                'ack': bool(ack),
                'urg': bool(urg)
            }
        }
    
    def parse_udp_header(self, packet):
        """Parse UDP header"""
        if len(packet) < 8:
            return None
            
        udp_header = struct.unpack('!HHHH', packet[:8])
        
        return {
            'src_port': udp_header[0],
            'dest_port': udp_header[1],
            'length': udp_header[2],
            'checksum': udp_header[3]
        }
    
    def analyze_packet(self, raw_packet):
        """Analyze captured packet"""
        timestamp = datetime.now()
        
        # Parse Ethernet header
        eth_data = self.parse_ethernet_header(raw_packet)
        
        # Check if it's an IP packet
        if eth_data['type'] != 0x0800:  # Not IPv4
            return None
        
        # Parse IP header
        ip_data = self.parse_ip_header(eth_data['payload'])
        if not ip_data:
            return None
        
        packet_info = {
            'timestamp': timestamp.isoformat(),
            'ethernet': eth_data,
            'ip': ip_data,
            'size': len(raw_packet)
        }
        
        # Parse transport layer
        if ip_data['protocol'] == 6:  # TCP
            tcp_data = self.parse_tcp_header(ip_data['payload'])
            if tcp_data:
                packet_info['tcp'] = tcp_data
                packet_info['protocol'] = 'TCP'
        elif ip_data['protocol'] == 17:  # UDP
            udp_data = self.parse_udp_header(ip_data['payload'])
            if udp_data:
                packet_info['udp'] = udp_data
                packet_info['protocol'] = 'UDP'
        else:
            packet_info['protocol'] = f'IP_PROTO_{ip_data["protocol"]}'
        
        # Update statistics
        self.packet_stats['total_packets'] += 1
        self.packet_stats[f'protocol_{packet_info["protocol"]}'] += 1
        self.packet_stats[f'src_ip_{ip_data["src_ip"]}'] += 1
        
        # Basic anomaly detection
        self.detect_anomalies(packet_info)
        
        return packet_info
    
    def detect_anomalies(self, packet_info):
        """Basic anomaly detection"""
        src_ip = packet_info['ip']['src_ip']
        
        # Check for port scanning (multiple destination ports from same IP)
        if 'tcp' in packet_info:
            tcp_data = packet_info['tcp']
            if tcp_data['flags']['syn'] and not tcp_data['flags']['ack']:
                # SYN packet - potential port scan
                key = f'syn_scan_{src_ip}'
                self.packet_stats[key] += 1
                
                if self.packet_stats[key] > 10:  # Threshold for port scan
                    self.suspicious_ips.add(src_ip)
                    self.logger.warning(f"Potential port scan detected from {src_ip}")
        
        # Check for suspicious IP ranges
        try:
            ip_obj = ipaddress.ip_address(src_ip)
            if ip_obj.is_private and str(ip_obj).startswith('192.168.'):
                # Monitor internal network activity
                pass
        except ValueError:
            pass
    
    def capture_packets(self):
        """Main packet capture loop"""
        sock = self.create_raw_socket()
        if not sock:
            return
        
        self.logger.info(f"Starting packet capture on interface {self.interface}")
        
        try:
            while self.running:
                try:
                    raw_packet, addr = sock.recvfrom(65535)
                    packet_info = self.analyze_packet(raw_packet)
                    
                    if packet_info:
                        self.captured_packets.append(packet_info)
                        
                        # Log suspicious activity
                        if packet_info['ip']['src_ip'] in self.suspicious_ips:
                            self.logger.warning(f"Suspicious packet from {packet_info['ip']['src_ip']}")
                
                except socket.timeout:
                    continue
                except Exception as e:
                    self.logger.error(f"Error capturing packet: {e}")
                    
        except KeyboardInterrupt:
            self.logger.info("Capture interrupted by user")
        finally:
            sock.close()
            self.logger.info("Packet capture stopped")
    
    def start_capture(self):
        """Start packet capture in background thread"""
        if self.running:
            self.logger.warning("Capture already running")
            return
        
        self.running = True
        self.capture_thread = threading.Thread(target=self.capture_packets)
        self.capture_thread.daemon = True
        self.capture_thread.start()
        self.logger.info("Packet capture started")
    
    def stop_capture(self):
        """Stop packet capture"""
        self.running = False
        if self.capture_thread:
            self.capture_thread.join(timeout=5)
        self.logger.info("Packet capture stopped")
    
    def get_statistics(self):
        """Get capture statistics"""
        return {
            'total_packets': len(self.captured_packets),
            'suspicious_ips': list(self.suspicious_ips),
            'protocol_stats': {k: v for k, v in self.packet_stats.items() if k.startswith('protocol_')},
            'top_sources': {k: v for k, v in sorted(self.packet_stats.items(), key=lambda x: x[1], reverse=True)[:10] if k.startswith('src_ip_')}
        }
    
    def export_packets(self, filename=None):
        """Export captured packets to JSON file"""
        if not filename:
            filename = f"captured_packets_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(list(self.captured_packets), f, indent=2)
            self.logger.info(f"Packets exported to {filename}")
            return filename
        except Exception as e:
            self.logger.error(f"Failed to export packets: {e}")
            return None

def main():
    """Main function for testing packet capture"""
    print("Intrusion Detection System - Packet Capture Engine")
    print("=" * 50)
    
    # Create packet capture instance
    capture = PacketCapture(interface='lo')  # Use loopback for testing
    
    try:
        # Start capture
        capture.start_capture()
        
        # Run for 30 seconds
        print("Capturing packets for 30 seconds...")
        time.sleep(30)
        
        # Stop capture
        capture.stop_capture()
        
        # Display statistics
        stats = capture.get_statistics()
        print("\nCapture Statistics:")
        print(f"Total packets captured: {stats['total_packets']}")
        print(f"Suspicious IPs: {stats['suspicious_ips']}")
        print(f"Protocol distribution: {stats['protocol_stats']}")
        
        # Export packets
        export_file = capture.export_packets()
        if export_file:
            print(f"Packets exported to: {export_file}")
            
    except KeyboardInterrupt:
        print("\nCapture interrupted by user")
        capture.stop_capture()

if __name__ == "__main__":
    main()
